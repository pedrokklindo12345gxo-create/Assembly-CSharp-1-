using Spine.Unity.Modules.AttachmentTools;
using UnityEngine;

namespace Spine.Unity.Modules;

public static class SpriteAttachmentExtensions
{
	public static RegionAttachment AttachUnitySprite(this Skeleton skeleton, string slotName, Sprite sprite, string shaderName = "Spine/Skeleton", bool applyPMA = true)
	{
		return skeleton.AttachUnitySprite(slotName, sprite, Shader.Find(shaderName), applyPMA);
	}

	public static RegionAttachment AddUnitySprite(this SkeletonData skeletonData, string slotName, Sprite sprite, string skinName = "", string shaderName = "Spine/Skeleton", bool applyPMA = true)
	{
		return skeletonData.AddUnitySprite(slotName, sprite, skinName, Shader.Find(shaderName), applyPMA);
	}

	public static RegionAttachment AttachUnitySprite(this Skeleton skeleton, string slotName, Sprite sprite, Shader shader, bool applyPMA)
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Expected O, but got Unknown
		RegionAttachment regionAttachment = ((!applyPMA) ? sprite.ToRegionAttachment(new Material(shader)) : sprite.ToRegionAttachmentPMAClone(shader, (TextureFormat)4));
		skeleton.FindSlot(slotName).Attachment = regionAttachment;
		return regionAttachment;
	}

	public static RegionAttachment AddUnitySprite(this SkeletonData skeletonData, string slotName, Sprite sprite, string skinName, Shader shader, bool applyPMA)
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Expected O, but got Unknown
		RegionAttachment regionAttachment = ((!applyPMA) ? sprite.ToRegionAttachment(new Material(shader)) : sprite.ToRegionAttachmentPMAClone(shader, (TextureFormat)4));
		int slotIndex = skeletonData.FindSlotIndex(slotName);
		Skin skin = skeletonData.defaultSkin;
		if (skinName != string.Empty)
		{
			skin = skeletonData.FindSkin(skinName);
		}
		skin.AddAttachment(slotIndex, regionAttachment.Name, regionAttachment);
		return regionAttachment;
	}
}
