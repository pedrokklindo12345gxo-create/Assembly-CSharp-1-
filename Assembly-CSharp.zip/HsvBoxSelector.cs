using UnityEngine;
using UnityEngine.EventSystems;

public class HsvBoxSelector : MonoBehaviour, IPointerDownHandler, IEventSystemHandler
{
	public HSVDragger dragger;

	private RectTransform rectTransform;

	private void Awake()
	{
		rectTransform = ((Component)this).GetComponent<RectTransform>();
	}

	private void Update()
	{
	}

	private void PlaceCursor(PointerEventData eventData)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		Debug.Log((object)string.Concat(eventData.position, " ", ((Transform)rectTransform).position));
	}

	public void OnDrag(PointerEventData eventData)
	{
		PlaceCursor(eventData);
	}

	public void OnPointerDown(PointerEventData eventData)
	{
		PlaceCursor(eventData);
	}
}
