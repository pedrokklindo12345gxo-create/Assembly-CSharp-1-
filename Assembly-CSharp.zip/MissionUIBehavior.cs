using UnityEngine;
using UnityEngine.UI;

public class MissionUIBehavior : MonoBehaviour
{
	public enum MissionStatus
	{
		Active,
		Complete,
		Failed
	}

	public Sprite completeSprite;

	public Sprite failedSprite;

	public Image bg;

	public Image grade;

	public Mission mission;

	public Text text;

	public Image face;

	public Room environmentLock;

	public MissionStatus status;

	public void SetInProgress()
	{
		((Behaviour)grade).enabled = false;
		status = MissionStatus.Active;
	}

	public void SetComplete()
	{
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		((Behaviour)grade).enabled = true;
		grade.sprite = completeSprite;
		status = MissionStatus.Complete;
		((Graphic)grade).rectTransform.anchoredPosition = new Vector2(-64f, 10f);
	}

	public void SetFailed()
	{
		((Behaviour)grade).enabled = true;
		grade.sprite = failedSprite;
		status = MissionStatus.Failed;
	}

	public void SetColor(Color c)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		((Graphic)bg).color = c;
	}

	public void SetFace(Sprite t)
	{
		face.sprite = t;
	}
}
