using UnityEngine;

namespace Spine.Unity;

public static class SpineMesh
{
	internal const HideFlags MeshHideflags = (HideFlags)20;

	public static Mesh NewMesh()
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Expected O, but got Unknown
		Mesh val = new Mesh();
		val.MarkDynamic();
		((Object)val).name = "Skeleton Mesh";
		((Object)val).hideFlags = (HideFlags)20;
		return val;
	}
}
