using System;
using System.Collections.Generic;
using UnityEngine;

namespace Spine.Unity;

[RequireComponent(typeof(ISkeletonAnimation))]
[ExecuteInEditMode]
public class SkeletonUtility : MonoBehaviour
{
	public delegate void SkeletonUtilityDelegate();

	public Transform boneRoot;

	[HideInInspector]
	public SkeletonRenderer skeletonRenderer;

	[HideInInspector]
	public ISkeletonAnimation skeletonAnimation;

	[NonSerialized]
	public List<SkeletonUtilityBone> utilityBones = new List<SkeletonUtilityBone>();

	[NonSerialized]
	public List<SkeletonUtilityConstraint> utilityConstraints = new List<SkeletonUtilityConstraint>();

	protected bool hasTransformBones;

	protected bool hasUtilityConstraints;

	protected bool needToReprocessBones;

	public event SkeletonUtilityDelegate OnReset;

	public static PolygonCollider2D AddBoundingBoxGameObject(Skeleton skeleton, string skinName, string slotName, string attachmentName, Transform parent, bool isTrigger = true)
	{
		Skin skin = ((!string.IsNullOrEmpty(skinName)) ? skeleton.data.FindSkin(skinName) : skeleton.data.defaultSkin);
		if (skin == null)
		{
			Debug.LogError((object)("Skin " + skinName + " not found!"));
			return null;
		}
		Attachment attachment = skin.GetAttachment(skeleton.FindSlotIndex(slotName), attachmentName);
		if (attachment == null)
		{
			Debug.LogFormat("Attachment in slot '{0}' named '{1}' not found in skin '{2}'.", new object[3] { slotName, attachmentName, skin.name });
			return null;
		}
		if (attachment is BoundingBoxAttachment boundingBoxAttachment)
		{
			Slot slot = skeleton.FindSlot(slotName);
			return AddBoundingBoxGameObject(boundingBoxAttachment.Name, boundingBoxAttachment, slot, parent, isTrigger);
		}
		Debug.LogFormat("Attachment '{0}' was not a Bounding Box.", new object[1] { attachmentName });
		return null;
	}

	public static PolygonCollider2D AddBoundingBoxGameObject(string name, BoundingBoxAttachment box, Slot slot, Transform parent, bool isTrigger = true)
	{
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Expected O, but got Unknown
		//IL_002f: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		GameObject val = new GameObject("[BoundingBox]" + ((!string.IsNullOrEmpty(name)) ? name : box.Name));
		Transform transform = val.transform;
		transform.parent = parent;
		transform.localPosition = Vector3.zero;
		transform.localRotation = Quaternion.identity;
		transform.localScale = Vector3.one;
		return AddBoundingBoxAsComponent(box, slot, val, isTrigger);
	}

	public static PolygonCollider2D AddBoundingBoxAsComponent(BoundingBoxAttachment box, Slot slot, GameObject gameObject, bool isTrigger = true)
	{
		if (box == null)
		{
			return null;
		}
		if (slot.bone != slot.Skeleton.RootBone && (Object)(object)gameObject.GetComponent<Rigidbody2D>() == (Object)null)
		{
			Rigidbody2D obj = gameObject.AddComponent<Rigidbody2D>();
			obj.isKinematic = true;
			obj.gravityScale = 0f;
		}
		PolygonCollider2D obj2 = gameObject.AddComponent<PolygonCollider2D>();
		((Collider2D)obj2).isTrigger = isTrigger;
		SetColliderPointsLocal(obj2, slot, box);
		return obj2;
	}

	public static void SetColliderPointsLocal(PolygonCollider2D collider, Slot slot, BoundingBoxAttachment box)
	{
		if (box != null)
		{
			if (box.IsWeighted())
			{
				Debug.LogWarning((object)"UnityEngine.PolygonCollider2D does not support weighted or animated points. Collider points will not be animated and may have incorrect orientation. If you want to use it as a collider, please remove weights and animations from the bounding box in Spine editor.");
			}
			Vector2[] localVertices = box.GetLocalVertices(slot, null);
			collider.SetPath(0, localVertices);
		}
	}

	public static Bounds GetBoundingBoxBounds(BoundingBoxAttachment boundingBox, float depth = 0f)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		float[] vertices = boundingBox.Vertices;
		int num = vertices.Length;
		Bounds result = default(Bounds);
		((Bounds)(ref result)).center = new Vector3(vertices[0], vertices[1], 0f);
		for (int i = 2; i < num; i += 2)
		{
			((Bounds)(ref result)).Encapsulate(new Vector3(vertices[i], vertices[i + 1], 0f));
		}
		Vector3 size = ((Bounds)(ref result)).size;
		size.z = depth;
		((Bounds)(ref result)).size = size;
		return result;
	}

	private void Update()
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		Skeleton skeleton = skeletonRenderer.skeleton;
		if ((Object)(object)boneRoot != (Object)null && skeleton != null)
		{
			Vector3 one = Vector3.one;
			if (skeleton.FlipX)
			{
				one.x = -1f;
			}
			if (skeleton.FlipY)
			{
				one.y = -1f;
			}
			boneRoot.localScale = one;
		}
	}

	private void OnEnable()
	{
		if ((Object)(object)skeletonRenderer == (Object)null)
		{
			skeletonRenderer = ((Component)this).GetComponent<SkeletonRenderer>();
		}
		if (skeletonAnimation == null)
		{
			skeletonAnimation = ((Component)this).GetComponent<SkeletonAnimation>();
			if (skeletonAnimation == null)
			{
				skeletonAnimation = ((Component)this).GetComponent<SkeletonAnimator>();
			}
		}
		SkeletonRenderer obj = skeletonRenderer;
		obj.OnRebuild = (SkeletonRenderer.SkeletonRendererDelegate)Delegate.Remove(obj.OnRebuild, new SkeletonRenderer.SkeletonRendererDelegate(HandleRendererReset));
		SkeletonRenderer obj2 = skeletonRenderer;
		obj2.OnRebuild = (SkeletonRenderer.SkeletonRendererDelegate)Delegate.Combine(obj2.OnRebuild, new SkeletonRenderer.SkeletonRendererDelegate(HandleRendererReset));
		if (skeletonAnimation != null)
		{
			skeletonAnimation.UpdateLocal -= UpdateLocal;
			skeletonAnimation.UpdateLocal += UpdateLocal;
		}
		CollectBones();
	}

	private void Start()
	{
		CollectBones();
	}

	private void OnDisable()
	{
		SkeletonRenderer obj = skeletonRenderer;
		obj.OnRebuild = (SkeletonRenderer.SkeletonRendererDelegate)Delegate.Remove(obj.OnRebuild, new SkeletonRenderer.SkeletonRendererDelegate(HandleRendererReset));
		if (skeletonAnimation != null)
		{
			skeletonAnimation.UpdateLocal -= UpdateLocal;
			skeletonAnimation.UpdateWorld -= UpdateWorld;
			skeletonAnimation.UpdateComplete -= UpdateComplete;
		}
	}

	private void HandleRendererReset(SkeletonRenderer r)
	{
		if (this.OnReset != null)
		{
			this.OnReset();
		}
		CollectBones();
	}

	public void RegisterBone(SkeletonUtilityBone bone)
	{
		if (!utilityBones.Contains(bone))
		{
			utilityBones.Add(bone);
			needToReprocessBones = true;
		}
	}

	public void UnregisterBone(SkeletonUtilityBone bone)
	{
		utilityBones.Remove(bone);
	}

	public void RegisterConstraint(SkeletonUtilityConstraint constraint)
	{
		if (!utilityConstraints.Contains(constraint))
		{
			utilityConstraints.Add(constraint);
			needToReprocessBones = true;
		}
	}

	public void UnregisterConstraint(SkeletonUtilityConstraint constraint)
	{
		utilityConstraints.Remove(constraint);
	}

	public void CollectBones()
	{
		Skeleton skeleton = skeletonRenderer.skeleton;
		if (skeleton == null)
		{
			return;
		}
		if ((Object)(object)boneRoot != (Object)null)
		{
			List<object> list = new List<object>();
			ExposedList<IkConstraint> ikConstraints = skeleton.IkConstraints;
			int i = 0;
			for (int count = ikConstraints.Count; i < count; i++)
			{
				list.Add(ikConstraints.Items[i].target);
			}
			ExposedList<TransformConstraint> transformConstraints = skeleton.TransformConstraints;
			int j = 0;
			for (int count2 = transformConstraints.Count; j < count2; j++)
			{
				list.Add(transformConstraints.Items[j].target);
			}
			List<SkeletonUtilityBone> list2 = utilityBones;
			int k = 0;
			for (int count3 = list2.Count; k < count3; k++)
			{
				SkeletonUtilityBone skeletonUtilityBone = list2[k];
				if (skeletonUtilityBone.bone != null)
				{
					hasTransformBones |= skeletonUtilityBone.mode == SkeletonUtilityBone.Mode.Override;
					hasUtilityConstraints |= list.Contains(skeletonUtilityBone.bone);
				}
			}
			hasUtilityConstraints |= utilityConstraints.Count > 0;
			if (skeletonAnimation != null)
			{
				skeletonAnimation.UpdateWorld -= UpdateWorld;
				skeletonAnimation.UpdateComplete -= UpdateComplete;
				if (hasTransformBones || hasUtilityConstraints)
				{
					skeletonAnimation.UpdateWorld += UpdateWorld;
				}
				if (hasUtilityConstraints)
				{
					skeletonAnimation.UpdateComplete += UpdateComplete;
				}
			}
			needToReprocessBones = false;
		}
		else
		{
			utilityBones.Clear();
			utilityConstraints.Clear();
		}
	}

	private void UpdateLocal(ISkeletonAnimation anim)
	{
		if (needToReprocessBones)
		{
			CollectBones();
		}
		List<SkeletonUtilityBone> list = utilityBones;
		if (list != null)
		{
			int i = 0;
			for (int count = list.Count; i < count; i++)
			{
				list[i].transformLerpComplete = false;
			}
			UpdateAllBones();
		}
	}

	private void UpdateWorld(ISkeletonAnimation anim)
	{
		UpdateAllBones();
		int i = 0;
		for (int count = utilityConstraints.Count; i < count; i++)
		{
			utilityConstraints[i].DoUpdate();
		}
	}

	private void UpdateComplete(ISkeletonAnimation anim)
	{
		UpdateAllBones();
	}

	private void UpdateAllBones()
	{
		if ((Object)(object)boneRoot == (Object)null)
		{
			CollectBones();
		}
		List<SkeletonUtilityBone> list = utilityBones;
		if (list != null)
		{
			int i = 0;
			for (int count = list.Count; i < count; i++)
			{
				list[i].DoUpdate();
			}
		}
	}

	public Transform GetBoneRoot()
	{
		//IL_001b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)boneRoot != (Object)null)
		{
			return boneRoot;
		}
		boneRoot = new GameObject("SkeletonUtility-Root").transform;
		boneRoot.parent = ((Component)this).transform;
		boneRoot.localPosition = Vector3.zero;
		boneRoot.localRotation = Quaternion.identity;
		boneRoot.localScale = Vector3.one;
		return boneRoot;
	}

	public GameObject SpawnRoot(SkeletonUtilityBone.Mode mode, bool pos, bool rot, bool sca)
	{
		GetBoneRoot();
		Skeleton skeleton = skeletonRenderer.skeleton;
		GameObject result = SpawnBone(skeleton.RootBone, boneRoot, mode, pos, rot, sca);
		CollectBones();
		return result;
	}

	public GameObject SpawnHierarchy(SkeletonUtilityBone.Mode mode, bool pos, bool rot, bool sca)
	{
		GetBoneRoot();
		Skeleton skeleton = skeletonRenderer.skeleton;
		GameObject result = SpawnBoneRecursively(skeleton.RootBone, boneRoot, mode, pos, rot, sca);
		CollectBones();
		return result;
	}

	public GameObject SpawnBoneRecursively(Bone bone, Transform parent, SkeletonUtilityBone.Mode mode, bool pos, bool rot, bool sca)
	{
		GameObject val = SpawnBone(bone, parent, mode, pos, rot, sca);
		ExposedList<Bone> children = bone.Children;
		int i = 0;
		for (int count = children.Count; i < count; i++)
		{
			Bone bone2 = children.Items[i];
			SpawnBoneRecursively(bone2, val.transform, mode, pos, rot, sca);
		}
		return val;
	}

	public GameObject SpawnBone(Bone bone, Transform parent, SkeletonUtilityBone.Mode mode, bool pos, bool rot, bool sca)
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Expected O, but got Unknown
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		GameObject val = new GameObject(bone.Data.Name);
		val.transform.parent = parent;
		SkeletonUtilityBone skeletonUtilityBone = val.AddComponent<SkeletonUtilityBone>();
		skeletonUtilityBone.skeletonUtility = this;
		skeletonUtilityBone.position = pos;
		skeletonUtilityBone.rotation = rot;
		skeletonUtilityBone.scale = sca;
		skeletonUtilityBone.mode = mode;
		skeletonUtilityBone.zPosition = true;
		skeletonUtilityBone.Reset();
		skeletonUtilityBone.bone = bone;
		skeletonUtilityBone.boneName = bone.Data.Name;
		skeletonUtilityBone.valid = true;
		if (mode == SkeletonUtilityBone.Mode.Override)
		{
			if (rot)
			{
				val.transform.localRotation = Quaternion.Euler(0f, 0f, skeletonUtilityBone.bone.AppliedRotation);
			}
			if (pos)
			{
				val.transform.localPosition = new Vector3(skeletonUtilityBone.bone.X, skeletonUtilityBone.bone.Y, 0f);
			}
			val.transform.localScale = new Vector3(skeletonUtilityBone.bone.scaleX, skeletonUtilityBone.bone.scaleY, 0f);
		}
		return val;
	}
}
