using System.Collections;
using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using UnityEngine;

public class HallMonitor : NPCBehavior
{
	private bool mShowedBathroomPass;

	private bool mShowedHallPass;

	private bool mIsMovingBack;

	private bool mGaveCiggs;

	private bool mDontEndCafeteria;

	private bool mShowedPass
	{
		get
		{
			if (!mShowedBathroomPass)
			{
				return mShowedHallPass;
			}
			return true;
		}
	}

	public void CheckSmoking()
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		if (EnvironmentController.Instance.furthestRoom == Room.Cafeteria)
		{
			((Component)Object.FindObjectOfType<Janitor>()).transform.position = new Vector3(0f, 50f, 0f);
			if (!mGaveCiggs)
			{
				GameObject.Find("BathroomBoxes").SetActive(false);
				((Component)this).transform.position = new Vector3(-10f, -6.15f, -9.9f);
				SetDepth();
				UnlockHint("General", 5);
				UnlockHint("Lily", 2);
				UnlockHint("Jerome", 5);
				((MonoBehaviour)this).StartCoroutine(StartBathroom());
			}
			else
			{
				((Component)this).transform.position = new Vector3(26.1f, -4.6f, -4.7f);
			}
		}
	}

	private IEnumerator StartBathroom()
	{
		Lily i = Object.FindObjectOfType<Lily>();
		player.inAnim = true;
		if (UI.IsMissionActive(Mission.LilyMeetInBathroom))
		{
			((Component)i).transform.position = new Vector3(-18.7f, -1f, 1.3f);
			i.SetDepth();
			i.SetDirection(setFlip: true);
			SetCurrentConversation(5);
			CompleteMission(Mission.LilyMeetInBathroom);
			yield return (object)new WaitForSeconds(1f);
			player.inAnim = false;
			((MonoBehaviour)this).StartCoroutine(RunDialogueSection("What the--?!~ Woah there little hombre! You're way too young to be bringing your little girlfriend into the bathroom with you!", "¿¡Qué está pa--?!~ ¡Hey hombrecito! ¡Está demasiado joven para llevar a tu novia al baño! ", this));
			while (pEmptyOptions)
			{
				yield return null;
			}
			((MonoBehaviour)this).StartCoroutine(RunDialogueSection("Gotta wait 'til at least sixth grade for that. I gotta take you both to the principal.", "Espérese por lo menos hasta el sexto grado. Voy a llevarlos a los dos al director. ", this));
			while (pEmptyOptions)
			{
				yield return null;
			}
			((MonoBehaviour)this).StartCoroutine(RunDialogueSection("No! You don't understand!~ This is so important!~ You can't stop us! There must be something we can do!", "¡No! ¡Usted no entiende!~ ¡Esto es muy importante!~ ¡No puede detenernos! ¡Hay algo que tenemos que hacer!", i));
			while (pEmptyOptions)
			{
				yield return null;
			}
			Interact();
		}
		else
		{
			yield return (object)new WaitForSeconds(1f);
			player.inAnim = false;
			Interact();
		}
	}

	private void GiveCigs()
	{
		player.UseItem(Item.Cigarettes);
		mGaveCiggs = true;
	}

	private void WalkToStallLily()
	{
		((MonoBehaviour)this).StartCoroutine(Object.FindObjectOfType<Lily>().MakePhoneCall());
		WalkToStall();
	}

	private void WalkToStall()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		SetDirection(setFlip: true);
		WalkToPoint(new Vector3(26.1f, -4.6f, -4.7f), 2f);
	}

	public void EndBathroom()
	{
		SetCurrentConversation(11);
		Interact();
	}

	public void StartFollowing()
	{
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		if (EnvironmentController.Instance.furthestRoom == Room.Classroom1 || EnvironmentController.Instance.furthestRoom == Room.Office)
		{
			if (mShowedBathroomPass)
			{
				((Component)this).transform.position = new Vector3(9.5f, -5f, -4.7f);
				GameObject.Find("HallMonitorWallCollider").transform.position = new Vector3(9.5f, 0f, 0f);
			}
			((MonoBehaviour)this).StartCoroutine(FollowPlayer());
		}
		else
		{
			((Behaviour)GameObject.Find("HallMonitorWallCollider").GetComponent<BoxCollider2D>()).enabled = false;
			((Component)this).transform.position = new Vector3(0f, 50f, 0f);
		}
	}

	private IEnumerator FollowPlayer()
	{
		while (EnvironmentController.currentRoom == Room.Hallway && !mShowedHallPass)
		{
			yield return null;
			if (!Mathf.Approximately(((Component)this).transform.position.y, ((Component)player).transform.position.y))
			{
				SetAnimation("walk");
				((Component)this).transform.position = Vector3.Lerp(((Component)this).transform.position, new Vector3(((Component)this).transform.position.x, ((Component)player).transform.position.y, 0f), 0.5f);
				SetDepth();
			}
			else if (!mIsMovingBack)
			{
				SetAnimation("idle");
			}
		}
		SetAnimation("idle");
	}

	private void ShowBathroomPass()
	{
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Expected O, but got Unknown
		if (EnvironmentController.Instance.ActionsLeft() == 1)
		{
			lastSelectedOption.DestinationID = 8;
			return;
		}
		mIsMovingBack = true;
		mShowedBathroomPass = true;
		SetAnimation("walk");
		SetDirection(setFlip: false);
		GameObject.Find("HallMonitorWallCollider").transform.position = new Vector3(9.5f, 0f, 0f);
		TweenSettingsExtensions.OnComplete<TweenerCore<Vector3, Vector3, VectorOptions>>(TweenSettingsExtensions.SetEase<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOMoveX(((Component)this).transform, 9.5f, 0.5f, false), (Ease)1), (TweenCallback)delegate
		{
			SetDirection(setFlip: true);
			SetAnimation("idle");
			mIsMovingBack = false;
		});
	}

	private void ShowHallPass()
	{
		if (EnvironmentController.Instance.ActionsLeft() == 1)
		{
			lastSelectedOption.DestinationID = 8;
			return;
		}
		mShowedHallPass = true;
		((Behaviour)GameObject.Find("HallMonitorWallCollider").GetComponent<BoxCollider2D>()).enabled = false;
	}

	private void UnscrewVent()
	{
		GameObject obj = GameObject.Find("AirVent");
		((Behaviour)obj.GetComponent<BoxCollider2D>()).enabled = false;
		ShortcutExtensions.DOLocalMoveY(obj.transform, 2f, 0.1f, false);
		TweenSettingsExtensions.SetDelay<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOLocalMoveX(obj.transform, -7.6f, 0.5f, false), 0.1f);
		((Behaviour)GameObject.Find("MonstermonCardAirVent").GetComponent<BoxCollider2D>()).enabled = true;
	}

	private void GetMonstermonCard()
	{
		player.SetInteractable(null);
		GameObject.Find("MonstermonCardAirVent").SetActive(false);
		player.GetItem(Item.TornadoFly);
		UnlockHint("Monstermon", 11);
	}

	public void EndHallway()
	{
		SetCurrentConversation(6);
		Interact();
	}

	public void SetEndCafeteria()
	{
		mDontEndCafeteria = true;
	}

	public void EndHallwayCafeteria()
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		if (!mDontEndCafeteria)
		{
			((Component)this).transform.position = new Vector3(14.12f, -0.82f, 0f);
			SetDepth();
			SetCurrentConversation(7);
			Interact();
		}
	}

	private void HeadBackToClass()
	{
		EnvironmentController.Instance.SetSpawnPoint(1);
		EnvironmentController.Instance.ChangeEnvironment(Room.Classroom1);
	}

	private void ForceToRecess()
	{
		EnvironmentController.Instance.ChangeEnvironment(Room.Recess);
	}

	private void SendToPrincipalBathroom()
	{
		EnvironmentController.Instance.ChangeEnvironment(Room.Office);
		Object.FindObjectOfType<Principal>().SetBathroom();
	}

	private void SendToPrincipalBathroomLily()
	{
		EnvironmentController.Instance.ChangeEnvironment(Room.Office);
		Object.FindObjectOfType<Principal>().SetBathroomLily();
	}

	private void SendToPrincipal()
	{
		EnvironmentController.Instance.ChangeEnvironment(Room.Office);
		Object.FindObjectOfType<Principal>().SetMonitor();
	}
}
