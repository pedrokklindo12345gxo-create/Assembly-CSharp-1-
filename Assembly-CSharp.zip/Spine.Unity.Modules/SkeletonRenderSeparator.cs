using System.Collections.Generic;
using Spine.Unity.MeshGeneration;
using UnityEngine;
using UnityEngine.Rendering;

namespace Spine.Unity.Modules;

[ExecuteInEditMode]
[HelpURL("https://github.com/pharan/spine-unity-docs/blob/master/SkeletonRenderSeparator.md")]
public class SkeletonRenderSeparator : MonoBehaviour
{
	public const int DefaultSortingOrderIncrement = 5;

	[SerializeField]
	protected SkeletonRenderer skeletonRenderer;

	private MeshRenderer mainMeshRenderer;

	public bool copyPropertyBlock;

	[Tooltip("Copies MeshRenderer flags into each parts renderer")]
	public bool copyMeshRendererFlags;

	public List<SkeletonPartsRenderer> partsRenderers = new List<SkeletonPartsRenderer>();

	private MaterialPropertyBlock copiedBlock;

	public SkeletonRenderer SkeletonRenderer
	{
		get
		{
			return skeletonRenderer;
		}
		set
		{
			if ((Object)(object)skeletonRenderer != (Object)null)
			{
				skeletonRenderer.GenerateMeshOverride -= HandleRender;
			}
			skeletonRenderer = value;
			((Behaviour)this).enabled = false;
		}
	}

	private void OnEnable()
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Expected O, but got Unknown
		//IL_0070: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)skeletonRenderer == (Object)null)
		{
			return;
		}
		if (copiedBlock == null)
		{
			copiedBlock = new MaterialPropertyBlock();
		}
		mainMeshRenderer = ((Component)skeletonRenderer).GetComponent<MeshRenderer>();
		skeletonRenderer.GenerateMeshOverride -= HandleRender;
		skeletonRenderer.GenerateMeshOverride += HandleRender;
		if (!copyMeshRendererFlags)
		{
			return;
		}
		LightProbeUsage lightProbeUsage = ((Renderer)mainMeshRenderer).lightProbeUsage;
		bool receiveShadows = ((Renderer)mainMeshRenderer).receiveShadows;
		for (int i = 0; i < partsRenderers.Count; i++)
		{
			SkeletonPartsRenderer skeletonPartsRenderer = partsRenderers[i];
			if (!((Object)(object)skeletonPartsRenderer == (Object)null))
			{
				MeshRenderer meshRenderer = skeletonPartsRenderer.MeshRenderer;
				((Renderer)meshRenderer).lightProbeUsage = lightProbeUsage;
				((Renderer)meshRenderer).receiveShadows = receiveShadows;
			}
		}
	}

	private void OnDisable()
	{
		if ((Object)(object)skeletonRenderer == (Object)null)
		{
			return;
		}
		skeletonRenderer.GenerateMeshOverride -= HandleRender;
		foreach (SkeletonPartsRenderer partsRenderer in partsRenderers)
		{
			partsRenderer.ClearMesh();
		}
	}

	private void HandleRender(SkeletonRenderer.SmartMesh.Instruction instruction)
	{
		int count = partsRenderers.Count;
		if (count <= 0)
		{
			return;
		}
		if (copyPropertyBlock)
		{
			((Renderer)mainMeshRenderer).GetPropertyBlock(copiedBlock);
		}
		ExposedList<SubmeshInstruction> submeshInstructions = instruction.submeshInstructions;
		SubmeshInstruction[] items = submeshInstructions.Items;
		int num = submeshInstructions.Count - 1;
		bool pmaVertexColors = skeletonRenderer.pmaVertexColors;
		int i = 0;
		SkeletonPartsRenderer skeletonPartsRenderer = partsRenderers[i];
		int j = 0;
		int startSubmesh = 0;
		for (; j <= num; j++)
		{
			if (items[j].forceSeparate || j == num)
			{
				skeletonPartsRenderer.MeshGenerator.PremultiplyVertexColors = pmaVertexColors;
				if (copyPropertyBlock)
				{
					skeletonPartsRenderer.SetPropertyBlock(copiedBlock);
				}
				skeletonPartsRenderer.RenderParts(instruction.submeshInstructions, startSubmesh, j + 1);
				startSubmesh = j + 1;
				i++;
				if (i >= count)
				{
					break;
				}
				skeletonPartsRenderer = partsRenderers[i];
			}
		}
		for (; i < count; i++)
		{
			partsRenderers[i].ClearMesh();
		}
	}
}
