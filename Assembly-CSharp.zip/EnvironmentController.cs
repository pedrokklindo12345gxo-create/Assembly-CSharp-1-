using System;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using Spine.Unity;
using TextFx;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class EnvironmentController : MonoBehaviour
{
	[Serializable]
	public class RoomScenario
	{
		public string name;

		public Room room;

		public UnityEvent startFunction;

		public UnityEvent endFunction;
	}

	public bool isSpanish;

	public Transform spanishCanvas;

	[HideInInspector]
	public bool waitForNextAction;

	public bool waitForNextTalk;

	public static EnvironmentController Instance;

	public Room startRoom;

	public static Room currentRoom;

	public Room furthestRoom;

	private Image mFaderPanel;

	private Dictionary<Room, GameObject> mRooms = new Dictionary<Room, GameObject>();

	private Dictionary<Room, int> mActions = new Dictionary<Room, int>();

	public RoomScenario[] roomList;

	private UIController mUI;

	private int mSpawnPoint;

	private NPCBehavior[] mStoredNPC = new NPCBehavior[12];

	private GameObject[] mStoreEnvironments;

	private bool mRingBell;

	private string mFileModifier = string.Empty;

	private IEnumerator endRoomCoroutine;

	private bool mWaitingForEnd;

	public string GetFileModifier()
	{
		return mFileModifier;
	}

	private void Awake()
	{
		if (PlayerPrefs.GetInt("SaveFile", 1) == 2)
		{
			mFileModifier = "2";
		}
		else
		{
			mFileModifier = string.Empty;
		}
		if (isSpanish)
		{
			((Component)Object.FindObjectOfType<UIController>()).gameObject.SetActive(false);
			((Component)spanishCanvas).gameObject.SetActive(true);
		}
		Instance = this;
		mUI = Object.FindObjectOfType<UIController>();
	}

	private void Start()
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		GetRooms();
		mFaderPanel = GameObject.Find("FaderPanel").GetComponent<Image>();
		((Graphic)mFaderPanel).color = Color.black;
		ChangeEnvironment(startRoom);
		mUI.SetActionsLeft(mActions[furthestRoom]);
	}

	public void GetRooms()
	{
		mRooms.Clear();
		InitializeActions();
		foreach (Room value in Enum.GetValues(typeof(Room)))
		{
			if (Object.op_Implicit((Object)(object)((Component)this).transform.Find(value.ToString())))
			{
				mRooms.Add(value, ((Component)((Component)this).transform.Find(value.ToString())).gameObject);
				if (mRooms[value].activeSelf)
				{
					startRoom = value;
				}
			}
		}
	}

	private void InitializeActions()
	{
		mActions.Clear();
		mActions.Add(Room.Bedroom, 3);
		mActions.Add(Room.SchoolYard, 5);
		mActions.Add(Room.Classroom1, 5);
		mActions.Add(Room.Office, 5);
		mActions.Add(Room.ClassroomLunch, 2);
		mActions.Add(Room.Cafeteria, 5);
		mActions.Add(Room.Recess, 5);
		mActions.Add(Room.Lair, 5);
		mActions.Add(Room.Classroom2, 1);
	}

	public void ChangeEnvironment(string r)
	{
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Expected O, but got Unknown
		Room cr = currentRoom;
		currentRoom = (Room)Enum.Parse(typeof(Room), r);
		if (cr == Room.None)
		{
			cr = currentRoom;
		}
		PlayerController.roomTransition = true;
		TweenSettingsExtensions.OnComplete<TweenerCore<Color, Color, ColorOptions>>(DOTweenModuleUI.DOFade(mFaderPanel, 1f, 1f), (TweenCallback)delegate
		{
			mRooms[cr].SetActive(false);
		});
		((MonoBehaviour)this).Invoke("SwitchRoom", 1.1f);
	}

	private void ChangeEnvironment()
	{
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Expected O, but got Unknown
		ChangeEnvironment(furthestRoom);
		PlayerController.roomTransition = true;
		TweenSettingsExtensions.OnComplete<TweenerCore<Color, Color, ColorOptions>>(DOTweenModuleUI.DOFade(mFaderPanel, 1f, 1f), new TweenCallback(SwitchRoom));
		mUI.SetActionsLeft(mActions[furthestRoom]);
	}

	public void ChangeEnvironment(Room r)
	{
		if (r != Room.None)
		{
			ChangeEnvironment(r.ToString());
		}
	}

	private IEnumerator ChangeEnvironmentReset(Room r)
	{
		PlayerController.roomTransition = true;
		DOTweenModuleUI.DOFade(mFaderPanel, 1f, 1f);
		currentRoom = r;
		yield return (object)new WaitForSeconds(1f);
		yield return null;
		GetRooms();
		yield return null;
		mRooms[r].SetActive(true);
		InitializeNPCs();
		InitializePlayerPos();
		DOTweenModuleUI.DOFade(mFaderPanel, 0f, 1f);
		yield return (object)new WaitForSeconds(0.25f);
		PlayerController.roomTransition = false;
		RoomScenario[] array = roomList;
		foreach (RoomScenario roomScenario in array)
		{
			if (furthestRoom == roomScenario.room)
			{
				((MonoBehaviour)this).StartCoroutine(InvokeStartFunction(roomScenario));
			}
		}
	}

	private void SwitchRoom()
	{
		waitForNextAction = false;
		waitForNextTalk = false;
		if (!Object.op_Implicit((Object)(object)mRooms[currentRoom]))
		{
			GetRooms();
		}
		mRooms[currentRoom].SetActive(true);
		InitializeNPCs();
		if (mSpawnPoint > 0)
		{
			InitializePlayerPos(mSpawnPoint);
		}
		else
		{
			InitializePlayerPos();
		}
		DOTweenModuleUI.DOFade(mFaderPanel, 0f, 1f);
		RoomScenario[] array = roomList;
		foreach (RoomScenario roomScenario in array)
		{
			if (currentRoom == roomScenario.room)
			{
				((MonoBehaviour)this).StartCoroutine(InvokeStartFunction(roomScenario));
			}
		}
	}

	private IEnumerator InvokeStartFunction(RoomScenario rs)
	{
		yield return null;
		rs.startFunction.Invoke();
		yield return null;
		PlayerController.roomTransition = false;
	}

	private void InitializeNPCs()
	{
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		NPCBehavior[] array = Object.FindObjectsOfType<NPCBehavior>();
		foreach (NPCBehavior nPCBehavior in array)
		{
			if (!nPCBehavior.removedFromGame && ((Object)((Component)nPCBehavior).transform).name != "Billy")
			{
				Transform val = mRooms[currentRoom].transform.Find("NPCPositions/" + ((Object)nPCBehavior).name + "Pos");
				((Component)nPCBehavior).transform.position = val.position;
				nPCBehavior.SetDirection(val.localScale.x < 0f);
				nPCBehavior.SetDepth();
			}
			else
			{
				((Component)nPCBehavior).transform.position = new Vector3(0f, 50f, 0f);
			}
		}
	}

	private void InitializePlayerPos()
	{
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		Transform val = mRooms[currentRoom].transform.Find("NPCPositions/PlayerPos");
		((Component)PlayerController.instance).transform.position = val.position;
		PlayerController.instance.ForceChangeDirection(val.localScale.x > 0f);
		PlayerController.instance.SetDepth();
		PlayerController.instance.SetInteractable(null);
	}

	private void InitializePlayerPos(int x)
	{
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		Transform val = mRooms[currentRoom].transform.Find("NPCPositions/PlayerPos" + x);
		((Component)PlayerController.instance).transform.position = val.position;
		PlayerController.instance.ForceChangeDirection(val.localScale.x > 0f);
		PlayerController.instance.SetDepth();
		PlayerController.instance.SetInteractable(null);
		mSpawnPoint = 0;
	}

	public void DecreaseActions()
	{
		if (mActions[furthestRoom] > 0)
		{
			if (waitForNextAction)
			{
				waitForNextAction = false;
			}
			mActions[furthestRoom]--;
			mUI.SetActionsLeft(mActions[furthestRoom]);
			if (mActions[furthestRoom] == 1 && (currentRoom == Room.Hallway || currentRoom == Room.Closet || currentRoom == Room.Bathroom))
			{
				RingBell();
				if ((currentRoom == Room.Hallway || currentRoom == Room.Bathroom) && furthestRoom == Room.Classroom1)
				{
					endRoomCoroutine = InvokeEndFunction(currentRoom);
					((MonoBehaviour)this).StartCoroutine(endRoomCoroutine);
				}
			}
			if (mActions[furthestRoom] == 0)
			{
				endRoomCoroutine = InvokeEndFunction(currentRoom);
				((MonoBehaviour)this).StartCoroutine(endRoomCoroutine);
			}
		}
		else
		{
			endRoomCoroutine = InvokeEndFunction(currentRoom);
			((MonoBehaviour)this).StartCoroutine(endRoomCoroutine);
		}
	}

	private IEnumerator InvokeEndFunction(Room r)
	{
		mWaitingForEnd = true;
		while (PlayerController.instance.inDialogue || PlayerController.instance.inAnim || mUI.IsDialogueOut() || mUI.dialogueTransitioning)
		{
			yield return null;
		}
		PlayerController.instance.inAnim = true;
		yield return (object)new WaitForSeconds(0.25f);
		PlayerController.instance.inAnim = false;
		if (!mWaitingForEnd)
		{
			yield break;
		}
		RoomScenario[] array = roomList;
		foreach (RoomScenario roomScenario in array)
		{
			if (roomScenario.room == r)
			{
				roomScenario.endFunction.Invoke();
				break;
			}
		}
	}

	public int ActionsLeft()
	{
		return mActions[furthestRoom];
	}

	public void SetSpawnPoint(int x)
	{
		mSpawnPoint = x;
	}

	public static void ShowHoleCover(bool x)
	{
		((Renderer)GameObject.Find("HoleCover").GetComponent<SpriteRenderer>()).enabled = x;
	}

	public void RingBell()
	{
		if (!mRingBell)
		{
			SFXManager.Instance.PlaySound("Bell");
			mRingBell = true;
		}
	}

	public void UpdateFurthestRoom()
	{
		mRingBell = false;
		if (furthestRoom != currentRoom)
		{
			mUI.CheckEnviornmentMissions();
			furthestRoom = currentRoom;
			mUI.SetActionsLeft(mActions[furthestRoom]);
			CreateRestartPoint();
		}
	}

	public void StartBedroom()
	{
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		SFXManager.Instance.PlayMusic("BedroomTheme");
		mUI.SetActionsLeft(mActions[furthestRoom]);
		PlayerController.instance.lockActions = true;
		((MonoBehaviour)this).StartCoroutine(BedroomCoroutine());
		UnlockableObject[] array = Object.FindObjectsOfType<UnlockableObject>();
		int num = 0;
		UnlockableObject[] array2 = array;
		foreach (UnlockableObject unlockableObject in array2)
		{
			if (((Object)((Component)unlockableObject).transform.parent).name.Contains("Cards") && unlockableObject.unlocked)
			{
				num++;
			}
		}
		PlayerPrefs.SetInt("UnlockedCards" + mFileModifier, num);
		if (num == 25)
		{
			GameObject obj = GameObject.Find("MonstermonComplete");
			((Behaviour)obj.GetComponent<BoxCollider2D>()).enabled = true;
			obj.GetComponent<SpriteRenderer>().color = Color.white;
		}
	}

	private IEnumerator BedroomCoroutine()
	{
		yield return (object)new WaitForSeconds(3f);
		if (PlayerPrefs.GetInt("ShowTutorial", 0) == 0)
		{
			PlayerController.instance.SetInteractable(GameObject.Find("Tutorial").GetComponent<ObjectInteractable>());
			GameObject.Find("Tutorial").GetComponent<ObjectInteractable>().Interact();
		}
		GameObject.Find("KindergartenTitle").GetComponent<TextFxUGUI>().AnimationManager.PlayAnimation();
		yield return (object)new WaitForSeconds(1.5f);
		SFXManager.Instance.PlaySound("Yay");
	}

	public void StartSchoolyard()
	{
		PlayerController.instance.lockActions = false;
		if (PlayerController.instance.money > 3f)
		{
			Object.FindObjectOfType<Buggs>().StealMoney();
		}
	}

	public void EndSchoolYard()
	{
		Object.FindObjectOfType<Teacher>().EndSchoolYard();
	}

	public void StartCS1()
	{
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		PlayerController.instance.lockActions = false;
		if (furthestRoom == Room.SchoolYard)
		{
			UpdateFurthestRoom();
		}
		Object.FindObjectOfType<Teacher>().StartClassroom();
		Object.FindObjectOfType<Jerome>().CheckTriedToLeave();
		Object.FindObjectOfType<Buggs>().CheckCallOverPlayer();
		Object.FindObjectOfType<Principal>().mPunishingBuggs = false;
		if (mUI.IsMissionActive(Mission.CindyPlayHouse) || mUI.IsMissionActive(Mission.CindyWashUp))
		{
			((Component)Object.FindObjectOfType<Cindy>()).transform.position = new Vector3(-19.65f, -12.1f, -12.09f);
		}
	}

	public void EndCS1()
	{
		Object.FindObjectOfType<Teacher>().EndClassroom1();
	}

	public void StartCafeteria()
	{
		UpdateFurthestRoom();
		Object.FindObjectOfType<Principal>().mPunishingBuggs = false;
		PlayerController.instance.lockActions = false;
		Object.FindObjectOfType<LunchLady>().CheckSendToRecess();
		Object.FindObjectOfType<Lily>().CheckLeaveCafeteria();
		Object.FindObjectOfType<Jerome>().InterceptCafeteria();
		Object.FindObjectOfType<Buggs>().CheckDeadInCafeteria();
	}

	public void EndCafeteria()
	{
		Object.FindObjectOfType<Nugget>().CheckPoison();
	}

	public void StartRecess()
	{
		UpdateFurthestRoom();
		PlayerController.instance.lockActions = false;
		Object.FindObjectOfType<Monty>().CheckDeath();
		Object.FindObjectOfType<Janitor>().CheckAppearAtRecess();
		Object.FindObjectOfType<Buggs>().CheckDeath();
		Object.FindObjectOfType<Teacher>().StartRecess();
		Object.FindObjectOfType<Nugget>().CheckEndWorld();
	}

	public void EndRecess()
	{
		if (mUI.IsMissionComplete(Mission.BuggsKillTeacher))
		{
			Object.FindObjectOfType<Janitor>().EndRecess();
		}
		else
		{
			Object.FindObjectOfType<Teacher>().EndRecess();
		}
	}

	public void StartCS2()
	{
		UpdateFurthestRoom();
		Object.FindObjectOfType<Teacher>().StartClassRoom2();
	}

	public void StartOffice()
	{
		PlayerController.instance.lockActions = true;
		if (furthestRoom == Room.SchoolYard)
		{
			UpdateFurthestRoom();
		}
		Object.FindObjectOfType<Principal>().StartPrincipal();
	}

	public void StartHallway()
	{
		Object.FindObjectOfType<HallMonitor>().StartFollowing();
		Object.FindObjectOfType<Lily>().CheckHallwayLilyStatus();
		Object.FindObjectOfType<Buggs>().CheckDeadInHallway();
		PlayerController.instance.lockActions = true;
		if (ActionsLeft() == 1)
		{
			RingBell();
			if (furthestRoom == Room.Classroom1 || furthestRoom == Room.Office)
			{
				Object.FindObjectOfType<HallMonitor>().EndHallway();
			}
		}
		if (furthestRoom == Room.Cafeteria)
		{
			GameObject.Find("JanitorHallwayDoor").GetComponent<ObjectInteractable>().startFunction = string.Empty;
			GameObject.Find("ClassRoomDoorHallway").GetComponent<ObjectInteractable>().startFunction = string.Empty;
			GameObject.Find("CafeteriaDoorHallway").GetComponent<ObjectInteractable>().startFunction = "EnterCafeteria";
		}
	}

	public void EndHallway()
	{
		if (furthestRoom == Room.Classroom1 || furthestRoom == Room.Office)
		{
			if (currentRoom == Room.Hallway)
			{
				Object.FindObjectOfType<HallMonitor>().EndHallway();
			}
		}
		else if (Object.FindObjectOfType<Nugget>().GetPoisonedPlayer())
		{
			Object.FindObjectOfType<Nugget>().CheckPoison();
		}
		else if (currentRoom == Room.Hallway)
		{
			Object.FindObjectOfType<HallMonitor>().EndHallwayCafeteria();
		}
	}

	public void StartCloset()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		Transform transform = GameObject.Find("StolenStuff").transform;
		((Component)transform).transform.localPosition = new Vector3(transform.localPosition.x, transform.localPosition.y, -18.45f);
		PlayerController.instance.lockActions = true;
		if (mUI.IsMissionActive(Mission.JeromeGoToCloset))
		{
			mUI.CompleteMission(Mission.JeromeGoToCloset);
			Object.FindObjectOfType<Jerome>().ActivateMission(Mission.JeromeGetLaserFromBox, Room.Classroom1);
		}
	}

	public void EndCloset()
	{
		Object.FindObjectOfType<Janitor>().AppearJanitor();
	}

	public void StartCSLunch()
	{
		PlayerController.instance.lockActions = false;
		Object.FindObjectOfType<Teacher>().Interact();
		UpdateFurthestRoom();
		if (mUI.IsMissionActive(Mission.BuggsGoToLunchWithTeacher))
		{
			Object.FindObjectOfType<Buggs>().CompleteMission(Mission.BuggsGoToLunchWithTeacher);
			Object.FindObjectOfType<Buggs>().ActivateMission(Mission.BuggsKillTeacher);
		}
	}

	public void EndCSLunch()
	{
		Object.FindObjectOfType<Teacher>().EndCSLunch();
	}

	public void StartBathroom()
	{
		Object.FindObjectOfType<HallMonitor>().CheckSmoking();
		PlayerController.instance.lockActions = true;
		if (mUI.IsMissionComplete(Mission.JeromeHideLaser))
		{
			GameObject obj = GameObject.Find("GarbageBag");
			((Behaviour)obj.GetComponent<BoxCollider2D>()).enabled = true;
			((Renderer)obj.GetComponent<SpriteRenderer>()).enabled = true;
		}
	}

	public void EndBathroom()
	{
		if (currentRoom != Room.Bathroom)
		{
			return;
		}
		if (furthestRoom == Room.Classroom1)
		{
			Object.FindObjectOfType<Janitor>().EndBathroom();
		}
		else if (!Object.FindObjectOfType<Nugget>().GetPoisonedPlayer())
		{
			if (mUI.IsMissionActive(Mission.JeromeGetLaserFromBathroom) || mUI.IsMissionComplete(Mission.JeromeGetLaserFromBathroom))
			{
				Object.FindObjectOfType<Janitor>().EndBathroomCafeteria();
			}
			else
			{
				Object.FindObjectOfType<HallMonitor>().EndBathroom();
			}
		}
		else
		{
			Object.FindObjectOfType<Nugget>().CheckPoison();
		}
	}

	public void StartNuggetCave()
	{
		PlayerController.instance.lockActions = true;
		Object.FindObjectOfType<Nugget>().CheckRemoveNuggetPiles();
	}

	public void EndNuggetCave()
	{
		Object.FindObjectOfType<Nugget>().EndNuggetCave();
	}

	public void EndBedroom()
	{
		PlayerController.instance.SetInteractable(GameObject.Find("GoToSchool").GetComponent<ObjectInteractable>());
		PlayerController.instance.GetInteractable().GetDialogue().GetCurrentNode()
			.DialogueText = "If I don't leave now, I'm gonna be late for school.";
		PlayerController.instance.GetInteractable().GetCurrentOptions()[0].OptionText = "(Go to school.)";
		PlayerController.instance.GetInteractable().GetCurrentOptions()[1].IsAvailable = false;
		GameObject.Find("GoToSchool").GetComponent<ObjectInteractable>().Interact();
	}

	public void StartEndDay()
	{
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		PlayerController.instance.inAnim = true;
		NPCBehavior[] array = Object.FindObjectsOfType<NPCBehavior>();
		foreach (NPCBehavior nPCBehavior in array)
		{
			((Component)nPCBehavior).transform.position = new Vector3(((Component)nPCBehavior).transform.position.x, ((Component)nPCBehavior).transform.position.y, 6f);
		}
		((MonoBehaviour)this).StartCoroutine(EndDayCoroutine());
	}

	public void StartLair()
	{
		UpdateFurthestRoom();
		PlayerController.instance.lockActions = true;
		SFXManager.Instance.PlayMusic("LairTheme");
		TweenSettingsExtensions.SetEase<TweenerCore<Vector3, Vector3, VectorOptions>>(TweenSettingsExtensions.SetLoops<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOLocalMoveY(GameObject.Find("Creature2").transform, 0.55f, 5f, false), -1, (LoopType)1), (Ease)1);
		TweenSettingsExtensions.SetDelay<TweenerCore<Vector3, Vector3, VectorOptions>>(TweenSettingsExtensions.SetEase<TweenerCore<Vector3, Vector3, VectorOptions>>(TweenSettingsExtensions.SetLoops<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOLocalMoveY(GameObject.Find("Creature1").transform, -0.55f, 5f, false), -1, (LoopType)1), (Ease)1), 0.5f);
		TweenSettingsExtensions.SetDelay<TweenerCore<Vector3, Vector3, VectorOptions>>(TweenSettingsExtensions.SetEase<TweenerCore<Vector3, Vector3, VectorOptions>>(TweenSettingsExtensions.SetLoops<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOLocalMoveY(GameObject.Find("Creature3").transform, -0.55f, 5f, false), -1, (LoopType)1), (Ease)1), 1f);
		Object.FindObjectOfType<Lily>().StartLair();
		Object.FindObjectOfType<Billy>().ResetLair();
	}

	public void EndLair()
	{
	}

	private IEnumerator EndDayCoroutine()
	{
		NPCBehavior[] kids = new NPCBehavior[6]
		{
			Object.FindObjectOfType<Jerome>(),
			Object.FindObjectOfType<Cindy>(),
			Object.FindObjectOfType<Monty>(),
			Object.FindObjectOfType<Buggs>(),
			Object.FindObjectOfType<Nugget>(),
			Object.FindObjectOfType<Lily>()
		};
		PlayerController p = PlayerController.instance;
		p.inAnim = true;
		NPCBehavior endKid = null;
		bool endDayScene = false;
		if (Object.FindObjectOfType<Lily>().GetEndDay())
		{
			((Component)Object.FindObjectOfType<Billy>()).transform.position = ((Component)Object.FindObjectOfType<Lily>()).transform.position;
			Teacher j = Object.FindObjectOfType<Teacher>();
			((MonoBehaviour)this).StartCoroutine(WalkAway(j));
			yield return (object)new WaitForSeconds(2f);
		}
		NPCBehavior[] array = kids;
		foreach (NPCBehavior nPCBehavior in array)
		{
			if (!nPCBehavior.removedFromGame)
			{
				((MonoBehaviour)this).StartCoroutine(WalkAway(nPCBehavior));
				if (nPCBehavior.GetEndDay())
				{
					endKid = nPCBehavior;
					endDayScene = true;
				}
				yield return (object)new WaitForSeconds(0.5f);
			}
		}
		if (Object.FindObjectOfType<Lily>().GetEndDay())
		{
			((MonoBehaviour)this).StartCoroutine(WalkAwayBilly());
			yield return (object)new WaitForSeconds(0.5f);
		}
		((Component)p).transform.position = new Vector3(24.2f, 1.2f, 6f);
		p.ForceAnim(walk: true);
		p.ForceChangeDirection(right: false);
		TweenSettingsExtensions.SetEase<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOMove(((Component)p).transform, new Vector3(19f, 0f, 6f), 1f, false), (Ease)1);
		yield return (object)new WaitForSeconds(1f);
		TweenSettingsExtensions.SetEase<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOMove(((Component)p).transform, new Vector3(16f, Random.Range(-1.5f, -0.25f), -1.14f), 0.5f, false), (Ease)1);
		yield return (object)new WaitForSeconds(0.5f);
		if (endDayScene)
		{
			TweenSettingsExtensions.SetEase<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOMove(((Component)p).transform, new Vector3(9.8f, -7.21f, -7.2f), 2.5f, false), (Ease)1);
			yield return (object)new WaitForSeconds(1.5f);
			((MonoBehaviour)this).StartCoroutine(endKid.EndDayCoroutine());
			yield return (object)new WaitForSeconds(1f);
			p.inAnim = false;
			p.ForceAnim(walk: false);
		}
		else
		{
			TweenSettingsExtensions.SetEase<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOMove(((Component)p).transform, new Vector3(-36f, Random.Range(-2f, -1.5f), -1.14f), 7f, false), (Ease)1);
			yield return (object)new WaitForSeconds(2f);
			mUI.CompleteDay(Item.None);
		}
	}

	private IEnumerator WalkAway(NPCBehavior j)
	{
		j.SetDirection(setFlip: false);
		j.WalkToPoint(new Vector3(19f, 0f, 6f), 0.75f, x: false);
		yield return (object)new WaitForSeconds(0.75f);
		j.WalkToPoint(new Vector3(16f, Random.Range(-1.5f, -0.25f), -1.14f), 0.5f, x: false);
		yield return (object)new WaitForSeconds(0.5f);
		if (j.GetEndDay())
		{
			j.WalkToPoint(new Vector3(6.23f, -7.21f, -7.2f), 2.5f, x: false);
			yield return (object)new WaitForSeconds(2.5f);
			j.SetDirection(setFlip: true);
		}
		else
		{
			j.WalkToPoint(new Vector3(-36f, Random.Range(-2f, -1.5f), -1.14f), 7f, x: false);
		}
	}

	private IEnumerator WalkAwayBilly()
	{
		Billy i = Object.FindObjectOfType<Billy>();
		i.SetDirection(setFlip: false);
		i.WalkToPoint(new Vector3(19f, 0f, 6f), 0.75f, x: false);
		yield return (object)new WaitForSeconds(0.75f);
		i.WalkToPoint(new Vector3(16f, Random.Range(-1.5f, -0.25f), -1.14f), 0.5f, x: false);
		yield return (object)new WaitForSeconds(0.5f);
		i.WalkToPoint(new Vector3(7.58f, -6.67f, -6.49f), 2.5f, x: false);
		yield return (object)new WaitForSeconds(2.5f);
		i.SetDirection(setFlip: true);
	}

	private void CreateRestartPoint()
	{
		PlayerController.instance.StorePlayerValues();
		StoreNpcStatus();
		mUI.StoreUI();
		StoreEnvironment();
	}

	public void RestartRoom()
	{
		mWaitingForEnd = false;
		((MonoBehaviour)this).StartCoroutine(ChangeEnvironmentReset(furthestRoom));
		((MonoBehaviour)this).StartCoroutine(RunRestartRoom());
	}

	private IEnumerator RunRestartRoom()
	{
		mUI.ResetUI();
		yield return (object)new WaitForSeconds(1f);
		GameObject obj = GameObject.Find("PrincipalShooting");
		((Renderer)obj.GetComponent<MeshRenderer>()).enabled = false;
		obj.GetComponent<SkeletonAnimation>().AnimationName = "idle";
		GameObject.Find("PlayerBloodStream").GetComponent<ParticleSystem>().Stop();
		SFXManager.Instance.RestartMusic();
		mUI.ForceResetUI();
		PlayerController.instance.ResetPlayerValues();
		Object.FindObjectOfType<CameraFollow>().overrideCamera = false;
		RestoreEnvironments();
		RestoreNPCs();
		yield return null;
		StoreEnvironment();
	}

	private void StoreEnvironment()
	{
		mStoreEnvironments = (GameObject[])(object)new GameObject[((Component)this).transform.childCount];
		for (int i = 0; i < ((Component)this).transform.childCount; i++)
		{
			mStoreEnvironments[i] = Object.Instantiate<GameObject>(((Component)((Component)this).transform.GetChild(i)).gameObject);
			((Object)mStoreEnvironments[i]).name = ((Object)((Component)this).transform.GetChild(i)).name;
			mStoreEnvironments[i].SetActive(false);
		}
	}

	private void RestoreEnvironments()
	{
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0079: Unknown result type (might be due to invalid IL or missing references)
		foreach (Transform item in ((Component)this).transform)
		{
			Object.Destroy((Object)(object)((Component)item).gameObject);
		}
		GameObject[] array = mStoreEnvironments;
		foreach (GameObject obj in array)
		{
			obj.SetActive(true);
			obj.transform.parent = ((Component)this).transform;
			obj.transform.localPosition = new Vector3(0f, -3.6f, 0f);
			obj.SetActive(false);
		}
		GetRooms();
		mUI.SetActionsLeft(mActions[furthestRoom]);
	}

	private void RestoreNPCs()
	{
		NPCBehavior[] array = Object.FindObjectsOfType<NPCBehavior>();
		for (int i = 0; i < array.Length; i++)
		{
			Object.Destroy((Object)(object)((Component)array[i]).gameObject);
		}
		array = mStoredNPC;
		foreach (NPCBehavior nPCBehavior in array)
		{
			((Component)nPCBehavior).gameObject.SetActive(true);
			NPCBehavior nPCBehavior2 = Object.Instantiate<NPCBehavior>(nPCBehavior);
			((Object)((Component)nPCBehavior2).transform).name = ((Object)((Component)nPCBehavior).transform).name;
			nPCBehavior2.ApplyTextureBlock(nPCBehavior.currentTextureBlock);
			nPCBehavior2.CloneConversations(nPCBehavior.conversations);
			((Component)nPCBehavior).gameObject.SetActive(false);
		}
	}

	private void StoreNpcStatus()
	{
		NPCBehavior[] array = Object.FindObjectsOfType<NPCBehavior>();
		for (int i = 0; i < mStoredNPC.Length; i++)
		{
			if (Object.op_Implicit((Object)(object)mStoredNPC[i]))
			{
				Object.Destroy((Object)(object)((Component)mStoredNPC[i]).gameObject);
			}
		}
		for (int j = 0; j < mStoredNPC.Length; j++)
		{
			mStoredNPC[j] = Object.Instantiate<NPCBehavior>(array[j]);
			mStoredNPC[j].CloneConversations(array[j].conversations);
			((Object)((Component)mStoredNPC[j]).transform).name = ((Object)((Component)array[j]).transform).name;
			mStoredNPC[j].ApplyTextureBlock(array[j].currentTextureBlock);
			((Component)mStoredNPC[j]).gameObject.SetActive(false);
		}
	}
}
