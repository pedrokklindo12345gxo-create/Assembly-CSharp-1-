using System;
using System.Collections.Generic;
using UnityEngine;

namespace Spine.Unity.Modules;

[ExecuteInEditMode]
public class SkeletonRendererCustomMaterials : MonoBehaviour
{
	[Serializable]
	public struct SlotMaterialOverride : IEquatable<SlotMaterialOverride>
	{
		public bool overrideDisabled;

		[SpineSlot("", "", false)]
		public string slotName;

		public Material material;

		public bool Equals(SlotMaterialOverride other)
		{
			if (overrideDisabled == other.overrideDisabled && slotName == other.slotName)
			{
				return (Object)(object)material == (Object)(object)other.material;
			}
			return false;
		}
	}

	[Serializable]
	public struct AtlasMaterialOverride : IEquatable<AtlasMaterialOverride>
	{
		public bool overrideDisabled;

		public Material originalMaterial;

		public Material replacementMaterial;

		public bool Equals(AtlasMaterialOverride other)
		{
			if (overrideDisabled == other.overrideDisabled && (Object)(object)originalMaterial == (Object)(object)other.originalMaterial)
			{
				return (Object)(object)replacementMaterial == (Object)(object)other.replacementMaterial;
			}
			return false;
		}
	}

	public SkeletonRenderer skeletonRenderer;

	[SerializeField]
	protected List<SlotMaterialOverride> customSlotMaterials = new List<SlotMaterialOverride>();

	[SerializeField]
	protected List<AtlasMaterialOverride> customMaterialOverrides = new List<AtlasMaterialOverride>();

	private void SetCustomSlotMaterials()
	{
		if ((Object)(object)skeletonRenderer == (Object)null)
		{
			Debug.LogError((object)"skeletonRenderer == null");
			return;
		}
		for (int i = 0; i < customSlotMaterials.Count; i++)
		{
			SlotMaterialOverride slotMaterialOverride = customSlotMaterials[i];
			if (!slotMaterialOverride.overrideDisabled && !string.IsNullOrEmpty(slotMaterialOverride.slotName))
			{
				Slot key = skeletonRenderer.skeleton.FindSlot(slotMaterialOverride.slotName);
				skeletonRenderer.CustomSlotMaterials[key] = slotMaterialOverride.material;
			}
		}
	}

	private void RemoveCustomSlotMaterials()
	{
		if ((Object)(object)skeletonRenderer == (Object)null)
		{
			Debug.LogError((object)"skeletonRenderer == null");
			return;
		}
		for (int i = 0; i < customSlotMaterials.Count; i++)
		{
			SlotMaterialOverride slotMaterialOverride = customSlotMaterials[i];
			if (!string.IsNullOrEmpty(slotMaterialOverride.slotName))
			{
				Slot key = skeletonRenderer.skeleton.FindSlot(slotMaterialOverride.slotName);
				if (skeletonRenderer.CustomSlotMaterials.TryGetValue(key, out var value) && !((Object)(object)value != (Object)(object)slotMaterialOverride.material))
				{
					skeletonRenderer.CustomSlotMaterials.Remove(key);
				}
			}
		}
	}

	private void SetCustomMaterialOverrides()
	{
		if ((Object)(object)skeletonRenderer == (Object)null)
		{
			Debug.LogError((object)"skeletonRenderer == null");
			return;
		}
		for (int i = 0; i < customMaterialOverrides.Count; i++)
		{
			AtlasMaterialOverride atlasMaterialOverride = customMaterialOverrides[i];
			if (!atlasMaterialOverride.overrideDisabled)
			{
				skeletonRenderer.CustomMaterialOverride[atlasMaterialOverride.originalMaterial] = atlasMaterialOverride.replacementMaterial;
			}
		}
	}

	private void RemoveCustomMaterialOverrides()
	{
		if ((Object)(object)skeletonRenderer == (Object)null)
		{
			Debug.LogError((object)"skeletonRenderer == null");
			return;
		}
		for (int i = 0; i < customMaterialOverrides.Count; i++)
		{
			AtlasMaterialOverride atlasMaterialOverride = customMaterialOverrides[i];
			if (skeletonRenderer.CustomMaterialOverride.TryGetValue(atlasMaterialOverride.originalMaterial, out var value) && !((Object)(object)value != (Object)(object)atlasMaterialOverride.replacementMaterial))
			{
				skeletonRenderer.CustomMaterialOverride.Remove(atlasMaterialOverride.originalMaterial);
			}
		}
	}

	private void OnEnable()
	{
		if ((Object)(object)skeletonRenderer == (Object)null)
		{
			skeletonRenderer = ((Component)this).GetComponent<SkeletonRenderer>();
		}
		if ((Object)(object)skeletonRenderer == (Object)null)
		{
			Debug.LogError((object)"skeletonRenderer == null");
			return;
		}
		skeletonRenderer.Initialize(overwrite: false);
		SetCustomMaterialOverrides();
		SetCustomSlotMaterials();
	}

	private void OnDisable()
	{
		if ((Object)(object)skeletonRenderer == (Object)null)
		{
			Debug.LogError((object)"skeletonRenderer == null");
			return;
		}
		RemoveCustomMaterialOverrides();
		RemoveCustomSlotMaterials();
	}
}
