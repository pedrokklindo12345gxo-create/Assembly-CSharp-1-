using System;
using UnityEngine;
using UnityEngine.Serialization;

namespace Spine.Unity;

[ExecuteInEditMode]
[AddComponentMenu("Spine/BoneFollower")]
public class BoneFollower : MonoBehaviour
{
	public SkeletonRenderer skeletonRenderer;

	[SpineBone("", "skeletonRenderer")]
	public string boneName;

	public Vector3 offset;

	public float offsetRotation;

	public bool followZPosition = true;

	public bool followBoneRotation = true;

	[Tooltip("Follows the skeleton's flip state by controlling this Transform's local scale.")]
	public bool followSkeletonFlip;

	[FormerlySerializedAs("resetOnAwake")]
	public bool initializeOnAwake = true;

	[NonSerialized]
	public bool valid;

	[NonSerialized]
	public Bone bone;

	private Transform skeletonTransform;

	public SkeletonRenderer SkeletonRenderer
	{
		get
		{
			return skeletonRenderer;
		}
		set
		{
			skeletonRenderer = value;
			Initialize();
		}
	}

	public void Awake()
	{
		if (initializeOnAwake)
		{
			Initialize();
		}
	}

	public void HandleRebuildRenderer(SkeletonRenderer skeletonRenderer)
	{
		Initialize();
	}

	public void Initialize()
	{
		bone = null;
		valid = (Object)(object)skeletonRenderer != (Object)null && skeletonRenderer.valid;
		if (valid)
		{
			skeletonTransform = ((Component)skeletonRenderer).transform;
			SkeletonRenderer obj = skeletonRenderer;
			obj.OnRebuild = (SkeletonRenderer.SkeletonRendererDelegate)Delegate.Remove(obj.OnRebuild, new SkeletonRenderer.SkeletonRendererDelegate(HandleRebuildRenderer));
			SkeletonRenderer obj2 = skeletonRenderer;
			obj2.OnRebuild = (SkeletonRenderer.SkeletonRendererDelegate)Delegate.Combine(obj2.OnRebuild, new SkeletonRenderer.SkeletonRendererDelegate(HandleRebuildRenderer));
		}
	}

	private void OnDestroy()
	{
		if ((Object)(object)skeletonRenderer != (Object)null)
		{
			SkeletonRenderer obj = skeletonRenderer;
			obj.OnRebuild = (SkeletonRenderer.SkeletonRendererDelegate)Delegate.Remove(obj.OnRebuild, new SkeletonRenderer.SkeletonRendererDelegate(HandleRebuildRenderer));
		}
	}

	public void LateUpdate()
	{
		//IL_0235: Unknown result type (might be due to invalid IL or missing references)
		//IL_023b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0240: Unknown result type (might be due to invalid IL or missing references)
		//IL_0245: Unknown result type (might be due to invalid IL or missing references)
		//IL_024a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0256: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_0280: Unknown result type (might be due to invalid IL or missing references)
		//IL_029c: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0184: Unknown result type (might be due to invalid IL or missing references)
		//IL_018a: Unknown result type (might be due to invalid IL or missing references)
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_02db: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_03da: Unknown result type (might be due to invalid IL or missing references)
		//IL_038b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0391: Unknown result type (might be due to invalid IL or missing references)
		//IL_039d: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0347: Unknown result type (might be due to invalid IL or missing references)
		//IL_034d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0359: Unknown result type (might be due to invalid IL or missing references)
		//IL_035e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0361: Unknown result type (might be due to invalid IL or missing references)
		//IL_037e: Unknown result type (might be due to invalid IL or missing references)
		//IL_02fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0300: Unknown result type (might be due to invalid IL or missing references)
		//IL_030c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0311: Unknown result type (might be due to invalid IL or missing references)
		//IL_0314: Unknown result type (might be due to invalid IL or missing references)
		//IL_0337: Unknown result type (might be due to invalid IL or missing references)
		//IL_0205: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0424: Unknown result type (might be due to invalid IL or missing references)
		if (!valid)
		{
			Initialize();
			return;
		}
		if (bone == null)
		{
			if (string.IsNullOrEmpty(boneName))
			{
				return;
			}
			bone = skeletonRenderer.skeleton.FindBone(boneName);
			if (bone == null)
			{
				Debug.LogError((object)("Bone not found: " + boneName), (Object)(object)this);
				return;
			}
		}
		Transform transform = ((Component)this).transform;
		if ((Object)(object)transform.parent == (Object)(object)skeletonTransform)
		{
			if (followSkeletonFlip)
			{
				if (!bone.skeleton.flipX)
				{
					transform.localPosition = new Vector3(bone.worldX, bone.worldY, (!followZPosition) ? transform.localPosition.z : 0f) + offset;
				}
				else
				{
					transform.localPosition = new Vector3(bone.worldX, bone.worldY, (!followZPosition) ? transform.localPosition.z : 0f) + new Vector3(0f - offset.x, offset.y, offset.z);
				}
			}
			else
			{
				transform.localPosition = new Vector3(bone.worldX, bone.worldY, (!followZPosition) ? transform.localPosition.z : 0f) + offset;
			}
			if (followBoneRotation)
			{
				if (!bone.skeleton.flipX)
				{
					transform.localRotation = Quaternion.Euler(0f, 0f, bone.WorldRotationX + offsetRotation);
				}
				else
				{
					transform.localRotation = Quaternion.Euler(0f, 0f, bone.WorldRotationX + offsetRotation - 45f);
				}
			}
		}
		else
		{
			Vector3 val = skeletonTransform.TransformPoint(new Vector3(bone.worldX, bone.worldY, 0f) + offset);
			if (!followZPosition)
			{
				val.z = transform.position.z;
			}
			if (followSkeletonFlip)
			{
				if (bone.skeleton.flipX)
				{
					transform.position = val - new Vector3(2f * offset.x, 0f, 0f);
				}
				else
				{
					transform.position = val;
				}
			}
			else
			{
				transform.position = val;
			}
			if (followBoneRotation)
			{
				Quaternion rotation = skeletonTransform.rotation;
				Vector3 eulerAngles = ((Quaternion)(ref rotation)).eulerAngles;
				if (followSkeletonFlip)
				{
					if (bone.skeleton.flipX)
					{
						float x = eulerAngles.x;
						float y = eulerAngles.y;
						rotation = skeletonTransform.rotation;
						transform.rotation = Quaternion.Euler(x, y, ((Quaternion)(ref rotation)).eulerAngles.z + bone.WorldRotationX + offsetRotation - 45f);
					}
					else
					{
						float x2 = eulerAngles.x;
						float y2 = eulerAngles.y;
						rotation = skeletonTransform.rotation;
						transform.rotation = Quaternion.Euler(x2, y2, ((Quaternion)(ref rotation)).eulerAngles.z + bone.WorldRotationX + offsetRotation);
					}
				}
				else
				{
					float x3 = eulerAngles.x;
					float y3 = eulerAngles.y;
					rotation = skeletonTransform.rotation;
					transform.rotation = Quaternion.Euler(x3, y3, ((Quaternion)(ref rotation)).eulerAngles.z + bone.WorldRotationX + offsetRotation);
				}
			}
		}
		if (followSkeletonFlip && offset == Vector3.zero)
		{
			float num = ((!(bone.skeleton.flipX ^ bone.skeleton.flipY)) ? 1f : (-1f));
			transform.localScale = new Vector3(1f, num, 1f);
		}
	}
}
