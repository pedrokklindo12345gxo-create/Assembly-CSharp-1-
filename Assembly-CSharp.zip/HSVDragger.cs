using UnityEngine;
using UnityEngine.UI;

public class HSVDragger : MonoBehaviour
{
	public RectTransform parentPanel;

	[HideInInspector]
	public RectTransform rectTransform;

	public ScrollRect scrollRect;

	public HSVPicker picker;

	private void Awake()
	{
		rectTransform = ((Component)this).GetComponent<RectTransform>();
	}

	private void Update()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		Vector3 localPosition = ((Transform)rectTransform).localPosition;
		localPosition.x = Mathf.Clamp(localPosition.x, (0f - parentPanel.sizeDelta.x) / 2f, parentPanel.sizeDelta.x / 2f);
		localPosition.y = Mathf.Clamp(localPosition.y, (0f - parentPanel.sizeDelta.y) / 2f, parentPanel.sizeDelta.y / 2f);
		((Transform)rectTransform).localPosition = localPosition;
		localPosition.x += parentPanel.sizeDelta.x / 2f;
		localPosition.y += parentPanel.sizeDelta.y / 2f;
		localPosition.x /= parentPanel.sizeDelta.x;
		localPosition.y /= parentPanel.sizeDelta.y;
	}

	public void ScrollValueChanged(Vector2 value)
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_010c: Unknown result type (might be due to invalid IL or missing references)
		//IL_011e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		//IL_012b: Unknown result type (might be due to invalid IL or missing references)
		Vector3 localPosition = ((Transform)rectTransform).localPosition;
		localPosition.x = Mathf.Clamp(localPosition.x, (0f - parentPanel.sizeDelta.x) / 2f, parentPanel.sizeDelta.x / 2f);
		localPosition.y = Mathf.Clamp(localPosition.y, (0f - parentPanel.sizeDelta.y) / 2f, parentPanel.sizeDelta.y / 2f);
		((Transform)rectTransform).localPosition = localPosition;
		localPosition.x += parentPanel.sizeDelta.x / 2f;
		localPosition.y += parentPanel.sizeDelta.y / 2f;
		localPosition.x /= parentPanel.sizeDelta.x;
		localPosition.y /= parentPanel.sizeDelta.y;
		picker.MoveCursor(localPosition.x, localPosition.y);
	}

	public void SetSelectorPosition(float posX, float posY)
	{
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		Vector3 localPosition = default(Vector3);
		((Vector3)(ref localPosition))._002Ector(posX, posY, ((Transform)rectTransform).localPosition.z);
		localPosition.x *= parentPanel.sizeDelta.x;
		localPosition.y *= parentPanel.sizeDelta.y;
		localPosition.x -= parentPanel.sizeDelta.x / 2f;
		localPosition.y -= parentPanel.sizeDelta.y / 2f;
		((Transform)rectTransform).localPosition = localPosition;
	}
}
