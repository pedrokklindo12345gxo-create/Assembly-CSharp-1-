using TouchControlsKit;
using UnityEngine;

namespace Examples;

public class TwoDPlayerControl : MonoBehaviour
{
	public float moveForce = 365f;

	public float maxSpeed = 5f;

	public float jumpForce = 1000f;

	private bool jump;

	private Transform groundCheck;

	private bool grounded;

	private Animator anim;

	private Rigidbody2D m_Rigidbody2D;

	internal bool facingRight { get; private set; }

	private void Awake()
	{
		facingRight = true;
		groundCheck = ((Component)this).transform.Find("groundCheck");
		anim = ((Component)this).GetComponent<Animator>();
		m_Rigidbody2D = ((Component)this).GetComponent<Rigidbody2D>();
	}

	private void Update()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		grounded = RaycastHit2D.op_Implicit(Physics2D.Linecast(Vector2.op_Implicit(((Component)this).transform.position), Vector2.op_Implicit(groundCheck.position), 1 << LayerMask.NameToLayer("Default")));
		if (TCKInput.GetButtonDown("jumpButton") && grounded)
		{
			jump = true;
		}
	}

	private void FixedUpdate()
	{
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0124: Unknown result type (might be due to invalid IL or missing references)
		float axis = TCKInput.GetAxis("DPad", AxisType.X);
		axis = Mathf.Clamp(axis, -1f, 1f);
		anim.SetFloat("Speed", Mathf.Abs(axis));
		if (axis * m_Rigidbody2D.velocity.x < maxSpeed)
		{
			m_Rigidbody2D.AddForce(Vector2.right * axis * moveForce);
		}
		if (Mathf.Abs(m_Rigidbody2D.velocity.x) > maxSpeed)
		{
			m_Rigidbody2D.velocity = new Vector2(Mathf.Sign(m_Rigidbody2D.velocity.x) * maxSpeed, m_Rigidbody2D.velocity.y);
		}
		if (axis > 0f && !facingRight)
		{
			Flip();
		}
		else if (axis < 0f && facingRight)
		{
			Flip();
		}
		if (jump)
		{
			anim.SetTrigger("Jump");
			m_Rigidbody2D.AddForce(new Vector2(0f, jumpForce * 1.5f));
			jump = false;
		}
	}

	private void Flip()
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		facingRight = !facingRight;
		Vector3 localScale = ((Component)this).transform.localScale;
		localScale.x *= -1f;
		((Component)this).transform.localScale = localScale;
	}
}
