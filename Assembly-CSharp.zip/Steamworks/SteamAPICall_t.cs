using System;

namespace Steamworks;

[Serializable]
public struct SteamAPICall_t : IEquatable<SteamAPICall_t>, IComparable<SteamAPICall_t>
{
	public static readonly SteamAPICall_t Invalid = new SteamAPICall_t(0uL);

	public ulong m_SteamAPICall;

	public SteamAPICall_t(ulong value)
	{
		m_SteamAPICall = value;
	}

	public override string ToString()
	{
		return m_SteamAPICall.ToString();
	}

	public override bool Equals(object other)
	{
		if (other is SteamAPICall_t)
		{
			return this == (SteamAPICall_t)other;
		}
		return false;
	}

	public override int GetHashCode()
	{
		return m_SteamAPICall.GetHashCode();
	}

	public static bool operator ==(SteamAPICall_t x, SteamAPICall_t y)
	{
		return x.m_SteamAPICall == y.m_SteamAPICall;
	}

	public static bool operator !=(SteamAPICall_t x, SteamAPICall_t y)
	{
		return !(x == y);
	}

	public static explicit operator SteamAPICall_t(ulong value)
	{
		return new SteamAPICall_t(value);
	}

	public static explicit operator ulong(SteamAPICall_t that)
	{
		return that.m_SteamAPICall;
	}

	public bool Equals(SteamAPICall_t other)
	{
		return m_SteamAPICall == other.m_SteamAPICall;
	}

	public int CompareTo(SteamAPICall_t other)
	{
		return m_SteamAPICall.CompareTo(other.m_SteamAPICall);
	}
}
