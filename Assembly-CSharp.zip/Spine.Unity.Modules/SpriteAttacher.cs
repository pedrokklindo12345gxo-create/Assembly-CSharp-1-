using System.Collections.Generic;
using Spine.Unity.Modules.AttachmentTools;
using UnityEngine;

namespace Spine.Unity.Modules;

public class SpriteAttacher : MonoBehaviour
{
	public const string DefaultPMAShader = "Spine/Skeleton";

	public const string DefaultStraightAlphaShader = "Sprites/Default";

	public bool attachOnStart = true;

	public Sprite sprite;

	[SpineSlot("", "", false)]
	public string slot;

	private RegionAttachment attachment;

	private bool applyPMA;

	private static Dictionary<Texture, AtlasPage> atlasPageCache;

	private static AtlasPage GetPageFor(Texture texture, Shader shader)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Expected O, but got Unknown
		if (atlasPageCache == null)
		{
			atlasPageCache = new Dictionary<Texture, AtlasPage>();
		}
		atlasPageCache.TryGetValue(texture, out var value);
		if (value == null)
		{
			value = SpriteAtlasRegionExtensions.ToSpineAtlasPage(new Material(shader));
			atlasPageCache[texture] = value;
		}
		return value;
	}

	private void Start()
	{
		if (attachOnStart)
		{
			Attach();
		}
	}

	public void Attach()
	{
		ISkeletonComponent component = ((Component)this).GetComponent<ISkeletonComponent>();
		SkeletonRenderer skeletonRenderer = component as SkeletonRenderer;
		if ((Object)(object)skeletonRenderer != (Object)null)
		{
			applyPMA = skeletonRenderer.pmaVertexColors;
		}
		else
		{
			SkeletonGraphic skeletonGraphic = component as SkeletonGraphic;
			if ((Object)(object)skeletonGraphic != (Object)null)
			{
				applyPMA = skeletonGraphic.SpineMeshGenerator.PremultiplyVertexColors;
			}
		}
		Shader shader = ((!applyPMA) ? Shader.Find("Sprites/Default") : Shader.Find("Spine/Skeleton"));
		attachment = ((!applyPMA) ? sprite.ToRegionAttachment(GetPageFor((Texture)(object)sprite.texture, shader)) : sprite.ToRegionAttachmentPMAClone(shader, (TextureFormat)4));
		component.Skeleton.FindSlot(slot).Attachment = attachment;
	}
}
