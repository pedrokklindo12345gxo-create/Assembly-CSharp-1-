using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace Spine.Unity.Modules;

[RequireComponent(typeof(SkeletonRenderer))]
public class SkeletonRagdoll : MonoBehaviour
{
	public class LayerFieldAttribute : PropertyAttribute
	{
	}

	private static Transform parentSpaceHelper;

	[Header("Hierarchy")]
	[SpineBone("", "")]
	public string startingBoneName = string.Empty;

	[SpineBone("", "")]
	public List<string> stopBoneNames = new List<string>();

	[Header("Parameters")]
	public bool applyOnStart;

	[Tooltip("Warning!  You will have to re-enable and tune mix values manually if attempting to remove the ragdoll system.")]
	public bool disableIK = true;

	public bool disableOtherConstraints;

	[Space(18f)]
	[Tooltip("Set RootRigidbody IsKinematic to true when Apply is called.")]
	public bool pinStartBone;

	[Tooltip("Enable Collision between adjacent ragdoll elements (IE: Neck and Head)")]
	public bool enableJointCollision;

	public bool useGravity = true;

	[Tooltip("If no BoundingBox Attachment is attached to a bone, this becomes the default Width or Radius of a Bone's ragdoll Rigidbody")]
	public float thickness = 0.125f;

	[Tooltip("Default rotational limit value.  Min is negative this value, Max is this value.")]
	public float rotationLimit = 20f;

	public float rootMass = 20f;

	[Tooltip("If your ragdoll seems unstable or uneffected by limits, try lowering this value.")]
	[Range(0.01f, 1f)]
	public float massFalloffFactor = 0.4f;

	[Tooltip("The layer assigned to all of the rigidbody parts.")]
	public int colliderLayer;

	[Range(0f, 1f)]
	public float mix = 1f;

	private ISkeletonAnimation targetSkeletonComponent;

	private Skeleton skeleton;

	private Dictionary<Bone, Transform> boneTable = new Dictionary<Bone, Transform>();

	private Transform ragdollRoot;

	private Vector3 rootOffset;

	private bool isActive;

	public Rigidbody RootRigidbody { get; private set; }

	public Bone StartingBone { get; private set; }

	public Vector3 RootOffset => rootOffset;

	public bool IsActive => isActive;

	public Rigidbody[] RigidbodyArray
	{
		get
		{
			if (!isActive)
			{
				return (Rigidbody[])(object)new Rigidbody[0];
			}
			Rigidbody[] array = (Rigidbody[])(object)new Rigidbody[boneTable.Count];
			int num = 0;
			foreach (Transform value in boneTable.Values)
			{
				array[num] = ((Component)value).GetComponent<Rigidbody>();
				num++;
			}
			return array;
		}
	}

	public Vector3 EstimatedSkeletonPosition => RootRigidbody.position - rootOffset;

	private IEnumerator Start()
	{
		if ((Object)(object)parentSpaceHelper == (Object)null)
		{
			parentSpaceHelper = new GameObject("Parent Space Helper").transform;
			((Object)parentSpaceHelper).hideFlags = (HideFlags)1;
		}
		targetSkeletonComponent = ((Component)this).GetComponent<SkeletonRenderer>() as ISkeletonAnimation;
		if (targetSkeletonComponent == null)
		{
			Debug.LogError((object)"Attached Spine component does not implement ISkeletonAnimation. This script is not compatible.");
		}
		skeleton = targetSkeletonComponent.Skeleton;
		if (applyOnStart)
		{
			yield return null;
			Apply();
		}
	}

	public void Apply()
	{
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_015d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0183: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_012e: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_01fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_0203: Unknown result type (might be due to invalid IL or missing references)
		//IL_0217: Unknown result type (might be due to invalid IL or missing references)
		//IL_0220: Unknown result type (might be due to invalid IL or missing references)
		//IL_024d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0273: Unknown result type (might be due to invalid IL or missing references)
		//IL_0198: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ad: Unknown result type (might be due to invalid IL or missing references)
		isActive = true;
		mix = 1f;
		StartingBone = skeleton.FindBone(startingBoneName);
		RecursivelyCreateBoneProxies(StartingBone);
		RootRigidbody = ((Component)boneTable[StartingBone]).GetComponent<Rigidbody>();
		RootRigidbody.isKinematic = pinStartBone;
		RootRigidbody.mass = rootMass;
		List<Collider> list = new List<Collider>();
		foreach (KeyValuePair<Bone, Transform> item in boneTable)
		{
			Bone key = item.Key;
			Transform value = item.Value;
			list.Add(((Component)value).GetComponent<Collider>());
			Transform val;
			if (key == StartingBone)
			{
				ragdollRoot = new GameObject("RagdollRoot").transform;
				ragdollRoot.SetParent(((Component)this).transform, false);
				if (key == skeleton.RootBone)
				{
					ragdollRoot.localPosition = new Vector3(key.WorldX, key.WorldY, 0f);
					ragdollRoot.localRotation = Quaternion.Euler(0f, 0f, GetPropagatedRotation(key));
				}
				else
				{
					ragdollRoot.localPosition = new Vector3(key.Parent.WorldX, key.Parent.WorldY, 0f);
					ragdollRoot.localRotation = Quaternion.Euler(0f, 0f, GetPropagatedRotation(key.Parent));
				}
				val = ragdollRoot;
				rootOffset = value.position - ((Component)this).transform.position;
			}
			else
			{
				val = boneTable[key.Parent];
			}
			Rigidbody component = ((Component)val).GetComponent<Rigidbody>();
			if ((Object)(object)component != (Object)null)
			{
				HingeJoint val2 = ((Component)value).gameObject.AddComponent<HingeJoint>();
				((Joint)val2).connectedBody = component;
				Vector3 connectedAnchor = val.InverseTransformPoint(value.position);
				connectedAnchor.x *= 1f;
				((Joint)val2).connectedAnchor = connectedAnchor;
				((Joint)val2).axis = Vector3.forward;
				((Component)val2).GetComponent<Rigidbody>().mass = ((Joint)val2).connectedBody.mass * massFalloffFactor;
				JointLimits limits = default(JointLimits);
				((JointLimits)(ref limits)).min = 0f - rotationLimit;
				((JointLimits)(ref limits)).max = rotationLimit;
				val2.limits = limits;
				val2.useLimits = true;
				((Joint)val2).enableCollision = enableJointCollision;
			}
		}
		for (int i = 0; i < list.Count; i++)
		{
			for (int j = 0; j < list.Count; j++)
			{
				if (i != j)
				{
					Physics.IgnoreCollision(list[i], list[j]);
				}
			}
		}
		SkeletonUtilityBone[] componentsInChildren = ((Component)this).GetComponentsInChildren<SkeletonUtilityBone>();
		if (componentsInChildren.Length != 0)
		{
			List<string> list2 = new List<string>();
			SkeletonUtilityBone[] array = componentsInChildren;
			foreach (SkeletonUtilityBone skeletonUtilityBone in array)
			{
				if (skeletonUtilityBone.mode == SkeletonUtilityBone.Mode.Override)
				{
					list2.Add(((Object)((Component)skeletonUtilityBone).gameObject).name);
					Object.Destroy((Object)(object)((Component)skeletonUtilityBone).gameObject);
				}
			}
			if (list2.Count > 0)
			{
				string text = "Destroyed Utility Bones: ";
				for (int l = 0; l < list2.Count; l++)
				{
					text += list2[l];
					if (l != list2.Count - 1)
					{
						text += ",";
					}
				}
				Debug.LogWarning((object)text);
			}
		}
		if (disableIK)
		{
			ExposedList<IkConstraint> ikConstraints = skeleton.IkConstraints;
			int m = 0;
			for (int count = ikConstraints.Count; m < count; m++)
			{
				ikConstraints.Items[m].mix = 0f;
			}
		}
		if (disableOtherConstraints)
		{
			ExposedList<TransformConstraint> transformConstraints = skeleton.transformConstraints;
			int n = 0;
			for (int count2 = transformConstraints.Count; n < count2; n++)
			{
				transformConstraints.Items[n].rotateMix = 0f;
				transformConstraints.Items[n].scaleMix = 0f;
				transformConstraints.Items[n].shearMix = 0f;
				transformConstraints.Items[n].translateMix = 0f;
			}
			ExposedList<PathConstraint> pathConstraints = skeleton.pathConstraints;
			int num = 0;
			for (int count3 = pathConstraints.Count; num < count3; num++)
			{
				pathConstraints.Items[num].rotateMix = 0f;
				pathConstraints.Items[num].translateMix = 0f;
			}
		}
		targetSkeletonComponent.UpdateWorld += UpdateSpineSkeleton;
	}

	public Coroutine SmoothMix(float target, float duration)
	{
		return ((MonoBehaviour)this).StartCoroutine(SmoothMixCoroutine(target, duration));
	}

	private IEnumerator SmoothMixCoroutine(float target, float duration)
	{
		float startTime = Time.time;
		float startMix = mix;
		while (mix > 0f)
		{
			skeleton.SetBonesToSetupPose();
			mix = Mathf.SmoothStep(startMix, target, (Time.time - startTime) / duration);
			yield return null;
		}
	}

	public void SetSkeletonPosition(Vector3 worldPosition)
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		if (!isActive)
		{
			Debug.LogWarning((object)"Can't call SetSkeletonPosition while Ragdoll is not active!");
			return;
		}
		Vector3 val = worldPosition - ((Component)this).transform.position;
		((Component)this).transform.position = worldPosition;
		foreach (Transform value in boneTable.Values)
		{
			value.position -= val;
		}
		UpdateSpineSkeleton(null);
		skeleton.UpdateWorldTransform();
	}

	public void Remove()
	{
		isActive = false;
		foreach (Transform value in boneTable.Values)
		{
			Object.Destroy((Object)(object)((Component)value).gameObject);
		}
		Object.Destroy((Object)(object)((Component)ragdollRoot).gameObject);
		boneTable.Clear();
		targetSkeletonComponent.UpdateWorld -= UpdateSpineSkeleton;
	}

	public Rigidbody GetRigidbody(string boneName)
	{
		Bone bone = skeleton.FindBone(boneName);
		if (bone != null && boneTable.ContainsKey(bone))
		{
			return ((Component)boneTable[bone]).GetComponent<Rigidbody>();
		}
		return null;
	}

	private void RecursivelyCreateBoneProxies(Bone b)
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Expected O, but got Unknown
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		string name = b.data.name;
		if (stopBoneNames.Contains(name))
		{
			return;
		}
		GameObject val = new GameObject(name);
		val.layer = colliderLayer;
		Transform transform = val.transform;
		boneTable.Add(b, transform);
		transform.parent = ((Component)this).transform;
		transform.localPosition = new Vector3(b.WorldX, b.WorldY, 0f);
		transform.localRotation = Quaternion.Euler(0f, 0f, b.WorldRotationX - b.shearX);
		transform.localScale = new Vector3(b.WorldScaleX, b.WorldScaleY, 1f);
		if (AttachBoundingBoxRagdollColliders(b).Count == 0)
		{
			float length = b.Data.Length;
			if (length == 0f)
			{
				val.AddComponent<SphereCollider>().radius = thickness * 0.5f;
			}
			else
			{
				BoxCollider obj = val.AddComponent<BoxCollider>();
				obj.size = new Vector3(length, thickness, thickness);
				obj.center = new Vector3(length * 0.5f, 0f);
			}
		}
		val.AddComponent<Rigidbody>().constraints = (RigidbodyConstraints)8;
		foreach (Bone child in b.Children)
		{
			RecursivelyCreateBoneProxies(child);
		}
	}

	private void UpdateSpineSkeleton(ISkeletonAnimation skeletonRenderer)
	{
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_016f: Unknown result type (might be due to invalid IL or missing references)
		//IL_018f: Unknown result type (might be due to invalid IL or missing references)
		bool flipX = skeleton.flipX;
		bool flipY = skeleton.flipY;
		bool flag = flipX ^ flipY;
		bool flag2 = flipX || flipY;
		foreach (KeyValuePair<Bone, Transform> item in boneTable)
		{
			Bone key = item.Key;
			Transform value = item.Value;
			bool flag3 = key == StartingBone;
			Transform val = ((!flag3) ? boneTable[key.Parent] : ragdollRoot);
			Vector3 position = val.position;
			Quaternion rotation = val.rotation;
			parentSpaceHelper.position = position;
			parentSpaceHelper.rotation = rotation;
			parentSpaceHelper.localScale = val.localScale;
			Vector3 position2 = value.position;
			Vector3 val2 = parentSpaceHelper.InverseTransformDirection(value.right);
			Vector3 val3 = parentSpaceHelper.InverseTransformPoint(position2);
			float num = Mathf.Atan2(val2.y, val2.x) * 57.29578f;
			if (flag2)
			{
				if (flag3)
				{
					if (flipX)
					{
						val3.x *= -1f;
					}
					if (flipY)
					{
						val3.y *= -1f;
					}
					num *= ((!flag) ? 1f : (-1f));
					if (flipX)
					{
						num += 180f;
					}
				}
				else if (flag)
				{
					num *= -1f;
					val3.y *= -1f;
				}
			}
			key.x = Mathf.Lerp(key.x, val3.x, mix);
			key.y = Mathf.Lerp(key.y, val3.y, mix);
			key.rotation = Mathf.Lerp(key.rotation, num, mix);
		}
	}

	private List<Collider> AttachBoundingBoxRagdollColliders(Bone b)
	{
		//IL_00cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		List<Collider> list = new List<Collider>();
		GameObject gameObject = ((Component)boneTable[b]).gameObject;
		Skin skin = skeleton.Skin ?? skeleton.Data.DefaultSkin;
		List<Attachment> list2 = new List<Attachment>();
		foreach (Slot slot in skeleton.Slots)
		{
			if (slot.Bone != b)
			{
				continue;
			}
			skin.FindAttachmentsForSlot(skeleton.Slots.IndexOf(slot), list2);
			foreach (Attachment item in list2)
			{
				if (item is BoundingBoxAttachment boundingBox && item.Name.ToLower().Contains("ragdoll"))
				{
					BoxCollider val = gameObject.AddComponent<BoxCollider>();
					Bounds boundingBoxBounds = SkeletonUtility.GetBoundingBoxBounds(boundingBox, thickness);
					val.center = ((Bounds)(ref boundingBoxBounds)).center;
					val.size = ((Bounds)(ref boundingBoxBounds)).size;
					list.Add((Collider)(object)val);
				}
			}
		}
		return list;
	}

	private static float GetPropagatedRotation(Bone b)
	{
		Bone parent = b.Parent;
		float num = b.AppliedRotation;
		while (parent != null)
		{
			num += parent.AppliedRotation;
			parent = parent.parent;
		}
		return num;
	}
}
