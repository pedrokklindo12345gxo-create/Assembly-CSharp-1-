using System.IO;
using UnityEngine;

namespace Spine.Unity;

public class MaterialsTextureLoader : TextureLoader
{
	private AtlasAsset atlasAsset;

	public MaterialsTextureLoader(AtlasAsset atlasAsset)
	{
		this.atlasAsset = atlasAsset;
	}

	public void Load(AtlasPage page, string path)
	{
		string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(path);
		Material val = null;
		Material[] materials = atlasAsset.materials;
		foreach (Material val2 in materials)
		{
			if ((Object)(object)val2.mainTexture == (Object)null)
			{
				Debug.LogError((object)("Material is missing texture: " + ((Object)val2).name), (Object)(object)val2);
				return;
			}
			if (((Object)val2.mainTexture).name == fileNameWithoutExtension)
			{
				val = val2;
				break;
			}
		}
		if ((Object)(object)val == (Object)null)
		{
			Debug.LogError((object)("Material with texture name \"" + fileNameWithoutExtension + "\" not found for atlas asset: " + ((Object)atlasAsset).name), (Object)(object)atlasAsset);
			return;
		}
		page.rendererObject = val;
		if (page.width == 0 || page.height == 0)
		{
			page.width = val.mainTexture.width;
			page.height = val.mainTexture.height;
		}
	}

	public void Unload(object texture)
	{
	}
}
