using System.Collections;
using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using DialogueTree;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Nugget : NPCBehavior
{
	public TextureBlock crying;

	public TextureBlock slop;

	public TextureBlock bloodySlop;

	public Transform knife;

	public Vector3 offset;

	public Sprite recessRed;

	public bool mPoisonedPlayer;

	private bool mEndWorld;

	private void BringBillyNote()
	{
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		GameObject obj = GameObject.Find("BillyNote");
		player.GetItem(Item.BillyNote);
		((Behaviour)obj.GetComponent<Collider2D>()).enabled = false;
		obj.GetComponent<SpriteRenderer>().color = Color.black;
	}

	private void GetCards()
	{
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		GameObject obj = GameObject.Find("MonstermonComplete");
		player.GetItem(Item.MonstermonCardComplete);
		((Behaviour)obj.GetComponent<Collider2D>()).enabled = false;
		obj.GetComponent<SpriteRenderer>().color = Color.black;
	}

	public void GetNugget()
	{
		player.GetItem(Item.Nugget);
	}

	private void GetBug()
	{
		player.GetItem(Item.Bug);
	}

	public void GetPill()
	{
		player.GetItem(Item.Pill);
	}

	private void GetGlass()
	{
		player.GetItem(Item.MagnifyingGlass);
	}

	private void SendToOffice()
	{
		//IL_004a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Expected O, but got Unknown
		Teacher t = Object.FindObjectOfType<Teacher>();
		t.SetAnimation("walk");
		player.inAnim = true;
		UI.CollapseDialogue();
		if (((Component)t).transform.position.x < 0f)
		{
			SetDirection(setFlip: true);
		}
		TweenSettingsExtensions.OnComplete<TweenerCore<Vector3, Vector3, VectorOptions>>(TweenSettingsExtensions.SetEase<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOMove(((Component)t).transform, new Vector3(-1.53f, -1.26f, -1.23f), 1.5f, false), (Ease)1), (TweenCallback)delegate
		{
			SetDirection(setFlip: false);
			player.ForceChangeDirection(right: true);
			t.SetCurrentConversation(18);
			t.mySkeleton.AnimationName = "idle";
			t.Interact();
			player.inAnim = false;
		});
	}

	private void ActivateTalkToNuggetInCS1()
	{
		ActivateMission(Mission.NuggetStartCollectNuggets, Room.Recess);
		conversations[Room.Classroom1].currentConversation = 7;
		conversations[Room.Cafeteria].currentConversation = 45;
		conversations[Room.Recess].currentConversation = 44;
	}

	private void ActivateNuggetCubbyMission()
	{
		conversations[Room.Cafeteria].currentConversation = 45;
		CompleteMission(Mission.NuggetStartCollectNuggets);
		ActivateMission(Mission.NuggetGetCubbyNugget, Room.Classroom1);
	}

	private void SkipNuggetCubbyMission()
	{
		CompleteMission(Mission.NuggetStartCollectNuggets);
	}

	private void ActivateLilyNuggetMission()
	{
		CompleteMission(Mission.NuggetStartThirdNugget);
		ActivateMission(Mission.NuggetGiveLoveLetter, Room.Classroom1);
		player.GetItem(Item.LoveLetter);
	}

	private void ActivateLunchNugget()
	{
		GetNugget();
		CompleteMission(Mission.NuggetDeliveredLetter);
		ActivateMission(Mission.NuggetTalkAtLunch, Room.Cafeteria);
		conversations[Room.Cafeteria].currentConversation = 44;
	}

	private void DetonatePlayer()
	{
		if (!UI.IsMissionComplete(Mission.BuggsCheckForDistraction))
		{
			player.ExplodePlayer("É muito importante para o Nugget que você colete com sucesso os nuggets da amizade.", "Es muy importante para Nugget que tú recojas todos los nuggets de amistad.");
		}
		else if (EnvironmentController.currentRoom == Room.Cafeteria)
		{
			lastSelectedOption.DestinationID = 47;
			conversations[Room.Recess].currentConversation = 48;
		}
		else if (EnvironmentController.currentRoom == Room.Recess)
		{
			lastSelectedOption.DestinationID = 46;
		}
	}

	private void FailGiveLetter()
	{
		FailMission(Mission.NuggetGiveLoveLetter);
	}

	private void ActivateGetMagnifyingGlass()
	{
		ActivateMission(Mission.NuggetGetMagnifyingGlass, Room.Classroom1);
	}

	private void GiveMagnifyingGlass()
	{
		CompleteMission(Mission.NuggetGetMagnifyingGlass);
		player.UseItem(Item.MagnifyingGlass);
	}

	private void GetTowerBeetle()
	{
		player.GetItem(Item.KingTowerbeetle);
		UnlockHint("Monstermon", 4);
	}

	public bool GetPoisonedPlayer()
	{
		return mPoisonedPlayer;
	}

	private void GetPoisonNugget()
	{
		player.GetItem(Item.PoisonNugget);
	}

	private void EatPoisonNugget()
	{
		player.UseItem(Item.PoisonNugget);
		mPoisonedPlayer = true;
		if (EnvironmentController.currentRoom == Room.Classroom1)
		{
			conversations[Room.Cafeteria].currentConversation = 43;
			ActivateMission(Mission.NuggetJoinAtLunch, Room.Cafeteria);
		}
	}

	private void LosePoisonNugget()
	{
		player.UseItem(Item.PoisonNugget);
		FailMission(Mission.TeacherNuggetGainTrust);
	}

	private void ThrowSlop()
	{
		((MonoBehaviour)this).StartCoroutine(ThrowSlopCoroutine());
	}

	private void ActivateKillBuggs()
	{
		CompleteMission(Mission.NuggetTalkAtLunch);
		ActivateMission(Mission.NuggetKillBuggs, Room.Cafeteria);
	}

	private void ActivatePoisonBuggs()
	{
		CompleteMission(Mission.NuggetJoinAtLunch);
		ActivateMission(Mission.NuggetPoisonBuggs, Room.Cafeteria);
	}

	private IEnumerator ThrowSlopCoroutine()
	{
		Buggs b = Object.FindObjectOfType<Buggs>();
		if (b.removedFromGame)
		{
			lastSelectedOption.DestinationID = 39;
			yield break;
		}
		GameObject sg = GameObject.Find("SlopGlob");
		((Renderer)sg.GetComponent<SpriteRenderer>()).enabled = true;
		b.SetDirection(setFlip: false);
		b.mySkeleton.timeScale = 1f;
		b.SetAnimation("throw");
		player.inAnim = true;
		yield return (object)new WaitForSeconds(0.25f);
		TweenSettingsExtensions.OnComplete<TweenerCore<Vector3, Vector3, VectorOptions>>(TweenSettingsExtensions.SetEase<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOMove(sg.transform, new Vector3(-6f, -8f, -20f), 0.5f, false), (Ease)1), (TweenCallback)delegate
		{
			if (mySkeleton.skeleton.flipX)
			{
				SetAnimation("HitInHeadFront");
			}
			else
			{
				SetAnimation("HitInHeadBack");
			}
			SFXManager.Instance.PlaySound("SlopSplat");
			ApplyTextureBlock(slop);
			((Renderer)sg.GetComponent<SpriteRenderer>()).enabled = false;
			player.inAnim = false;
		});
		yield return (object)new WaitForSeconds(0.25f);
		b.SetAnimation("idle");
		b.mySkeleton.timeScale = 1.5f;
		yield return (object)new WaitForSeconds(0.58f);
		SetAnimation("idle");
	}

	private void BuggsFallOver()
	{
		UI.CompleteMission(Mission.TeacherGetBuggsInTrouble);
		Object.FindObjectOfType<Buggs>().PukeAndDie();
		Object.FindObjectOfType<Teacher>().conversations[Room.Recess].Nodes[0].Options[0].IsAvailable = true;
	}

	private void StabNugget()
	{
		SFXManager.Instance.PlaySound("GoreSplat2");
		ApplyTextureBlock(bloodySlop);
		player.UseItem(Item.Knife);
		GameObject obj = GameObject.Find("NuggetKnife");
		((Renderer)obj.GetComponent<SpriteRenderer>()).enabled = true;
		((Component)obj.transform.GetChild(0)).GetComponent<ParticleSystem>().Play();
	}

	private void ActivateNuggetCave()
	{
		CompleteMission(Mission.TeacherNuggetGainTrust);
		Object.FindObjectOfType<Teacher>().ActivateMission(Mission.TeacherTellGainedTrust, Room.Recess);
	}

	private void ActivateNuggetAtRecess()
	{
		ActivateMission(Mission.NuggetTalkAtRecess, Room.Recess);
		CompleteMission(Mission.NuggetTellPoisonedBuggs);
		CompleteMission(Mission.NuggetTellStabbedBuggs);
		conversations[Room.Recess].currentConversation = 17;
	}

	public void CheckPoison()
	{
		EnvironmentController.Instance.RingBell();
		if (mPoisonedPlayer)
		{
			((MonoBehaviour)this).StartCoroutine(PlayerPoisoned());
			return;
		}
		LunchLady lunchLady = Object.FindObjectOfType<LunchLady>();
		lunchLady.SetCurrentConversation(12);
		lunchLady.Interact();
	}

	private IEnumerator PlayerPoisoned()
	{
		player.inAnim = true;
		UI.showDeath = true;
		Renderer r = ((Component)player).GetComponent<Renderer>();
		while (r.material.color.r > 0.8f)
		{
			Material material = r.material;
			material.color -= new Color(0.025f, 0f, 0.025f, 0f);
			yield return (object)new WaitForSeconds(0.1f);
		}
		player.PlayAnimation("fallover");
		yield return (object)new WaitForSeconds(1f);
		player.GetSkeleton().timeScale = 0f;
		UI.ShowDeath("Você foi envenenado. Isso é ruim.", "Te envenenaron. Esto está mal");
	}

	private void TakeAntidote()
	{
		CompleteMission(Mission.NuggetJoinAtLunch);
		CompleteMission(Mission.NuggetGetAntidote);
		mPoisonedPlayer = false;
		ActivateNuggetCave();
	}

	private void JumpIntoHole()
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		((Renderer)GameObject.Find("HoleCover").GetComponent<SpriteRenderer>()).enabled = true;
		player.DisableGravity(((Component)this).transform.position.x < ((Component)player).transform.position.x);
		((MonoBehaviour)this).StartCoroutine(FallIntoHole());
	}

	private void CheckForDevice()
	{
		if (player.HasItem(Item.Bug))
		{
			lastSelectedOption.DestinationID = -1;
			player.ExplodePlayer("Por que você pegou um segundo dispositivo?", "¿Por qué cogiste un segundo dispositivo?");
		}
	}

	private void GetKnifeHint()
	{
		UnlockHint("Buggs", 5);
	}

	private IEnumerator FallIntoHole()
	{
		player.inAnim = true;
		player.inDialogue = true;
		UI.showDeath = true;
		yield return (object)new WaitForSeconds(3f);
		SFXManager.Instance.PlaySound("Thud");
		Object.FindObjectOfType<CameraFollow>().CameraShake(0.5f);
		yield return (object)new WaitForSeconds(1f);
		UI.ShowDeath("Pular em buracos dos quais você não consegue ver o fundo geralmente é considerado uma má ideia.", "Saltar a los agujeros sin ver el fondo se considera generalmente una mala idea.");
	}

	private void GotRidOfKnife()
	{
		((Renderer)GameObject.Find("HoleCover").GetComponent<SpriteRenderer>()).enabled = false;
		DialogueNode currentConversation = Object.FindObjectOfType<Buggs>().GetCurrentConversation();
		currentConversation.Options[0].IsAvailable = true;
		currentConversation.Options[1].IsAvailable = false;
		currentConversation.Options[2].IsAvailable = false;
	}

	private void ThrewKnifeInHole()
	{
		((MonoBehaviour)this).StartCoroutine(ThrewKnifeInHoleCoroutine());
	}

	private void ThrowKnife()
	{
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_008f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bf: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		player.UseItem(Item.BloodyKnife);
		GameObject val = GameObject.Find("BloodyKnife");
		((Renderer)val.GetComponent<SpriteRenderer>()).enabled = true;
		Rigidbody2D component = val.GetComponent<Rigidbody2D>();
		val.transform.position = new Vector3(((Component)player).transform.position.x, ((Component)player).transform.position.y, -7.15f);
		((Renderer)GameObject.Find("HoleCover").GetComponent<SpriteRenderer>()).enabled = true;
		component.isKinematic = false;
		component.AddForce(new Vector2(0f, 400f));
		component.AddTorque(150f);
		val.transform.position = new Vector3(val.transform.position.x, val.transform.position.y, -7.15f);
		((MonoBehaviour)this).StartCoroutine(DisableKnife(val));
	}

	private IEnumerator DisableKnife(GameObject k)
	{
		yield return (object)new WaitForSeconds(3f);
		k.SetActive(false);
	}

	private IEnumerator ThrewKnifeInHoleCoroutine()
	{
		player.inAnim = true;
		player.inDialogue = true;
		ThrowKnife();
		yield return (object)new WaitForSeconds(2f);
		player.inAnim = false;
		player.inDialogue = true;
		SetEmptyOptions();
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("Guh...naaaaaaaa...~mas...", "Guh...naaaaaaaa...~pero...", this));
		while (pEmptyOptions)
		{
			yield return null;
		}
		Object.FindObjectOfType<CameraFollow>().CameraShake(1f);
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("\\bRAAAAAA!!/b", "\\b¡¡RAAAAAA!!/b", this));
		while (pEmptyOptions)
		{
			yield return null;
		}
		((Behaviour)pCollider).enabled = false;
		SetAnimation("walk");
		player.inAnim = true;
		TweenSettingsExtensions.OnUpdate<TweenerCore<Vector3, Vector3, VectorOptions>>(TweenSettingsExtensions.OnComplete<TweenerCore<Vector3, Vector3, VectorOptions>>(TweenSettingsExtensions.SetEase<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOMoveY(((Component)this).transform, -7f, 1.5f, false), (Ease)1), (TweenCallback)delegate
		{
			SetAnimation("idle");
		}), new TweenCallback(base.SetDepth));
		yield return (object)new WaitForSeconds(1.5f);
		player.inAnim = false;
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("O NUGGET DISSE NÃO!!", "¡¡NUGGET DIJO NO!!", this));
		while (pEmptyOptions)
		{
			yield return null;
		}
		UI.showDeath = true;
		player.inAnim = true;
		UI.CollapseDialogue();
		SetAnimation("walk");
		TweenSettingsExtensions.OnComplete<TweenerCore<Vector3, Vector3, VectorOptions>>(TweenSettingsExtensions.SetEase<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOMove(((Component)this).transform, ((Component)player).transform.position, 0.5f, false), (Ease)1), (TweenCallback)delegate
		{
			//IL_0017: Unknown result type (might be due to invalid IL or missing references)
			//IL_002c: Unknown result type (might be due to invalid IL or missing references)
			SetAnimation("idle");
			player.DisableGravity(((Component)this).transform.position.x < ((Component)player).transform.position.x);
		});
		yield return (object)new WaitForSeconds(3f);
		SFXManager.Instance.PlaySound("Thud");
		Object.FindObjectOfType<CameraFollow>().CameraShake(0.5f);
		yield return (object)new WaitForSeconds(1f);
		UI.ShowDeath("Não significa não.", "No significa no.");
	}

	private void DropNuggetsInHole()
	{
		((MonoBehaviour)this).StartCoroutine(DropNuggets());
	}

	private IEnumerator DropNuggets()
	{
		player.inAnim = true;
		GameObject.Find("NuggetParticleSystem").GetComponent<ParticleSystem>().Play();
		((Renderer)GameObject.Find("HoleCover").GetComponent<SpriteRenderer>()).enabled = true;
		yield return (object)new WaitForSeconds(3f);
		player.inAnim = false;
		Interact();
	}

	private void EnterNuggetCave()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		player.DisableGravity(((Component)this).transform.position.x < ((Component)player).transform.position.x);
		((MonoBehaviour)this).StartCoroutine(EnteringCave());
	}

	private IEnumerator EnteringCave()
	{
		player.inAnim = true;
		yield return (object)new WaitForSeconds(2f);
		EnvironmentController.Instance.ChangeEnvironment(Room.NuggetCave);
		yield return (object)new WaitForSeconds(1f);
		player.inAnim = false;
		player.ResetGravity();
	}

	private void GiveBugToNugget()
	{
		player.UseItem(Item.Bug);
		((MonoBehaviour)this).StartCoroutine(GiveBugToNuggetCoroutine(g: true));
	}

	private void RetrieveBug()
	{
		((MonoBehaviour)this).StartCoroutine(GiveBugToNuggetCoroutine(g: false));
	}

	private IEnumerator GiveBugToNuggetCoroutine(bool g)
	{
		player.inAnim = true;
		SetDirection(setFlip: false);
		SetAnimation("walk");
		((Behaviour)pCollider).enabled = false;
		TweenSettingsExtensions.SetEase<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOMoveX(((Component)this).transform, -23f, 0.75f, false), (Ease)1);
		yield return (object)new WaitForSeconds(0.75f);
		SetDirection(setFlip: true);
		((Renderer)GameObject.Find("RecessBug").GetComponent<SpriteRenderer>()).enabled = g;
		TweenSettingsExtensions.SetEase<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOMoveX(((Component)this).transform, -11.41f, 0.75f, false), (Ease)1);
		yield return (object)new WaitForSeconds(0.75f);
		SetDirection(((Component)this).transform.position.x > ((Component)player).transform.position.x);
		SetAnimation("idle");
		((Behaviour)pCollider).enabled = true;
		player.inAnim = false;
		Interact();
		if (!g)
		{
			CompleteMission(Mission.NuggetTalkAtRecess);
			ActivateMission(Mission.NuggetPlaceDevice);
			player.GetItem(Item.Bug);
		}
	}

	private void PlaceBug()
	{
		player.UseItem(Item.Bug);
		CompleteMission(Mission.NuggetPlaceDevice);
		ActivateMission(Mission.NuggetTalkToLily, Room.Recess);
	}

	private void GetFinalNugget()
	{
		GetNugget();
		CompleteMission(Mission.NuggetGetLastNugget);
		CompleteMission(Mission.NuggetCollectNuggets);
	}

	private void TakeAllNuggets()
	{
		for (int i = 0; i < 5; i++)
		{
			player.UseItem(Item.Nugget);
		}
	}

	private void TakeNugget()
	{
		player.UseItem(Item.Nugget);
	}

	public void CheckRemoveNuggetPiles()
	{
		if (player.GetItemCount(Item.Nugget) >= 5)
		{
			GameObject.Find("NuggetPileCoverMemorial").SetActive(false);
			GameObject.Find("NuggetPileCoverSign").SetActive(false);
		}
		Interact();
	}

	private void GetCaveCard()
	{
		player.GetItem(Item.WizardWorm);
		UnlockHint("Monstermon", 12);
		GameObject obj = GameObject.Find("NuggetCaveCard");
		((Behaviour)obj.GetComponent<BoxCollider2D>()).enabled = false;
		((Renderer)obj.GetComponent<SpriteRenderer>()).enabled = false;
	}

	private void PlaceFlower()
	{
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0077: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Expected O, but got Unknown
		player.UseItem(Item.Flower);
		((Renderer)GameObject.Find("NuggetCaveFlower").GetComponent<SpriteRenderer>()).enabled = true;
		player.inAnim = true;
		player.ForceChangeDirection(right: false);
		SetAnimation("walk");
		TweenSettingsExtensions.OnComplete<TweenerCore<Vector3, Vector3, VectorOptions>>(TweenSettingsExtensions.SetEase<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOMove(((Component)this).transform, new Vector3(-3.75f, -3f, -7.9f), 2f, false), (Ease)1), (TweenCallback)delegate
		{
			player.inAnim = false;
			SetCrying();
			player.ForceChangeDirection(right: true);
			SetAnimation("idle");
		});
		SetEndDay(x: true);
	}

	private void SetCrying()
	{
		ApplyTextureBlock(crying);
	}

	private void BellRingMemorial()
	{
		SFXManager.Instance.PlaySound("Bell");
		((MonoBehaviour)this).StartCoroutine(ExitNuggetCaveToCS2());
	}

	private void StartMemorial()
	{
		UnlockHint("Nugget", 6);
		SetCurrentConversation(2);
		Interact();
	}

	private void StartSignPost()
	{
		SetCurrentConversation(3);
		Interact();
	}

	private void StartDog()
	{
		SetCurrentConversation(9);
		Interact();
	}

	private IEnumerator ExitNuggetCaveToCS2()
	{
		player.inAnim = true;
		yield return (object)new WaitForSeconds(1f);
		player.inAnim = false;
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("Esse é o sinal. Devemos partir da Caverna do Nugget. Vejo você novamente em breve.", "Está sonando el timbre. Debemos irnos de la Cueva de Nugget. Te veré pronto.", this));
		while (pEmptyOptions)
		{
			yield return null;
		}
		UI.CollapseDialogue();
		EnvironmentController.Instance.ChangeEnvironment(Room.Classroom2);
		yield return (object)new WaitForSeconds(1f);
		if (UI.ReceivedMission(Mission.NuggetKillBuggs))
		{
			ApplyTextureBlock(slop);
		}
	}

	private void GetDog()
	{
		player.GetItem(Item.CindyDog);
		GameObject.Find("CindyDog").SetActive(false);
		if (UI.IsMissionActive(Mission.TeacherCollectEvidence))
		{
			CompleteMission(Mission.TeacherCollectEvidence);
			ActivateMission(Mission.TeacherShowEvidence);
		}
	}
}
