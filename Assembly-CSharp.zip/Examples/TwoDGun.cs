using TouchControlsKit;
using UnityEngine;

namespace Examples;

public class TwoDGun : MonoBehaviour
{
	public Rigidbody2D rocket;

	public float speed = 20f;

	private TwoDPlayerControl playerCtrl;

	private Animator anim;

	private void Awake()
	{
		anim = ((Component)((Component)this).transform.root).gameObject.GetComponent<Animator>();
		playerCtrl = ((Component)((Component)this).transform.root).GetComponent<TwoDPlayerControl>();
	}

	private void Update()
	{
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		if (TCKInput.GetButtonDown("shootButton"))
		{
			anim.SetTrigger("Shoot");
			if (playerCtrl.facingRight)
			{
				Object.Instantiate<Rigidbody2D>(rocket, ((Component)this).transform.position, Quaternion.Euler(Vector3.zero)).velocity = new Vector2(speed, 0f);
			}
			else
			{
				Object.Instantiate<Rigidbody2D>(rocket, ((Component)this).transform.position, Quaternion.Euler(new Vector3(0f, 0f, 180f))).velocity = new Vector2(0f - speed, 0f);
			}
		}
	}
}
