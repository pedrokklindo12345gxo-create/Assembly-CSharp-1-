using UnityEngine;

public class ComputerBehavior : ObjectInteractable
{
	public override void DoNormalInteract()
	{
		UI.StartDialogue(dialogue.GetCurrentNode().DialogueText, null, cpu: true);
		((MonoBehaviour)this).Invoke("UpdateOptions", 0.5f);
		player.inDialogue = true;
	}

	public override void DoBaseFunction()
	{
		if (lastSelectedOption.DestinationID > -1)
		{
			dialogue.currentConversation = lastSelectedOption.DestinationID;
			UI.StartDialogue(dialogue.GetCurrentNode().DialogueText, null, cpu: true);
		}
		else
		{
			UI.CollapseDialogue();
			player.SetInteractable(null);
			if (lastSelectedOption.ResolutionID > 0)
			{
				dialogue.currentConversation = lastSelectedOption.ResolutionID;
			}
		}
		((MonoBehaviour)this).StartCoroutine(UI.ShowOptions(show: false));
		((MonoBehaviour)this).Invoke("UpdateOptions", 0.5f);
	}
}
