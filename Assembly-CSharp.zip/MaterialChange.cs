using Spine.Unity;
using UnityEngine;

[ExecuteInEditMode]
public class MaterialChange : MonoBehaviour
{
	public Material myMat;

	public Material defaultMat;

	private void OnValidate()
	{
		((Component)this).GetComponent<SkeletonAnimation>().CustomMaterialOverride.Clear();
		((Component)this).GetComponent<SkeletonAnimation>().CustomMaterialOverride.Add(defaultMat, myMat);
	}

	private void Start()
	{
		((Component)this).GetComponent<SkeletonAnimation>().CustomMaterialOverride.Clear();
		((Component)this).GetComponent<SkeletonAnimation>().CustomMaterialOverride.Add(defaultMat, myMat);
	}

	private void OnEnable()
	{
		((Component)this).GetComponent<SkeletonAnimation>().CustomMaterialOverride.Clear();
		((Component)this).GetComponent<SkeletonAnimation>().CustomMaterialOverride.Add(defaultMat, myMat);
	}
}
