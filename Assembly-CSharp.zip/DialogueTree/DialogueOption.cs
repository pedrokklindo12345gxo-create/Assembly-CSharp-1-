namespace DialogueTree;

public class DialogueOption
{
	public string OptionText;

	public int DestinationID;

	public int ResolutionID;

	public string FunctionCall;

	public float MoneyLock;

	public Mission MissionLock;

	public Item ItemToUse;

	public bool IsAvailable = true;

	public bool UsesAction;

	public bool isComplete;

	public DialogueOption()
	{
	}

	public DialogueOption(string t)
	{
		OptionText = t;
		DestinationID = -1;
	}

	public void SetAvailable()
	{
		IsAvailable = true;
	}

	public static DialogueOption Clone(DialogueOption original)
	{
		return new DialogueOption
		{
			OptionText = original.OptionText,
			DestinationID = original.DestinationID,
			ResolutionID = original.ResolutionID,
			FunctionCall = original.FunctionCall,
			MoneyLock = original.MoneyLock,
			MissionLock = original.MissionLock,
			ItemToUse = original.ItemToUse,
			IsAvailable = original.IsAvailable,
			UsesAction = original.UsesAction
		};
	}
}
