using TouchControlsKit;
using UnityEngine;

public class LevelLoader : MonoBehaviour
{
	[SerializeField]
	private bool isMainMenu;

	private void Update()
	{
		if (isMainMenu)
		{
			if (TCKInput.GetButtonDown("btnFps"))
			{
				Application.LoadLevel("FirstPerson");
			}
			if (TCKInput.GetButtonDown("btnPlatf"))
			{
				Application.LoadLevel("2DPlatformer");
			}
			if (TCKInput.GetButtonDown("btnBal"))
			{
				Application.LoadLevel("TiltBallDemo");
			}
			if (TCKInput.GetButtonDown("btnCar"))
			{
				Application.LoadLevel("WheelCarDemo");
			}
		}
		else if (TCKInput.GetButtonUp("mButton"))
		{
			Application.LoadLevel("mainMenu");
		}
	}
}
