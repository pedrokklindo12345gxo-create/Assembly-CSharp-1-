using System.Collections;
using UnityEngine;

namespace Spine.Unity.Modules;

public class SkeletonGhostRenderer : MonoBehaviour
{
	public float fadeSpeed = 10f;

	private Color32[] colors;

	private Color32 black = new Color32((byte)0, (byte)0, (byte)0, (byte)0);

	private MeshFilter meshFilter;

	private MeshRenderer meshRenderer;

	private void Awake()
	{
		meshRenderer = ((Component)this).gameObject.AddComponent<MeshRenderer>();
		meshFilter = ((Component)this).gameObject.AddComponent<MeshFilter>();
	}

	public void Initialize(Mesh mesh, Material[] materials, Color32 color, bool additive, float speed, int sortingLayerID, int sortingOrder)
	{
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		((MonoBehaviour)this).StopAllCoroutines();
		((Component)this).gameObject.SetActive(true);
		((Renderer)meshRenderer).sharedMaterials = materials;
		((Renderer)meshRenderer).sortingLayerID = sortingLayerID;
		((Renderer)meshRenderer).sortingOrder = sortingOrder;
		meshFilter.sharedMesh = Object.Instantiate<Mesh>(mesh);
		colors = meshFilter.sharedMesh.colors32;
		if (color.a + color.r + color.g + color.b > 0)
		{
			for (int i = 0; i < colors.Length; i++)
			{
				colors[i] = color;
			}
		}
		fadeSpeed = speed;
		if (additive)
		{
			((MonoBehaviour)this).StartCoroutine(FadeAdditive());
		}
		else
		{
			((MonoBehaviour)this).StartCoroutine(Fade());
		}
	}

	private IEnumerator Fade()
	{
		for (int t = 0; t < 500; t++)
		{
			bool flag = true;
			for (int i = 0; i < colors.Length; i++)
			{
				Color32 val = colors[i];
				if (val.a > 0)
				{
					flag = false;
				}
				colors[i] = Color32.Lerp(val, black, Time.deltaTime * fadeSpeed);
			}
			meshFilter.sharedMesh.colors32 = colors;
			if (flag)
			{
				break;
			}
			yield return null;
		}
		Object.Destroy((Object)(object)meshFilter.sharedMesh);
		((Component)this).gameObject.SetActive(false);
	}

	private IEnumerator FadeAdditive()
	{
		Color32 black = this.black;
		for (int t = 0; t < 500; t++)
		{
			bool flag = true;
			for (int i = 0; i < colors.Length; i++)
			{
				Color32 val = colors[i];
				black.a = val.a;
				if (val.r > 0 || val.g > 0 || val.b > 0)
				{
					flag = false;
				}
				colors[i] = Color32.Lerp(val, black, Time.deltaTime * fadeSpeed);
			}
			meshFilter.sharedMesh.colors32 = colors;
			if (flag)
			{
				break;
			}
			yield return null;
		}
		Object.Destroy((Object)(object)meshFilter.sharedMesh);
		((Component)this).gameObject.SetActive(false);
	}

	public void Cleanup()
	{
		if ((Object)(object)meshFilter != (Object)null && (Object)(object)meshFilter.sharedMesh != (Object)null)
		{
			Object.Destroy((Object)(object)meshFilter.sharedMesh);
		}
		Object.Destroy((Object)(object)((Component)this).gameObject);
	}
}
