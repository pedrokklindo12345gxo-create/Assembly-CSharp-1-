using System;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using DialogueTree;
using Spine.Unity;
using UnityEngine;

public class NPCBehavior : Interactable
{
	[Serializable]
	public class TextureBlock
	{
		public Texture2D bodyTexture;

		public Sprite face;

		public Sprite faceMO;

		public TextureBlock(Texture2D body, Sprite f, Sprite fMO)
		{
			bodyTexture = body;
			face = f;
			faceMO = fMO;
		}
	}

	public TextureBlock defaultTextureBlock;

	public TextureBlock currentTextureBlock;

	public Sprite face;

	public Sprite faceMO;

	public Color dialogueColor;

	protected Renderer pRend;

	protected Collider2D pCollider;

	public Dictionary<Room, Dialogue> conversations = new Dictionary<Room, Dialogue>();

	protected bool pEmptyOptions;

	public bool mEndDay;

	private PauseMenu mPauseMenu;

	[HideInInspector]
	public SkeletonAnimation mySkeleton;

	[HideInInspector]
	public bool removedFromGame;

	public void SetEndDay(bool x)
	{
		NPCBehavior[] array = Object.FindObjectsOfType<NPCBehavior>();
		for (int i = 0; i < array.Length; i++)
		{
			if (array[i].GetEndDay())
			{
				return;
			}
		}
		mEndDay = x;
	}

	public bool GetEndDay()
	{
		return mEndDay;
	}

	private void Awake()
	{
		mySkeleton = ((Component)this).GetComponent<SkeletonAnimation>();
	}

	public override void Start()
	{
		//IL_0249: Unknown result type (might be due to invalid IL or missing references)
		//IL_0259: Unknown result type (might be due to invalid IL or missing references)
		//IL_0269: Unknown result type (might be due to invalid IL or missing references)
		//IL_026e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0272: Unknown result type (might be due to invalid IL or missing references)
		//IL_027c: Unknown result type (might be due to invalid IL or missing references)
		base.Start();
		pRend = ((Component)this).GetComponent<Renderer>();
		pCollider = ((Component)this).GetComponent<Collider2D>();
		mPauseMenu = Object.FindObjectOfType<PauseMenu>();
		if (conversations.Count == 0)
		{
			ref TextureBlock reference = ref defaultTextureBlock;
			Texture mainTexture = pRend.material.mainTexture;
			reference = new TextureBlock((Texture2D)(object)((mainTexture is Texture2D) ? mainTexture : null), face, faceMO);
			currentTextureBlock = defaultTextureBlock;
			if (!EnvironmentController.Instance.isSpanish)
			{
				foreach (Room value in Enum.GetValues(typeof(Room)))
				{
					Object obj = Resources.Load("XML/" + ((Object)((Component)this).transform).name + "/" + ((Object)((Component)this).transform).name + value, typeof(TextAsset));
					TextAsset val = (TextAsset)(object)((obj is TextAsset) ? obj : null);
					if ((Object)(object)val != (Object)null)
					{
						conversations.Add(value, Dialogue.LoadDialogue(val));
						conversations[value].Nodes.Sort();
					}
				}
			}
			else
			{
				foreach (Room value2 in Enum.GetValues(typeof(Room)))
				{
					Object obj2 = Resources.Load("XMLSpanish/" + ((Object)((Component)this).transform).name + "/" + ((Object)((Component)this).transform).name + value2, typeof(TextAsset));
					TextAsset val2 = (TextAsset)(object)((obj2 is TextAsset) ? obj2 : null);
					if ((Object)(object)val2 != (Object)null)
					{
						conversations.Add(value2, Dialogue.LoadDialogue(val2));
						conversations[value2].Nodes.Sort();
					}
				}
			}
		}
		else
		{
			ApplyTextureBlock(currentTextureBlock);
		}
		Transform transform = ((Component)this).transform;
		float x = ((Component)this).transform.position.x;
		float y = ((Component)this).transform.position.y;
		Bounds bounds = ((Component)this).GetComponent<Collider2D>().bounds;
		transform.position = new Vector3(x, y, ((Bounds)(ref bounds)).min.y);
	}

	public void SetAnimation(string a)
	{
		mySkeleton.AnimationName = a;
	}

	public void SetDirection(bool setFlip)
	{
		mySkeleton.skeleton.flipX = setFlip;
	}

	private void CheckTurnAround()
	{
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		mySkeleton.skeleton.flipX = ((Component)player).transform.position.x > ((Component)this).transform.position.x;
	}

	public override void Interact()
	{
		base.Interact();
		CheckTurnAround();
		UI.StartDialogue(GetCurrentConversation().DialogueText, this);
		((MonoBehaviour)this).Invoke("UpdateOptions", 0.5f);
		player.inDialogue = true;
	}

	public override int GetOptionCount()
	{
		return GetCurrentConversation().Options.Count;
	}

	public void DoBaseFunction()
	{
		if (lastSelectedOption.DestinationID > -1)
		{
			conversations[EnvironmentController.currentRoom].currentConversation = lastSelectedOption.DestinationID;
			UI.StartDialogue(GetCurrentConversation().DialogueText, this);
		}
		else
		{
			if (lastSelectedOption.DestinationID != -1)
			{
				player.SetInteractable(null);
				((MonoBehaviour)this).StartCoroutine(UI.ShowOptions(show: false));
				return;
			}
			UI.CollapseDialogue();
			player.SetInteractable(null);
			if (lastSelectedOption.ResolutionID > 0)
			{
				conversations[EnvironmentController.currentRoom].currentConversation = lastSelectedOption.ResolutionID;
			}
			else if (lastSelectedOption.ResolutionID == -1)
			{
				conversations[EnvironmentController.currentRoom].currentConversation = 0;
			}
		}
		((MonoBehaviour)this).StartCoroutine(UI.ShowOptions(show: false));
		((MonoBehaviour)this).Invoke("UpdateOptions", 0.5f);
	}

	public DialogueNode GetCurrentConversation()
	{
		if (conversations.TryGetValue(EnvironmentController.currentRoom, out var value))
		{
			return value.Nodes[value.currentConversation];
		}
		return new DialogueNode("Error: Text not found");
	}

	public void SetCurrentConversation(int x)
	{
		if (conversations.ContainsKey(EnvironmentController.currentRoom))
		{
			conversations[EnvironmentController.currentRoom].currentConversation = x;
		}
	}

	public override DialogueOption[] GetCurrentOptions()
	{
		return GetCurrentConversation().Options.ToArray();
	}

	public void SetDepth()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		Transform transform = ((Component)this).transform;
		float x = ((Component)this).transform.position.x;
		float y = ((Component)this).transform.position.y;
		Bounds bounds = ((Collider2D)((Component)this).GetComponent<BoxCollider2D>()).bounds;
		transform.position = new Vector3(x, y, ((Bounds)(ref bounds)).min.y);
	}

	public void ActivateMission(Mission m)
	{
		((MonoBehaviour)this).StartCoroutine(SetMissionStatus(m, 0));
	}

	public void ActivateMission(Mission m, Room r)
	{
		((MonoBehaviour)this).StartCoroutine(SetMissionStatus(m, 0, r));
	}

	public void CompleteMission(Mission m)
	{
		((MonoBehaviour)this).StartCoroutine(SetMissionStatus(m, 1));
	}

	public void FailMission(Mission m)
	{
		((MonoBehaviour)this).StartCoroutine(SetMissionStatus(m, 2));
	}

	private IEnumerator SetMissionStatus(Mission m, int x)
	{
		while (UI.IsDialogueRunning() || UI.transitioning)
		{
			yield return null;
		}
		switch (x)
		{
		case 0:
			UI.AddMission(m, this, Room.None);
			break;
		case 1:
			UI.CompleteMission(m);
			break;
		case 2:
			UI.FailMission(m);
			break;
		}
	}

	private IEnumerator SetMissionStatus(Mission m, int x, Room r)
	{
		yield return null;
		while (UI.IsDialogueRunning() || UI.transitioning)
		{
			yield return null;
		}
		switch (x)
		{
		case 0:
			UI.AddMission(m, this, r);
			break;
		case 1:
			UI.CompleteMission(m);
			break;
		case 2:
			UI.FailMission(m);
			break;
		}
	}

	protected IEnumerator RunDialogueSection(string d, string sp, NPCBehavior n)
	{
		pEmptyOptions = true;
		if (Object.op_Implicit((Object)(object)n))
		{
			if (!EnvironmentController.Instance.isSpanish)
			{
				UI.StartDialogue(d, n);
			}
			else
			{
				UI.StartDialogue(sp, n);
			}
		}
		else if (!EnvironmentController.Instance.isSpanish)
		{
			UI.StartDialogue(d);
		}
		else
		{
			UI.StartDialogue(sp);
		}
		yield return (object)new WaitForSeconds(0.5f);
		SetEmptyOptions();
		while (UI.IsDialogueRunning())
		{
			yield return null;
		}
		yield return (object)new WaitForSeconds(0.5f);
		while (!InputManager.Instance.IsInteractPressed() || player.inAnim || UI.showPlanner || mPauseMenu.IsOpen)
		{
			yield return null;
		}
		SFXManager.Instance.PlaySound("Confirm");
		pEmptyOptions = false;
	}

	protected IEnumerator RunDialogueSection(string d, string sp, NPCBehavior n, bool cpu)
	{
		pEmptyOptions = true;
		if (Object.op_Implicit((Object)(object)n))
		{
			if (!EnvironmentController.Instance.isSpanish)
			{
				UI.StartDialogue(d, n, cpu);
			}
			else
			{
				UI.StartDialogue(sp, n, cpu);
			}
		}
		else if (!EnvironmentController.Instance.isSpanish)
		{
			UI.StartDialogue(d, null, cpu);
		}
		else
		{
			UI.StartDialogue(sp, null, cpu);
		}
		yield return (object)new WaitForSeconds(0.5f);
		SetEmptyOptions();
		while (UI.IsDialogueRunning())
		{
			yield return null;
		}
		yield return (object)new WaitForSeconds(0.5f);
		while (!InputManager.Instance.IsInteractPressed() || player.inAnim || UI.showPlanner)
		{
			yield return null;
		}
		SFXManager.Instance.PlaySound("Confirm");
		pEmptyOptions = false;
	}

	public void RemoveFromGame()
	{
		removedFromGame = true;
		pRend.enabled = false;
		((Behaviour)pCollider).enabled = false;
		((Renderer)((Component)((Component)this).transform.GetChild(0)).GetComponent<SpriteRenderer>()).enabled = false;
	}

	public void RemoveFromGame(bool x)
	{
		removedFromGame = x;
		pRend.enabled = !x;
		((Behaviour)pCollider).enabled = !x;
		((Renderer)((Component)((Component)this).transform.GetChild(0)).GetComponent<SpriteRenderer>()).enabled = !x;
	}

	public void ApplyTextureBlock(TextureBlock t)
	{
		if (!Object.op_Implicit((Object)(object)pRend))
		{
			pRend = ((Component)this).GetComponent<Renderer>();
		}
		currentTextureBlock = t;
		pRend.material.mainTexture = (Texture)(object)t.bodyTexture;
		face = t.face;
		faceMO = t.faceMO;
	}

	public void WalkToPoint(Vector3 v, float d)
	{
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Expected O, but got Unknown
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Expected O, but got Unknown
		SetAnimation("walk");
		player.inAnim = true;
		((Behaviour)pCollider).enabled = false;
		TweenSettingsExtensions.OnUpdate<TweenerCore<Vector3, Vector3, VectorOptions>>(TweenSettingsExtensions.OnComplete<TweenerCore<Vector3, Vector3, VectorOptions>>(TweenSettingsExtensions.SetEase<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOMove(((Component)this).transform, v, d, false), (Ease)1), (TweenCallback)delegate
		{
			SetAnimation("idle");
			player.inAnim = false;
			((Behaviour)pCollider).enabled = true;
		}), new TweenCallback(SetDepth));
	}

	public void WalkToPoint(Vector3 v, float d, bool x)
	{
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Expected O, but got Unknown
		SetAnimation("walk");
		((Behaviour)pCollider).enabled = false;
		TweenSettingsExtensions.OnComplete<TweenerCore<Vector3, Vector3, VectorOptions>>(TweenSettingsExtensions.SetEase<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOMove(((Component)this).transform, v, d, false), (Ease)1), (TweenCallback)delegate
		{
			SetAnimation("idle");
			((Behaviour)pCollider).enabled = true;
			SetDepth();
		});
	}

	public void FacePlayer()
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		SetDirection(((Component)player).transform.position.x > ((Component)this).transform.position.x);
	}

	public virtual IEnumerator EndDayCoroutine()
	{
		yield return null;
	}

	public void CloneConversations(Dictionary<Room, Dialogue> original)
	{
		conversations.Clear();
		foreach (KeyValuePair<Room, Dialogue> item in original)
		{
			conversations.Add(item.Key, Dialogue.Clone(original[item.Key]));
		}
	}
}
