using System.Collections;
using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Core.PathCore;
using DG.Tweening.Plugins.Options;
using DialogueTree;
using UnityEngine;

public class Lily : NPCBehavior
{
	public enum LilyStatus
	{
		DontLeaveCafeteria,
		HeadingToBathroom,
		HeadingToOffice,
		OutsideOffice,
		None
	}

	public TextureBlock Surprised;

	public TextureBlock Gum;

	public TextureBlock Bloody;

	public TextureBlock Embarassed;

	public LilyStatus mLilyStatus = LilyStatus.None;

	private void LoseGum()
	{
		player.UseItem(Item.Gum);
		FailMission(Mission.CindyPutGumInHair);
		Object.FindObjectOfType<Cindy>().conversations[Room.Classroom1].Nodes[1].Options[0].IsAvailable = true;
	}

	private void LilyCompliment()
	{
		conversations[Room.Classroom1].currentConversation = 3;
	}

	private void GetDonut()
	{
		player.GetItem(Item.Donut);
		UnlockHint("Nugget", 4);
	}

	private void GetMoney()
	{
		player.GetMoney(2f);
	}

	private void ActivateReadNoteMission()
	{
		ActivateMission(Mission.LilyReadNote, Room.SchoolYard);
	}

	private void ActivateGetSentToOffice()
	{
		UnlockHint("Lily", 4);
		CompleteMission(Mission.LilyTellNote);
		ActivateMission(Mission.LilyGetSentToOffice, Room.SchoolYard);
		conversations[Room.Classroom1].currentConversation = 7;
	}

	private void TurnOnSurprised()
	{
		ApplyTextureBlock(Surprised);
	}

	private void PutGumInHair()
	{
		player.UseItem(Item.Gum);
		mLilyStatus = LilyStatus.DontLeaveCafeteria;
		ApplyTextureBlock(Gum);
		CompleteMission(Mission.CindyPutGumInHair);
		Object.FindObjectOfType<Cindy>().ActivateMission(Mission.CindyTalkMorningTime, Room.Classroom1);
		Object.FindObjectOfType<Cindy>().conversations[Room.Classroom1].currentConversation = 2;
	}

	private void FailGiveLetter()
	{
		FailMission(Mission.NuggetGiveLoveLetter);
		DialogueNode currentConversation = Object.FindObjectOfType<Nugget>().GetCurrentConversation();
		currentConversation.Options[0].IsAvailable = true;
		currentConversation.Options[0].IsAvailable = false;
	}

	private void FailFindHatch()
	{
		FailMission(Mission.LilyLookForSomethingSuspicious);
	}

	private void TeacherReadLetter()
	{
		((MonoBehaviour)this).StartCoroutine(TeacherReadLetterCoroutine());
	}

	private IEnumerator TeacherReadLetterCoroutine()
	{
		UI.CollapseDialogue();
		mLilyStatus = LilyStatus.DontLeaveCafeteria;
		player.UseItem(Item.LoveLetter);
		Teacher t = Object.FindObjectOfType<Teacher>();
		Nugget i = Object.FindObjectOfType<Nugget>();
		SetDirection(setFlip: true);
		SetAnimation("walk");
		((Behaviour)pCollider).enabled = false;
		Vector3[] array = (Vector3[])(object)new Vector3[3]
		{
			new Vector3(10.56f, -0.56f, -0.55345f),
			new Vector3(18.26f, -0.56f, -0.55345f),
			new Vector3(22.44f, -6.92f, -6.91345f)
		};
		player.inAnim = true;
		TweenSettingsExtensions.OnComplete<TweenerCore<Vector3, Path, PathOptions>>(TweenSettingsExtensions.SetEase<TweenerCore<Vector3, Path, PathOptions>>(ShortcutExtensions.DOPath(((Component)this).transform, array, 2f, (PathType)0, (PathMode)1, 10, (Color?)null), (Ease)1), (TweenCallback)delegate
		{
			SetAnimation("idle");
			t.SetDirection(setFlip: false);
		});
		yield return (object)new WaitForSeconds(2f);
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("Umm...~Sra. Applegate?", "Umm...~Sra. Applegate?", this));
		player.inAnim = false;
		while (pEmptyOptions)
		{
			yield return null;
		}
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("Sim, Lily? O que foi?", "¿Sí, Lily? ¿Qué es ésto?", t));
		while (pEmptyOptions)
		{
			yield return null;
		}
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("O Nugget acabou de me dar esta carta de amor e eu estava pensando...", "Nugget me acaba de entregar esta carta de amor y me estaba preguntando—", this));
		while (pEmptyOptions)
		{
			yield return null;
		}
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("\\bOOOOOOOH!!/b", "\\b¡¡OOOOOOOH!!/b", t));
		while (pEmptyOptions)
		{
			yield return null;
		}
		player.inAnim = true;
		t.SetAnimation("walk");
		TweenSettingsExtensions.SetEase<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOMoveX(((Component)t).transform, 15.63f, 1.5f, false), (Ease)1);
		yield return (object)new WaitForSeconds(1.5f);
		SetDirection(setFlip: false);
		t.SetAnimation("idle");
		player.inAnim = false;
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("Venham cá, crianças!~ O Nugget escreveu uma carta de amor para a Lily!", "¡Vengan todos, niños!~ ¡Nugget escribió a  Lily una carta de amor!", t));
		while (pEmptyOptions)
		{
			yield return null;
		}
		i.SetDirection(setFlip: true);
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("Ah, não, não, não. A carta do Nugget só deve ser lida pela bela Lily!", "Oh, no, no, no. ¡La carta de Nugget debe ser leída sólo por la preciosa Lily!", i));
		while (pEmptyOptions)
		{
			yield return null;
		}
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("\"O Nugget gosta da bela Lily. Ele também sente falta do irmão dela, o Billy.\"", "\"A Nugget le gusta la preciosa Lily. Además extraña a su hermano Billy.\"", t));
		while (pEmptyOptions)
		{
			yield return null;
		}
		ApplyTextureBlock(Embarassed);
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("Por favor, não continue!", "¡No sigas, por favor!", i));
		while (pEmptyOptions)
		{
			yield return null;
		}
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("\"O Nugget gosta do cabelo da Lily. O Nugget gosta de cheirar a...~cabeceira dela.\"", "\"A Nugget le gusta su cabello. A Nugget le gusta oler su...~cuello.\"", t));
		while (pEmptyOptions)
		{
			yield return null;
		}
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("Nugget, precisamos agendar outra visita ao orientador escolar? Isso está ficando bem estranho.", "Nugget ¿necesitamos programar otra visita al consejero de la escuela? Esto se está poniendo muy raro.", t));
		while (pEmptyOptions)
		{
			yield return null;
		}
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("O Nugget acha que você deveria parar então.", "Nugget cree que deberías parar.", i));
		while (pEmptyOptions)
		{
			yield return null;
		}
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("Talvez só mais algumas linhas...", "Tal vez sólo unos renglones más...", t));
		while (pEmptyOptions)
		{
			yield return null;
		}
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("\\bO NUGGET DISSE NÃO!!/b", "\\b¡¡NUGGET DIJO NO!!/b", i));
		yield return (object)new WaitForSeconds(0.25f);
		Object.FindObjectOfType<CameraFollow>().CameraShake(1f);
		while (pEmptyOptions)
		{
			yield return null;
		}
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("Okay... okay. Tá bom. Esquisitão.~ Voltem a fazer o que faziam, crianças.", "Okay...okay. Está bien. Bicho raro. ~ Como si fueran niños.", t));
		while (pEmptyOptions)
		{
			yield return null;
		}
		UI.CollapseDialogue();
		player.inAnim = true;
		t.SetDirection(setFlip: true);
		t.SetAnimation("walk");
		TweenSettingsExtensions.OnComplete<TweenerCore<Vector3, Vector3, VectorOptions>>(TweenSettingsExtensions.SetEase<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOMoveX(((Component)t).transform, 25.65f, 1.5f, false), (Ease)1), (TweenCallback)delegate
		{
			t.SetAnimation("idle");
			t.SetDirection(setFlip: false);
		});
		array = (Vector3[])(object)new Vector3[3]
		{
			new Vector3(18.26f, -0.56f, -0.55345f),
			new Vector3(10.56f, -0.56f, -0.55345f),
			new Vector3(10.56f, -1.65f, -1.64345f)
		};
		SetAnimation("walk");
		SetDirection(setFlip: false);
		TweenSettingsExtensions.OnComplete<TweenerCore<Vector3, Path, PathOptions>>(TweenSettingsExtensions.SetEase<TweenerCore<Vector3, Path, PathOptions>>(ShortcutExtensions.DOPath(((Component)this).transform, array, 2f, (PathType)0, (PathMode)1, 10, (Color?)null), (Ease)1), (TweenCallback)delegate
		{
			SetAnimation("idle");
			SetDirection(setFlip: true);
			player.inAnim = false;
			player.SetInteractable(this);
			((Behaviour)pCollider).enabled = true;
			Interact();
		});
		conversations[Room.Cafeteria].currentConversation = 1;
		i.SetCurrentConversation(19);
		CompleteMission(Mission.NuggetGiveLoveLetter);
		i.ActivateMission(Mission.NuggetDeliveredLetter);
		while (player.inDialogue)
		{
			yield return null;
		}
	}

	private void CheckForBug()
	{
		if (player.HasItem(Item.Bug))
		{
			lastSelectedOption.DestinationID = -1;
			player.ExplodePlayer("Não fale com a Lily se você tiver um dispositivo.", "No hables con Lily si tienes un dispositivo.");
		}
		else
		{
			CompleteMission(Mission.LilyTellAboutTheHatch);
		}
	}

	private void ActivateJanitorMission()
	{
		UnlockHint("Lily", 5);
		ActivateMission(Mission.LilyFindEvidence, Room.Classroom1);
		mLilyStatus = LilyStatus.DontLeaveCafeteria;
		conversations[Room.Cafeteria].currentConversation = 7;
	}

	private void UseShoe()
	{
		player.UseItem(Item.Shoe);
	}

	private void UseFinger()
	{
		player.UseItem(Item.SeveredFinger);
	}

	private void GoForwardWithPlan()
	{
		CompleteMission(Mission.LilyFindEvidence);
		ActivateMission(Mission.LilyTalkAtLunch, Room.Cafeteria);
		conversations[Room.Cafeteria].currentConversation = 11;
	}

	public IEnumerator MakePhoneCall()
	{
		player.inAnim = true;
		yield return (object)new WaitForSeconds(1f);
		player.inAnim = false;
		Principal p = Object.FindObjectOfType<Principal>();
		SetDirection(setFlip: false);
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("Bem pensado trazer esses cigarros. Agora me dê o telefone. Tenho uma ligação muito importante para fazer ao diretor.", "Bien pensado traer esos cigarrillos. Ahora dame el teléfono. Tengo una llamada muy importante que hacer al director.", this));
		while (pEmptyOptions)
		{
			yield return null;
		}
		player.UseItem(Item.Phone);
		SFXManager.Instance.PlaySound("DialSound");
		yield return (object)new WaitForSeconds(1f);
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("Umm...~ alô? Sr. Diretor?", "Mmm...~¿hola? ¿Señor Director?", this));
		while (pEmptyOptions)
		{
			yield return null;
		}
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("Lily?~ É você? Como está me ligando do telefone da sua professora? Passe-a para cá.", "¿Lily?~¿es usted? ¿Cómo me está llamando desde el teléfono de la profesora? Pásemela.", p));
		while (pEmptyOptions)
		{
			yield return null;
		}
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("Não, mas se quiser salvar a vida dela, é melhor ir para a sala de aula agora mesmo!", "No, pero si quiere salvarle la vida, ¡lo mejor es que vaya al salón de clases ahora mismo!", this));
		while (pEmptyOptions)
		{
			yield return null;
		}
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("O que significa isso?!~ Lily!?~ Me responda, senhorita!", "¡¿Qué significa todo esto?!~ ¿¡Lily!?~ ¡Contésteme, señorita!", p));
		while (pEmptyOptions)
		{
			yield return null;
		}
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("*Click*~ Isso deve bastar...~ é. Posso ouvi-lo descendo pelo corredor. Vamos nessa!", "*Clic*~ Debías hacerlo...~sip. Puedo oírlo bajando por el pasillo. ¡Vámonos!", this));
		while (pEmptyOptions)
		{
			yield return null;
		}
		UI.CollapseDialogue();
		player.inAnim = true;
		((Behaviour)pCollider).enabled = true;
		SetAnimation("walk");
		TweenSettingsExtensions.OnComplete<TweenerCore<Vector3, Vector3, VectorOptions>>(TweenSettingsExtensions.SetEase<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOMove(((Component)this).transform, new Vector3(-23.1f, -1f, -0.89f), 1f, false), (Ease)1), (TweenCallback)delegate
		{
			//IL_002c: Unknown result type (might be due to invalid IL or missing references)
			player.inAnim = false;
			SetAnimation("idle");
			((Component)this).transform.position = new Vector3(0f, 50f, 0f);
		});
		p.SetOutOfOffice();
		mLilyStatus = LilyStatus.HeadingToOffice;
	}

	private void GoForwardWithPlanLunch()
	{
		CompleteMission(Mission.LilyShowEvidence);
	}

	public void CheckLeaveCafeteria()
	{
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		if (mLilyStatus == LilyStatus.None)
		{
			((MonoBehaviour)this).StartCoroutine(WaitLeaveCafeteria());
		}
		else if (mLilyStatus != LilyStatus.DontLeaveCafeteria)
		{
			((Component)this).transform.position = new Vector3(0f, 50f, 0f);
		}
	}

	private IEnumerator WaitLeaveCafeteria()
	{
		EnvironmentController.Instance.waitForNextAction = true;
		while (EnvironmentController.Instance.waitForNextAction || UI.IsDialogueOut() || player.inAnim)
		{
			yield return null;
		}
		LeaveCafeteria();
	}

	public void LeaveCafeteria()
	{
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0126: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Expected O, but got Unknown
		if (mLilyStatus == LilyStatus.DontLeaveCafeteria)
		{
			return;
		}
		CameraFollow c = Object.FindObjectOfType<CameraFollow>();
		c.overrideCamera = true;
		ShortcutExtensions.DOMove(((Component)c).transform, new Vector3(c.maxPosX, c.minPosY, -30f), 0.5f, false);
		player.inAnim = true;
		Vector3[] array = (Vector3[])(object)new Vector3[2]
		{
			new Vector3(32f, -14.44f, -14.43f),
			new Vector3(23.5f, -0.5f, -0.52f)
		};
		SetDirection(setFlip: true);
		SetAnimation("walk");
		((Behaviour)pCollider).enabled = false;
		if ((Object)(object)player.GetInteractable() == (Object)(object)this)
		{
			player.SetInteractable(null);
		}
		TweenSettingsExtensions.OnComplete<TweenerCore<Vector3, Path, PathOptions>>(TweenSettingsExtensions.OnWaypointChange<TweenerCore<Vector3, Path, PathOptions>>(TweenSettingsExtensions.SetEase<TweenerCore<Vector3, Path, PathOptions>>(ShortcutExtensions.DOPath(((Component)this).transform, array, 2.5f, (PathType)0, (PathMode)1, 10, (Color?)null), (Ease)1), (TweenCallback<int>)delegate(int x)
		{
			if (x == 1)
			{
				SetDirection(setFlip: false);
			}
		}), (TweenCallback)delegate
		{
			//IL_004c: Unknown result type (might be due to invalid IL or missing references)
			player.inAnim = false;
			SetAnimation("idle");
			((Behaviour)pCollider).enabled = true;
			((Component)this).transform.position = new Vector3(50f, 0f, 0f);
			if (mLilyStatus == LilyStatus.None)
			{
				mLilyStatus = LilyStatus.OutsideOffice;
			}
			((MonoBehaviour)this).StartCoroutine(MoveCameraBack(c));
		});
	}

	private IEnumerator MoveCameraBack(CameraFollow c)
	{
		for (int i = 0; i < 60; i++)
		{
			((Component)c).transform.position = Vector3.Slerp(((Component)c).transform.position, new Vector3(Mathf.Clamp(((Component)player).transform.position.x, c.minPosX, c.maxPosX), Mathf.Clamp(((Component)player).transform.position.y, c.minPosY, c.maxPosY), -30f), 0.1f);
			yield return null;
		}
		c.overrideCamera = false;
	}

	private void MeetLilyInBathroom()
	{
		CompleteMission(Mission.LilyTalkAtLunch);
		CompleteMission(Mission.LilyShowCode);
		ActivateMission(Mission.LilyMeetInBathroom, Room.Cafeteria);
		mLilyStatus = LilyStatus.HeadingToBathroom;
		LeaveCafeteria();
	}

	public void CheckHallwayLilyStatus()
	{
		//IL_0172: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f1: Expected O, but got Unknown
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_013e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0148: Expected O, but got Unknown
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		switch (mLilyStatus)
		{
		case LilyStatus.OutsideOffice:
			((Component)this).transform.position = new Vector3(-24.5f, -6.4f, -6.39f);
			GameObject.Find("PrincipalDoor").GetComponent<ObjectInteractable>().dialogue.Nodes[0].Options[0].IsAvailable = true;
			UnlockHint("Teacher", 6);
			SetDepth();
			break;
		case LilyStatus.HeadingToOffice:
			player.lockActions = true;
			((Component)this).transform.position = new Vector3(15f, -1.7f, -1.7f);
			SetDepth();
			SetAnimation("walk");
			SetDirection(setFlip: false);
			((Behaviour)pCollider).enabled = false;
			((Behaviour)GameObject.Find("BathroomDoor").GetComponent<Collider2D>()).enabled = false;
			((Behaviour)GameObject.Find("JanitorHallwayDoor").GetComponent<Collider2D>()).enabled = false;
			((Behaviour)GameObject.Find("CafeteriaDoorHallway").GetComponent<Collider2D>()).enabled = false;
			TweenSettingsExtensions.OnComplete<TweenerCore<Vector3, Vector3, VectorOptions>>(TweenSettingsExtensions.SetEase<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOMove(((Component)this).transform, new Vector3(-27f, -6.4f, -6.39f), 3f, false), (Ease)1), (TweenCallback)delegate
			{
				((Behaviour)pCollider).enabled = true;
				SetAnimation("idle");
			});
			break;
		case LilyStatus.HeadingToBathroom:
			SetCurrentConversation(4);
			player.lockActions = true;
			((Component)this).transform.position = new Vector3(-13f, -1f, -1.2f);
			SetAnimation("walk");
			SetDirection(setFlip: true);
			((Behaviour)pCollider).enabled = false;
			((Behaviour)GameObject.Find("JanitorHallwayDoor").GetComponent<Collider2D>()).enabled = false;
			((Behaviour)GameObject.Find("CafeteriaDoorHallway").GetComponent<Collider2D>()).enabled = false;
			TweenSettingsExtensions.OnComplete<TweenerCore<Vector3, Vector3, VectorOptions>>(TweenSettingsExtensions.SetEase<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOMoveX(((Component)this).transform, 15f, 2f, false), (Ease)1), (TweenCallback)delegate
			{
				//IL_002c: Unknown result type (might be due to invalid IL or missing references)
				SetAnimation("idle");
				((Behaviour)pCollider).enabled = true;
				((Component)this).transform.position = new Vector3(0f, 50f, 0f);
			});
			break;
		}
	}

	private void KnockOnDoor()
	{
		((MonoBehaviour)this).StartCoroutine(KnockOnDoorWithLily());
	}

	private IEnumerator KnockOnDoorWithLily()
	{
		Principal p = Object.FindObjectOfType<Principal>();
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("Que diachos--?! É hora do almoço! Quem está batendo na minha porta!?", "¡¿Qué carajos--?! ¡Es la hora de almuerzo! ¿¡Quién está tocando a mi puerta?", p));
		FacePlayer();
		while (pEmptyOptions)
		{
			yield return null;
		}
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("O que você está fazendo?! Você vai nos meter em problemas!", "¡¿Qué estás haciendo?! ¡Vas a meternos en problemas!", this));
		while (pEmptyOptions)
		{
			yield return null;
		}
		player.ForceAnim(walk: true);
		player.ForceChangeDirection(right: true);
		player.inAnim = true;
		TweenSettingsExtensions.OnComplete<TweenerCore<Vector3, Vector3, VectorOptions>>(TweenSettingsExtensions.SetEase<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOMoveX(((Component)player).transform, -19f, 1f, false), (Ease)1), (TweenCallback)delegate
		{
			player.ForceChangeDirection(right: false);
			player.ForceAnim(walk: false);
			player.inAnim = false;
			player.SetInteractable(p);
		});
		((Component)p).transform.position = new Vector3(-27.9f, -7.94f, -7.91f);
		p.SetDepth();
		p.Interact();
		p.SetDirection(setFlip: true);
	}

	private void EnterOffice()
	{
		EnvironmentController.Instance.SetSpawnPoint(1);
		EnvironmentController.Instance.ChangeEnvironment(Room.Office);
		if (mLilyStatus != LilyStatus.HeadingToOffice)
		{
			Object.FindObjectOfType<Principal>().mReason = Principal.OfficeReason.UsedKey;
		}
	}

	private void CompleteGumLunch()
	{
        // Função mantida conforme o final original do arquivo
    }
}
