using Spine.Unity.MeshGeneration;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace Spine.Unity;

[ExecuteInEditMode]
[RequireComponent(typeof(CanvasRenderer), typeof(RectTransform))]
[DisallowMultipleComponent]
[AddComponentMenu("Spine/SkeletonGraphic (Unity UI Canvas)")]
public class SkeletonGraphic : MaskableGraphic, ISkeletonComponent, IAnimationStateComponent, ISkeletonAnimation
{
	public SkeletonDataAsset skeletonDataAsset;

	[SpineSkin("", "skeletonDataAsset")]
	public string initialSkinName = "default";

	[SpineAnimation("", "skeletonDataAsset")]
	public string startingAnimation;

	public bool startingLoop;

	public float timeScale = 1f;

	public bool freeze;

	public bool unscaledTime;

	protected Skeleton skeleton;

	protected AnimationState state;

	protected ISimpleMeshGenerator spineMeshGenerator;

	public SkeletonDataAsset SkeletonDataAsset => skeletonDataAsset;

	public override Texture mainTexture
	{
		get
		{
			if ((Object)(object)skeletonDataAsset == (Object)null)
			{
				return null;
			}
			return skeletonDataAsset.atlasAssets[0].materials[0].mainTexture;
		}
	}

	public Skeleton Skeleton => skeleton;

	public SkeletonData SkeletonData
	{
		get
		{
			if (skeleton == null)
			{
				return null;
			}
			return skeleton.data;
		}
	}

	public bool IsValid => skeleton != null;

	public AnimationState AnimationState => state;

	public ISimpleMeshGenerator SpineMeshGenerator => spineMeshGenerator;

	public event UpdateBonesDelegate UpdateLocal;

	public event UpdateBonesDelegate UpdateWorld;

	public event UpdateBonesDelegate UpdateComplete;

	protected override void Awake()
	{
		((UIBehaviour)this).Awake();
		if (!IsValid)
		{
			Initialize(overwrite: false);
			((Graphic)this).Rebuild((CanvasUpdate)3);
		}
	}

	public override void Rebuild(CanvasUpdate update)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Invalid comparison between Unknown and I4
		((Graphic)this).Rebuild(update);
		if (!((Graphic)this).canvasRenderer.cull && (int)update == 3)
		{
			UpdateMesh();
		}
	}

	public virtual void Update()
	{
		if (!freeze)
		{
			Update((!unscaledTime) ? Time.deltaTime : Time.unscaledDeltaTime);
		}
	}

	public virtual void Update(float deltaTime)
	{
		if (IsValid)
		{
			deltaTime *= timeScale;
			skeleton.Update(deltaTime);
			state.Update(deltaTime);
			state.Apply(skeleton);
			if (this.UpdateLocal != null)
			{
				this.UpdateLocal(this);
			}
			skeleton.UpdateWorldTransform();
			if (this.UpdateWorld != null)
			{
				this.UpdateWorld(this);
				skeleton.UpdateWorldTransform();
			}
			if (this.UpdateComplete != null)
			{
				this.UpdateComplete(this);
			}
		}
	}

	public void LateUpdate()
	{
		if (!freeze)
		{
			UpdateMesh();
		}
	}

	public void Clear()
	{
		skeleton = null;
		((Graphic)this).canvasRenderer.Clear();
	}

	public void Initialize(bool overwrite)
	{
		if ((IsValid && !overwrite) || (Object)(object)skeletonDataAsset == (Object)null)
		{
			return;
		}
		SkeletonData skeletonData = skeletonDataAsset.GetSkeletonData(quiet: false);
		if (skeletonData == null || skeletonDataAsset.atlasAssets.Length == 0 || skeletonDataAsset.atlasAssets[0].materials.Length == 0)
		{
			return;
		}
		state = new AnimationState(skeletonDataAsset.GetAnimationStateData());
		if (state == null)
		{
			Clear();
			return;
		}
		skeleton = new Skeleton(skeletonData);
		spineMeshGenerator = new ArraysSimpleMeshGenerator();
		spineMeshGenerator.PremultiplyVertexColors = true;
		if (!string.IsNullOrEmpty(initialSkinName))
		{
			skeleton.SetSkin(initialSkinName);
		}
		if (!string.IsNullOrEmpty(startingAnimation))
		{
			state.SetAnimation(0, startingAnimation, startingLoop);
		}
	}

	public void UpdateMesh()
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		if (IsValid)
		{
			skeleton.SetColor(((Graphic)this).color);
			if ((Object)(object)((Graphic)this).canvas != (Object)null)
			{
				spineMeshGenerator.Scale = ((Graphic)this).canvas.referencePixelsPerUnit;
			}
			((Graphic)this).canvasRenderer.SetMesh(spineMeshGenerator.GenerateMesh(skeleton));
		}
	}
}
