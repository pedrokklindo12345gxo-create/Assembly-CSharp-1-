using System.Collections;
using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using DialogueTree;
using UnityEngine;

public class Janitor : NPCBehavior
{
	public TextureBlock bloody;

	public TextureBlock ear;

	public Sprite cleanBathroomSprite;

	private bool walkingBackFromToilet;

	private bool stall1Check;

	private bool stall2Check;

	private int mStoredConvo;

	private bool mUnscrewedShelf;

	public void KillPlayer()
	{
		((MonoBehaviour)this).StartCoroutine(KillPlayerCoroutine("Não leve os avisos do conserje na brincadeira.", "No tome las advertencias del portero ligeramente."));
		((Behaviour)pCollider).enabled = false;
	}

	public void KillPlayer(string s, string span)
	{
		((MonoBehaviour)this).StartCoroutine(KillPlayerCoroutine(s, span));
		((Behaviour)pCollider).enabled = false;
	}

	private IEnumerator KillPlayerCoroutine(string s, string span)
	{
		player.inAnim = true;
		UI.showDeath = true;
		ParticleSystem p = GameObject.Find("PlayerBloodSplat").GetComponent<ParticleSystem>();
		SetAnimation("attack");
		player.GetSkeleton().timeScale = 0.66f;
		yield return (object)new WaitForSeconds(0.2667f);
		player.PlayAnimation("hit");
		for (int j = 0; j < 3; j++)
		{
			SFXManager.Instance.PlaySound("BasicHit");
			yield return (object)new WaitForSeconds(0.5f);
			player.ApplyTextureBlock(player.bruisedBloody);
		}
		player.PlayAnimation("writhing");
		player.GetSkeleton().timeScale = 0.1f;
		yield return (object)new WaitForSeconds(0.5f);
		SetAnimation("walk");
		if (((Component)this).transform.position.x > ((Component)player).transform.position.x)
		{
			TweenSettingsExtensions.SetEase<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOMove(((Component)this).transform, ((Component)player).transform.position + Vector3.right + Vector3.up * 0.1f, 0.5f, false), (Ease)1);
		}
		else
		{
			Transform transform = ((Component)p).transform;
			transform.localPosition -= 2f * Vector3.right * ((Component)p).transform.localPosition.x;
			TweenSettingsExtensions.SetEase<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOMove(((Component)this).transform, ((Component)player).transform.position - Vector3.right + Vector3.up * 0.1f, 0.5f, false), (Ease)1);
		}
		yield return (object)new WaitForSeconds(0.5f);
		SetDepth();
		SetAnimation("attack");
		player.GetSkeleton().timeScale = 1f;
		for (int j = 0; j < 4; j++)
		{
			yield return (object)new WaitForSeconds(0.2667f);
			player.ActivateBloody();
			p.Play();
			SFXManager.Instance.PlaySound("GoreSplat" + Random.Range(2, 4));
			yield return (object)new WaitForSeconds(0.2333f);
			ApplyTextureBlock(bloody);
		}
		int x = 0;
		while (player.GetSkeleton().timeScale > 0.01f)
		{
			yield return (object)new WaitForSeconds(0.23f);
			p.Play();
			player.GetSkeleton().timeScale *= 0.5f;
			SFXManager.Instance.PlaySound("GoreSplat" + Random.Range(2, 4));
			yield return (object)new WaitForSeconds(0.27f);
			x++;
			if (x == 2)
			{
				UI.ShowDeath(s, span);
			}
		}
		SetAnimation("idle");
	}

	public void EnableToiletConversation()
	{
		conversations[Room.Bathroom].Nodes[0].Options[1].SetAvailable();
	}

	private void GetBuck()
	{
		player.GetMoney(1f);
	}

	private void CheckEndBathroom()
	{
		if (EnvironmentController.Instance.ActionsLeft() == 1)
		{
			lastSelectedOption.DestinationID = 71;
		}
	}

	public void CheckStall1()
	{
		stall1Check = true;
		if (stall2Check)
		{
			conversations[Room.Bathroom].Nodes[23].Options[0].SetAvailable();
			conversations[Room.Bathroom].Nodes[56].Options[0].SetAvailable();
		}
	}

	public void CheckStall2()
	{
		stall2Check = true;
		if (stall1Check)
		{
			conversations[Room.Bathroom].Nodes[23].Options[0].SetAvailable();
			conversations[Room.Bathroom].Nodes[56].Options[0].SetAvailable();
		}
	}

	public void WalkToStall()
	{
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		if (EnvironmentController.Instance.ActionsLeft() == 1)
		{
			lastSelectedOption.DestinationID = 69;
			return;
		}
		((Behaviour)GameObject.Find("BathroomBoxes").GetComponent<Collider2D>()).enabled = false;
		((Behaviour)GameObject.Find("BathroomBox1").GetComponent<Collider2D>()).enabled = true;
		((Behaviour)GameObject.Find("BathroomBox2").GetComponent<Collider2D>()).enabled = true;
		((Behaviour)GameObject.Find("BathroomBox3").GetComponent<Collider2D>()).enabled = true;
		SetDirection(setFlip: true);
		WalkToPoint(new Vector3(25f, -3.21f), 3f);
		((MonoBehaviour)this).StartCoroutine(CloseJanDialogue());
	}

	private IEnumerator CloseJanDialogue()
	{
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("Criança estúpida...~me fazendo limpar o banheiro estúpido...~com o meu esfregão estúpido...~porque é o meu trabalho estúpido.", "Estúpido niño...~haciendome limpiar el estúpido baño...~con mi estúpido trapeador...~porque es mi estúpido trabajo.", this));
		while (pEmptyOptions)
		{
			yield return null;
		}
		conversations[Room.Bathroom].currentConversation = 26;
		SFXManager.Instance.PlaySound("Confirm");
		UI.CollapseDialogue();
		((MonoBehaviour)this).StartCoroutine(WaitWalkBack());
	}

	private IEnumerator WaitWalkBack()
	{
		EnvironmentController.Instance.waitForNextAction = true;
		while (EnvironmentController.Instance.waitForNextAction && EnvironmentController.currentRoom == Room.Bathroom)
		{
			yield return null;
		}
		((Behaviour)GameObject.Find("BathroomBoxes").GetComponent<Collider2D>()).enabled = true;
		((Behaviour)GameObject.Find("BathroomBox1").GetComponent<Collider2D>()).enabled = false;
		((Behaviour)GameObject.Find("BathroomBox2").GetComponent<Collider2D>()).enabled = false;
		((Behaviour)GameObject.Find("BathroomBox3").GetComponent<Collider2D>()).enabled = false;
		SetDirection(setFlip: false);
		GameObject.Find("Bathroom").GetComponent<SpriteRenderer>().sprite = cleanBathroomSprite;
		GameObject.Find("Toilet").GetComponent<ObjectInteractable>().GetDialogue()
			.currentConversation = 1;
		if (EnvironmentController.currentRoom == Room.Bathroom)
		{
			walkingBackFromToilet = true;
			WalkToPoint(new Vector3(-12.4f, -8.3f, -8.4f), 3f);
			yield return (object)new WaitForSeconds(3f);
			if (EnvironmentController.Instance.ActionsLeft() == 1)
			{
				SetCurrentConversation(68);
			}
			else
			{
				SetCurrentConversation(20);
				walkingBackFromToilet = false;
			}
			Interact();
		}
		else
		{
			conversations[Room.Bathroom].currentConversation = 20;
		}
	}

	private void GetCardBathroom()
	{
		UnlockHint("Monstermon", 16);
		player.GetItem(Item.EyeOfTheButtholder);
	}

	public void GetNickel()
	{
		player.GetMoney(0.05f);
	}

	public void GetFive()
	{
		player.GetMoney(5f);
	}

	private void GetOglebopGolem()
	{
		player.GetItem(Item.OglebopGolem);
		UnlockHint("Monstermon", 16);
		((Behaviour)GameObject.Find("OglebopGolemTrigger").GetComponent<BoxCollider2D>()).enabled = false;
	}

	private void EnableCheapChocolate()
	{
		LunchLady lunchLady = Object.FindObjectOfType<LunchLady>();
		UnlockHint("Monty", 3);
		lunchLady.conversations[Room.Cafeteria].Nodes[18].Options[2].IsAvailable = true;
		lunchLady.conversations[Room.Cafeteria].Nodes[21].Options[1].IsAvailable = true;
	}

	public void CheckBoxes()
	{
		mStoredConvo = conversations[Room.Bathroom].currentConversation;
		SetCurrentConversation(62);
		Interact();
	}

	private void ResetConvo()
	{
		conversations[Room.Bathroom].currentConversation = mStoredConvo;
	}

	private void KillPlayerAt5()
	{
		KillPlayer("Eu deveria ter prestado atenção da próxima vez.", "La próxima vez lo entenderé.");
	}

	private void GetFinger()
	{
		player.GetItem(Item.SeveredFinger);
		if (UI.IsMissionActive(Mission.LilyFindEvidence))
		{
			CompleteMission(Mission.LilyFindEvidence);
			Object.FindObjectOfType<Lily>().ActivateMission(Mission.LilyShowEvidence);
		}
	}

	private void GetCardJeromePass()
	{
		player.GetItem(Item.ManWithLongArm);
		UnlockHint("Monstermon", 17);
	}

	private void GetShoe()
	{
		player.GetItem(Item.Shoe);
		if (UI.IsMissionActive(Mission.LilyFindEvidence))
		{
			CompleteMission(Mission.LilyFindEvidence);
			Object.FindObjectOfType<Lily>().ActivateMission(Mission.LilyShowEvidence);
		}
	}

	public void EndBathroom()
	{
		if (!walkingBackFromToilet)
		{
			SetCurrentConversation(63);
			Interact();
		}
	}

	private void GoBackToClass()
	{
		EnvironmentController.Instance.SetSpawnPoint(1);
		EnvironmentController.Instance.ChangeEnvironment(Room.Classroom1);
	}

	public void EndBathroomCafeteria()
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		((Component)this).transform.position = new Vector3(-23.34f, -0.6f, 0f);
		SetDepth();
		SetDirection(setFlip: true);
		player.ForceChangeDirection(right: false);
		SetCurrentConversation(64);
		Interact();
	}

	private void BathroomCafeteria()
	{
		((MonoBehaviour)this).StartCoroutine(RunBathroomCafeteria());
	}

	private IEnumerator RunBathroomCafeteria()
	{
		WalkToPoint(((Component)player).transform.position - Vector3.right * 3f, 2f);
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("Nem a pau! Você e o filhinho do diretor estão agindo estranho desde que arrombaram meu armário.~ Esvaziem os bolsos! Agora!", "¡Gran oportunidad! Tú y el hijo del director han estado actuando raro desde que mi aramario fue asaltado. ~ ¡Vacien sus bolsillos! ¡Ahora!", this));
		while (pEmptyOptions)
		{
			yield return null;
		}
		if (player.HasItem(Item.LaserPointer))
		{
			SetCurrentConversation(66);
		}
		else
		{
			SetCurrentConversation(65);
		}
		Interact();
	}

	private void KillPlayerLaserBathroom()
	{
		KillPlayer("O conserje vem recolher o lixo depois que o sinal toca.", "El conserje viene a recoger la basura después de que suena la campana.");
	}

	private void GoToRecess()
	{
		EnvironmentController.Instance.ChangeEnvironment(Room.Recess);
	}

	private void ExitBathroom()
	{
		EnvironmentController.Instance.SetSpawnPoint(4);
		EnvironmentController.Instance.ChangeEnvironment(Room.Hallway);
	}

	private void GetBiscuitBall()
	{
		player.GetItem(Item.BiscuitBall);
	}

	private void KillMonty()
	{
		conversations[Room.Cafeteria].Nodes[0].Options[1].IsAvailable = false;
		((MonoBehaviour)this).StartCoroutine(GoKillMonty());
	}

	private IEnumerator GoKillMonty()
	{
		((Behaviour)pCollider).enabled = false;
		Vector3 origin = ((Component)this).transform.position;
		Monty i = Object.FindObjectOfType<Monty>();
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("Ugh. É aquele CDF de óculos?~ Quem eu tô enganando? Claro que é.", "Iugh. ¿Aquel es el bobo con lentes?~ ¿A quién engaño? Por supuesto que es él.", this));
		while (pEmptyOptions)
		{
			yield return null;
		}
		SetDirection(setFlip: true);
		WalkToPoint(new Vector3(11.7f, -10f, -10.5f), 3f);
		player.ForceChangeDirection(right: true);
		i.SetDirection(setFlip: false);
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("Ei!~ Nerd!", "¡Hey! ~ ¡nerdo!", this));
		while (pEmptyOptions)
		{
			yield return null;
		}
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("Ummm...~o que você quer? Tem alguma muamba de conserje que quer me vender?", "Ummm...~ ¿Qué quieres? ¿Tienes alguna cosa del conserje que quieras venderme?", i));
		while (pEmptyOptions)
		{
			yield return null;
		}
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("Não, mas eu trouxe um caixão para você comprar!", "¡No, pero tengo un ataúd para que compres!", this));
		while (pEmptyOptions)
		{
			yield return null;
		}
		SetAnimation("attack");
		yield return (object)new WaitForSeconds(0.25f);
		i.SetAnimation("fallover");
		i.ApplyTextureBlock(i.noGlasses);
		SFXManager.Instance.PlaySound("BasicHit");
		GameObject g = GameObject.Find("MontyGlasses");
		((Renderer)g.GetComponent<SpriteRenderer>()).enabled = true;
		g.GetComponent<Rigidbody2D>().simulated = true;
		g.GetComponent<Rigidbody2D>().AddForce(new Vector2(-300f, 500f));
		g.GetComponent<Rigidbody2D>().AddTorque(50f);
		player.inAnim = true;
		yield return (object)new WaitForSeconds(0.25f);
		SetAnimation("walk");
		TweenSettingsExtensions.OnComplete<TweenerCore<Vector3, Vector3, VectorOptions>>(TweenSettingsExtensions.SetEase<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOMove(((Component)this).transform, new Vector3(13.5f, -10f, -9.5f), 1f, false), (Ease)1), (TweenCallback)delegate
		{
			i.SetAnimation("writhing");
			SetAnimation("attack");
			player.inAnim = false;
		});
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("Que isso te sirva de lição sobre ficar corrigindo a ortografia dos outros!", "¡Dejemos ésto como una lección para ti sobre corregir el deltreo de las personas!", this));
		ParticleSystem p = GameObject.Find("GeneralBloodSplat").GetComponent<ParticleSystem>();
		ParticleSystem ps = GameObject.Find("CafeteriaBloodStream").GetComponent<ParticleSystem>();
		((Component)p).transform.position = new Vector3(16f, -10f, -14f);
		yield return (object)new WaitForSeconds(1.2667f);
		((Component)ps).transform.localPosition = new Vector3(16.25f, -9.19f, -15f);
		p.Play();
		SFXManager.Instance.PlaySound("GoreSplat" + Random.Range(2, 4));
		yield return (object)new WaitForSeconds(0.2333f);
		ApplyTextureBlock(bloody);
		i.ApplyTextureBlock(i.bloody);
		while (pEmptyOptions)
		{
			yield return (object)new WaitForSeconds(0.2667f);
			p.Play();
			SFXManager.Instance.PlaySound("GoreSplat" + Random.Range(2, 4));
			yield return (object)new WaitForSeconds(0.2333f);
		}
		ps.Play();
		SetAnimation("idle");
		i.mySkeleton.timeScale = 0.5f;
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("Pronto...~lições aprendidas. Limites estabelecidos.", "Ahí...~lecciones aprendidas. La guerra está declarada.", this));
		while (pEmptyOptions)
		{
			yield return null;
		}
		UI.CollapseDialogue();
		SetDirection(setFlip: false);
		i.SetDead();
		UI.CompleteMission(Mission.TeacherGetMontyInTrouble);
		SetCurrentConversation(12);
		i.SetCurrentConversation(6);
		i.ResizeCollider();
		g.layer = 0;
		g.GetComponent<Rigidbody2D>().bodyType = (RigidbodyType2D)1;
		player.inAnim = true;
		WalkToPoint(g.transform.position + Vector3.right * 0.5f, 1f, x: true);
		yield return (object)new WaitForSeconds(1.5f);
		g.SetActive(false);
		WalkToPoint(origin, 2f, x: true);
		yield return (object)new WaitForSeconds(2f);
		Interact();
		player.inAnim = false;
	}

	private void GetGlasses()
	{
		player.GetItem(Item.MontyGlasses);
	}

	private void StopWait()
	{
		EnvironmentController.Instance.waitForNextAction = false;
		player.SetInteractable(null);
	}

	public IEnumerator AppearAndSearch()
	{
		EnvironmentController.Instance.waitForNextAction = true;
		LunchLady j = Object.FindObjectOfType<LunchLady>();
		Jerome i = Object.FindObjectOfType<Jerome>();
		SetDirection(setFlip: false);
		UnlockHint("Jerome", 4);
		while (EnvironmentController.Instance.waitForNextAction)
		{
			yield return null;
		}
		((Component)this).transform.position = new Vector3(19.81f, -0.87f, -0.97f);
		player.inDialogue = true;
		player.ForceChangeDirection(((Component)player).transform.position.x < ((Component)this).transform.position.x);
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("E então?!~ Alguém quer dar um passo à frente?~~ Não?~ Nossa, que surpresa!", "¡¿Entonces?!~ ¿Alguien quiere dar un paso al frente? ~~ ¿No?~ ¡Qué sorpresa!", this));
		while (pEmptyOptions)
		{
			yield return null;
		}
		WalkToPoint(new Vector3(16.94f, -3.4f, -3.5f), 1f);
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("E quanto a você, mini subdiretor? Eu peguei sua coisinha de laser hoje de manhã. Certeza que você quer de volta!", "¿Y qué tal tú, directorcito?  Yo tomé tu cosita de lasercito esta mañana. ¡Seguro la quieres de vuelta!", this));
		while (pEmptyOptions)
		{
			yield return null;
		}
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("Me reviste cara.~ Eu não tô com isso, então some daqui ou eu conto pro meu pai que você mijou no bebedouro de novo.", "A mí que me registren. ~ Yo no lo tengo, así que jódete o le diré a mi padre que otra vez orinaste la fuente de agua.", i));
		while (pEmptyOptions)
		{
			yield return null;
		}
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("...~Você venceu dessa vez, pirralho.", "...~Ganaste esta ronda, niño.", this));
		while (pEmptyOptions)
		{
			yield return null;
		}
		if (((Component)player).transform.position.x > ((Component)this).transform.position.x)
		{
			player.ForceChangeDirection(right: false);
			SetDirection(setFlip: true);
			WalkToPoint(((Component)player).transform.position - new Vector3(2.5f, -0.1f, 0f), 1f);
		}
		else
		{
			player.ForceChangeDirection(right: true);
			SetDirection(setFlip: false);
			WalkToPoint(((Component)player).transform.position + new Vector3(2.5f, 0.1f, 0f), 1f);
		}
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("E você?~ Esteve mexendo no meu armário?~ Vira os bolsos.", "¿Y tú?~ ¿Has estado en mi armario?~ Vacia tus bolcillos.", this));
		yield return (object)new WaitForSeconds(1f);
		((Behaviour)pCollider).enabled = false;
		while (pEmptyOptions)
		{
			yield return null;
		}
		if (player.HasItem(Item.LaserPointer))
		{
			((MonoBehaviour)this).StartCoroutine(RunDialogueSection("A coisinha de laser! Eu sabia que você tava com ela!", "¡La cosita de lasercito! ¡Sabía que la tenías!", this));
			while (pEmptyOptions)
			{
				yield return null;
			}
			KillPlayer("Esconda o ponteiro laser antes que o conserje chegue à cafeteria.", "Oculta el puntero láser antes de que el conserje llegue a la cafetería.");
			yield break;
		}
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("Hmmmm... nada.~ Continuo de olho em você.", "Hmmmm...nada.' Te sigo vigilando.", this));
		while (pEmptyOptions)
		{
			yield return null;
		}
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("Ah, deixa essa pobre criatura em paz! Você vive procurando desculpa pra enfiar um esfregão em uma criança!", "¡Oh, deja en paz a esta pobre criaturita! ¡Tú siempre estás buscando una razón para empalar a un niño con ese trapeador!", j));
		while (pEmptyOptions)
		{
			yield return null;
		}
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("E daí se eu procuro?~ Não tem nada de errado em enfiar um esfregão em criança!", "¿Y qué sí lo hago?~ ¡No hay nada malo con empalar a un niño!", this));
		while (pEmptyOptions)
		{
			yield return null;
		}
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("Vai logo vender sua carne misteriosa!", "¡Vete a vender tu carne misteriosa!", j));
		while (pEmptyOptions)
		{
			yield return null;
		}
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("Tá bom! Mas marquem minhas palavras... alguém vai pagar por ter entrado no meu armário.", "¡Perfecto! Pero recuerda mis palabras…..Alguien pagará por meterse en mi armario.", this));
		WalkToPoint(new Vector3(-6f, -5.4f, -5.5f), 1.5f);
		while (pEmptyOptions)
		{
			yield return null;
		}
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("Na verdade, antes de começar, aquela lata de lixo precisa ser esvaziada. Vá cuidar disso.", "De hecho, antes de que empieces ese bote de basura necesita ser vaciado. Así que encárgate de eso.", j));
		while (pEmptyOptions)
		{
			yield return null;
		}
		SetDirection(setFlip: true);
		WalkToPoint(new Vector3(3.18f, -1.33f, -1.44f), 1f);
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("*Resmungos*~ Cozinheira chata...~me fazendo fazer meu trabalho idiota.", "*Refunfuña*~ Cocinera estúpida...~me hizo hacer mi estúpido trabajo.", this));
		while (pEmptyOptions)
		{
			yield return null;
		}
		((Renderer)((Component)((Component)this).transform.GetChild(1)).GetComponent<SpriteRenderer>()).enabled = true;
		WalkToPoint(new Vector3(18.35f, -1.33f, -1.44f), 1.5f);
		yield return (object)new WaitForSeconds(1.5f);
		WalkToPoint(new Vector3(20.11f, -0.3f, -0.4f), 0.5f);
		yield return (object)new WaitForSeconds(0.5f);
		((Component)this).transform.position = new Vector3(0f, 50f, 0f);
		yield return (object)new WaitForSeconds(2f);
		((Component)this).transform.position = new Vector3(20.11f, -1.5f, -0.4f);
		SetDirection(setFlip: false);
	}
}
