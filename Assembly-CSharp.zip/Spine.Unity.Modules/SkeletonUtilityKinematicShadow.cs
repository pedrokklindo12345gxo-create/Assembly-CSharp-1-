using System.Collections.Generic;
using UnityEngine;

namespace Spine.Unity.Modules;

public class SkeletonUtilityKinematicShadow : MonoBehaviour
{
	private struct TransformPair
	{
		public Transform dest;

		public Transform src;
	}

	[Tooltip("If checked, the hinge chain can inherit your root transform's velocity or position/rotation changes.")]
	public bool detachedShadow;

	public Transform parent;

	public bool hideShadow = true;

	private GameObject shadowRoot;

	private readonly List<TransformPair> shadowTable = new List<TransformPair>();

	private void Start()
	{
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_005a: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		shadowRoot = Object.Instantiate<GameObject>(((Component)this).gameObject);
		Object.Destroy((Object)(object)shadowRoot.GetComponent<SkeletonUtilityKinematicShadow>());
		Transform transform = shadowRoot.transform;
		transform.position = ((Component)this).transform.position;
		transform.rotation = ((Component)this).transform.rotation;
		Vector3 val = ((Component)this).transform.TransformPoint(Vector3.right);
		float num = Vector3.Distance(((Component)this).transform.position, val);
		transform.localScale = Vector3.one;
		if (!detachedShadow)
		{
			if ((Object)(object)parent == (Object)null)
			{
				transform.parent = ((Component)this).transform.root;
			}
			else
			{
				transform.parent = parent;
			}
		}
		if (hideShadow)
		{
			((Object)shadowRoot).hideFlags = (HideFlags)1;
		}
		Joint[] componentsInChildren = shadowRoot.GetComponentsInChildren<Joint>();
		foreach (Joint obj in componentsInChildren)
		{
			obj.connectedAnchor *= num;
		}
		SkeletonUtilityBone[] componentsInChildren2 = ((Component)this).GetComponentsInChildren<SkeletonUtilityBone>();
		SkeletonUtilityBone[] componentsInChildren3 = shadowRoot.GetComponentsInChildren<SkeletonUtilityBone>();
		SkeletonUtilityBone[] array = componentsInChildren2;
		foreach (SkeletonUtilityBone skeletonUtilityBone in array)
		{
			if ((Object)(object)((Component)skeletonUtilityBone).gameObject == (Object)(object)((Component)this).gameObject)
			{
				continue;
			}
			SkeletonUtilityBone[] array2 = componentsInChildren3;
			foreach (SkeletonUtilityBone skeletonUtilityBone2 in array2)
			{
				if ((Object)(object)((Component)skeletonUtilityBone2).GetComponent<Rigidbody>() != (Object)null && skeletonUtilityBone2.boneName == skeletonUtilityBone.boneName)
				{
					shadowTable.Add(new TransformPair
					{
						dest = ((Component)skeletonUtilityBone).transform,
						src = ((Component)skeletonUtilityBone2).transform
					});
					break;
				}
			}
		}
		Component[] components = (Component[])(object)componentsInChildren3;
		DestroyComponents(components);
		components = (Component[])(object)((Component)this).GetComponentsInChildren<Joint>();
		DestroyComponents(components);
		components = (Component[])(object)((Component)this).GetComponentsInChildren<Rigidbody>();
		DestroyComponents(components);
		components = (Component[])(object)((Component)this).GetComponentsInChildren<Collider>();
		DestroyComponents(components);
	}

	private static void DestroyComponents(Component[] components)
	{
		int i = 0;
		for (int num = components.Length; i < num; i++)
		{
			Object.Destroy((Object)(object)components[i]);
		}
	}

	private void FixedUpdate()
	{
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		Rigidbody component = shadowRoot.GetComponent<Rigidbody>();
		component.MovePosition(((Component)this).transform.position);
		component.MoveRotation(((Component)this).transform.rotation);
		int i = 0;
		for (int count = shadowTable.Count; i < count; i++)
		{
			TransformPair transformPair = shadowTable[i];
			transformPair.dest.localPosition = transformPair.src.localPosition;
			transformPair.dest.localRotation = transformPair.src.localRotation;
		}
	}
}
