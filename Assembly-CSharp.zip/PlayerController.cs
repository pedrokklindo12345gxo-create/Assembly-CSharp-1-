using System;
using System.Collections;
using System.Collections.Generic;
using Spine.Unity;
using TouchControlsKit;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
	[Serializable]
	public class TextureBlock
	{
		public Texture2D bodyTexture;

		public Sprite face;

		public Sprite faceMO;

		public TextureBlock(Texture2D body, Sprite f, Sprite fMO)
		{
			bodyTexture = body;
			face = f;
			faceMO = fMO;
		}
	}

	public static PlayerController instance;

	public float moveSpeed;

	public bool lockActions;

	private SkeletonAnimation mSkeleton;

	[HideInInspector]
	public bool inDialogue;

	[HideInInspector]
	public bool optionsMode;

	private UIController mUI;

	private List<Item> mInventory = new List<Item>();

	private Interactable mInteractable;

	private GameObject mInteractableArrow;

	private float previousInput;

	private BoxCollider2D mCollider;

	private Rigidbody2D mRigidBody;

	public float money = 1.5f;

	public static bool roomTransition;

	[HideInInspector]
	public bool inAnim;

	private PauseMenu mPauseMenu;

	private bool mOverrideAnim;

	private bool mDisableGravity;

	public Sprite face;

	public Sprite faceMO;

	public TextureBlock defaultTextureBlock;

	public TextureBlock beaten;

	public TextureBlock bloody;

	public TextureBlock bruised;

	public TextureBlock bruisedBloody;

	public Texture bruisedTexture;

	public Texture holeInHeadTexture;

	public Texture bloodyTexture;

	public Texture bloodTexture;

	public Texture pukingTexture;

	public Texture stabbed;

	private TextureBlock mCurrentTextureBlock;

	private TextureBlock mStoreTextureBlock;

	private float mStoreMoney;

	private List<Item> mStoreInventory = new List<Item>();

	private int mShowAndTellSelection;

	private bool mInShowAndTell;

	private bool mIsMoving
	{
		get
		{
			if ((TCKInput.GetAxis("DPad0", AxisType.X) != 0f || TCKInput.GetAxis("DPad0", AxisType.Y) != 0f) && !inDialogue)
			{
				return !roomTransition;
			}
			return false;
		}
	}

	private void Awake()
	{
		instance = this;
	}

	private void Start()
	{
		mCollider = ((Component)this).GetComponent<BoxCollider2D>();
		mSkeleton = ((Component)this).GetComponent<SkeletonAnimation>();
		mRigidBody = ((Component)this).GetComponent<Rigidbody2D>();
		mSkeleton.skeleton.FlipX = true;
		mUI = Object.FindObjectOfType<UIController>();
		mPauseMenu = Object.FindObjectOfType<PauseMenu>();
		mInteractableArrow = GameObject.Find("InteractableArrow");
		mCurrentTextureBlock = defaultTextureBlock;
		SetDepth();
	}

	public void SetShowAndTell(Transform t)
	{
		int siblingIndex = t.GetSiblingIndex();
		if (siblingIndex != mShowAndTellSelection && mInShowAndTell)
		{
			mUI.HighlightItem(siblingIndex, mShowAndTellSelection);
			mShowAndTellSelection = siblingIndex;
		}
	}

	public IEnumerator SelectShowAndTellItem()
	{
		inAnim = true;
		mInShowAndTell = true;
		previousInput = 0f;
		mShowAndTellSelection = 0;
		int inventorCount = mInventory.Count;
		mUI.HighlightItem(0, 0);
		mUI.ShowShowAndTellPanel(x: true);
		while (inAnim)
		{
			if (!mPauseMenu.IsOpen)
			{
				previousInput = TCKInput.GetAxis("DPad0", AxisType.X);
				if (previousInput > 0f)
				{
					if (mShowAndTellSelection < inventorCount - 1)
					{
						mShowAndTellSelection++;
						mUI.HighlightItem(mShowAndTellSelection, mShowAndTellSelection - 1);
						yield return (object)new WaitForSeconds(0.25f);
					}
				}
				else if (previousInput < 0f && mShowAndTellSelection > 0)
				{
					mShowAndTellSelection--;
					mUI.HighlightItem(mShowAndTellSelection, mShowAndTellSelection + 1);
					yield return (object)new WaitForSeconds(0.25f);
				}
				if (InputManager.Instance.IsInteractPressed())
				{
					inAnim = false;
					SFXManager.Instance.PlaySound("Confirm");
				}
			}
			yield return null;
		}
		mInShowAndTell = false;
		mUI.ShowShowAndTellPanel(x: false);
		((MonoBehaviour)this).StartCoroutine(Object.FindObjectOfType<Teacher>().PlayShowAndTell(mInventory[mShowAndTellSelection]));
	}

	public void SetDepth()
	{
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0072: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0087: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		Bounds bounds;
		if (Object.op_Implicit((Object)(object)mCollider))
		{
			Transform transform = ((Component)this).transform;
			float x = ((Component)this).transform.position.x;
			float y = ((Component)this).transform.position.y;
			bounds = ((Collider2D)mCollider).bounds;
			transform.position = new Vector3(x, y, ((Bounds)(ref bounds)).min.y);
		}
		else
		{
			Transform transform2 = ((Component)this).transform;
			float x2 = ((Component)this).transform.position.x;
			float y2 = ((Component)this).transform.position.y;
			bounds = ((Collider2D)((Component)this).GetComponent<BoxCollider2D>()).bounds;
			transform2.position = new Vector3(x2, y2, ((Bounds)(ref bounds)).min.y);
		}
	}

	private void Update()
	{
		UpdateAnimator();
		if (roomTransition)
		{
			mInteractableArrow.SetActive(false);
		}
		else if (!inDialogue && !inAnim && !roomTransition)
		{
			HandleWalkState();
		}
		else
		{
			HandleOptionsState();
		}
	}

	private void FixedUpdate()
	{
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		if (mIsMoving && !roomTransition && !mUI.showPlanner && !inAnim && !mPauseMenu.IsOpen && !mUI.IsTutorialOpen())
		{
			HandleMovement();
		}
		else if (!mDisableGravity)
		{
			mRigidBody.velocity = Vector2.op_Implicit(Vector3.zero);
		}
	}

	public void HandleWalkState()
	{
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		if (InputManager.Instance.IsInteractPressed() && Object.op_Implicit((Object)(object)mInteractable) && !mUI.transitioning && !mUI.showPlanner && !mPauseMenu.IsOpen && !mUI.IsTutorialOpen())
		{
			mSkeleton.AnimationName = "idle";
			mSkeleton.skeleton.flipX = ((Component)this).transform.position.x < ((Component)mInteractable).transform.position.x;
			mInteractable.Interact();
		}
		if (InputManager.Instance.IsActionPressed() && !mUI.transitioning && !mUI.showPlanner && !mPauseMenu.IsOpen && !inDialogue && !inAnim && !mUI.IsDialogueOut() && !mUI.IsTutorialOpen())
		{
			if (!lockActions)
			{
				GetMoney(0.25f);
				EnvironmentController.Instance.DecreaseActions();
			}
			else
			{
				SFXManager.Instance.PlaySound("Failed");
			}
		}
	}

	private void OnCollisionEnter2D(Collision2D collision)
	{
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_0098: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		if (Object.op_Implicit((Object)(object)collision.gameObject.GetComponent<Interactable>()) && !inDialogue && !inAnim && !inDialogue)
		{
			mInteractable = collision.gameObject.GetComponent<Interactable>();
			mInteractableArrow.SetActive(true);
			Bounds bounds;
			if (Object.op_Implicit((Object)(object)((Component)mInteractable).GetComponent<Renderer>()))
			{
				Transform transform = mInteractableArrow.transform;
				float x = ((Component)mInteractable).transform.position.x;
				bounds = ((Component)mInteractable).GetComponent<Renderer>().bounds;
				transform.position = new Vector3(x, ((Bounds)(ref bounds)).max.y, -25f);
			}
			else
			{
				Transform transform2 = mInteractableArrow.transform;
				float x2 = ((Component)mInteractable).transform.position.x;
				bounds = ((Component)mInteractable).GetComponent<Collider2D>().bounds;
				transform2.position = new Vector3(x2, ((Bounds)(ref bounds)).max.y, -25f);
			}
			if (((Object)collision.transform).name == "HallMonitor" && EnvironmentController.currentRoom == Room.Hallway)
			{
				((MonoBehaviour)this).StartCoroutine(MoveExclamationPointToMonitor());
			}
		}
	}

	private IEnumerator MoveExclamationPointToMonitor()
	{
		while (Object.op_Implicit((Object)(object)mInteractable))
		{
			if (((Object)((Component)mInteractable).transform).name == "HallMonitor")
			{
				bool activeSelf = mInteractableArrow.activeSelf;
				if (TCKInput.GetAxis("DPad0", AxisType.Y) != 0f)
				{
					if (activeSelf)
					{
						mInteractableArrow.SetActive(false);
					}
				}
				else if (!activeSelf)
				{
					mInteractableArrow.SetActive(true);
					Transform transform = mInteractableArrow.transform;
					float x = ((Component)mInteractable).transform.position.x;
					Bounds bounds = ((Component)mInteractable).GetComponent<Renderer>().bounds;
					transform.position = new Vector3(x, ((Bounds)(ref bounds)).max.y, -25f);
				}
			}
			yield return null;
		}
	}

	private void OnCollisionExit2D(Collision2D c)
	{
		if ((Object)(object)mInteractable == (Object)(object)c.gameObject.GetComponent<Interactable>())
		{
			SetInteractable(null);
		}
	}

	private void OnTriggerEnter2D(Collider2D c)
	{
		//IL_00d6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f3: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_0089: Unknown result type (might be due to invalid IL or missing references)
		//IL_009e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		if (!Object.op_Implicit((Object)(object)((Component)c).gameObject.GetComponent<Interactable>()) || inDialogue || inAnim || inDialogue)
		{
			return;
		}
		mInteractable = ((Component)c).gameObject.GetComponent<Interactable>();
		if (mInteractable.ActivateOnTouch())
		{
			mInteractable.Interact();
			return;
		}
		mInteractableArrow.SetActive(true);
		Bounds bounds;
		if (Object.op_Implicit((Object)(object)((Component)mInteractable).GetComponent<MeshRenderer>()))
		{
			Transform transform = mInteractableArrow.transform;
			float x = ((Component)mInteractable).transform.position.x;
			bounds = ((Renderer)((Component)mInteractable).GetComponent<MeshRenderer>()).bounds;
			transform.position = new Vector3(x, ((Bounds)(ref bounds)).max.y, -9f);
		}
		else
		{
			Transform transform2 = mInteractableArrow.transform;
			float x2 = ((Component)mInteractable).transform.position.x;
			bounds = ((Component)mInteractable).GetComponent<Collider2D>().bounds;
			transform2.position = new Vector3(x2, ((Bounds)(ref bounds)).max.y, -9f);
		}
	}

	private void OnTriggerExit2D(Collider2D c)
	{
		if ((Object)(object)mInteractable == (Object)(object)((Component)c).gameObject.GetComponent<Interactable>() && !InputManager.Instance.IsInteractPressed())
		{
			SetInteractable(null);
		}
	}

	private void HandleOptionsState()
	{
		if (!optionsMode || mUI.showPlanner || mPauseMenu.IsOpen || mUI.IsTutorialOpen())
		{
			return;
		}
		if (previousInput != TCKInput.GetAxis("DPad0", AxisType.Y))
		{
			if ((previousInput > 0f && TCKInput.GetAxis("DPad0", AxisType.Y) > 0f) || (previousInput < 0f && TCKInput.GetAxis("DPad0", AxisType.Y) < 0f))
			{
				return;
			}
			previousInput = TCKInput.GetAxis("DPad0", AxisType.Y);
			if (previousInput != 0f)
			{
				if (previousInput > 0f)
				{
					mUI.SetOption(mUI.currentOption - 1);
				}
				else
				{
					mUI.SetOption(mUI.currentOption + 1);
				}
			}
		}
		if (InputManager.Instance.IsInteractPressed() && !mUI.transitioning && !inAnim && (Object)(object)mInteractable != (Object)null)
		{
			optionsMode = false;
			mInteractable.ExecuteBaseEvent(mUI.currentOption);
		}
	}

	private void HandleMovement()
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0056: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		//IL_006b: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		float axis = TCKInput.GetAxis("DPad0", AxisType.X);
		float axis2 = TCKInput.GetAxis("DPad0", AxisType.Y);
		mRigidBody.velocity = Vector2.op_Implicit(new Vector3(axis, axis2) * moveSpeed);
		Transform transform = ((Component)this).transform;
		float x = ((Component)this).transform.position.x;
		float y = ((Component)this).transform.position.y;
		Bounds bounds = ((Collider2D)mCollider).bounds;
		transform.position = new Vector3(x, y, ((Bounds)(ref bounds)).min.y);
		if (axis != 0f && mIsMoving)
		{
			mSkeleton.skeleton.flipX = axis > 0f;
		}
	}

	private void UpdateAnimator()
	{
		if (!inAnim && !mOverrideAnim)
		{
			if (!mIsMoving || mUI.showPlanner || mPauseMenu.IsOpen || mUI.IsTutorialOpen())
			{
				mSkeleton.AnimationName = "idle";
			}
			else
			{
				mSkeleton.AnimationName = "run";
			}
		}
	}

	public void ForceAnim(bool walk)
	{
		if (!walk)
		{
			mSkeleton.AnimationName = "idle";
		}
		else
		{
			mSkeleton.AnimationName = "run";
		}
	}

	public void ForceChangeDirection(bool right)
	{
		mSkeleton.skeleton.flipX = right;
	}

	public bool HasItem(Item item)
	{
		if (!mInventory.Contains(item))
		{
			return item == Item.None;
		}
		return true;
	}

	public int ItemCount()
	{
		return mInventory.Count;
	}

	public List<Item> MonstermonList()
	{
		List<Item> list = new List<Item>();
		foreach (Item item in mInventory)
		{
			foreach (MonsterMon value in Enum.GetValues(typeof(MonsterMon)))
			{
				if (value.ToString() == item.ToString())
				{
					list.Add(item);
				}
			}
		}
		return list;
	}

	public void UseItem(Item item)
	{
		if (mInventory.Contains(item))
		{
			mUI.RemoveItem(mInventory.IndexOf(item));
			mInventory.Remove(item);
		}
		else
		{
			Debug.LogError((object)("Tried to use item " + item.ToString() + " but it was not in player inventory."));
		}
	}

	public void GetItem(Item item)
	{
		mUI.AddItem(mInventory.Count, item);
		mInventory.Add(item);
	}

	public void SetInteractable(Interactable i)
	{
		mInteractable = i;
		if ((Object)(object)i == (Object)null)
		{
			mInteractableArrow.SetActive(false);
		}
	}

	public Interactable GetInteractable()
	{
		return mInteractable;
	}

	public void PlayAnimation(string s)
	{
		mSkeleton.AnimationName = s;
	}

	public void CancelOverride()
	{
		mOverrideAnim = false;
	}

	public void EnableOverride()
	{
		mOverrideAnim = true;
	}

	public void GetMoney(float s)
	{
		money += s;
		mUI.UpdateMoneyText(playSound: true);
	}

	public void DisableGravity(bool x)
	{
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0099: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		((Component)this).transform.position = new Vector3(((Component)this).transform.position.x, ((Component)this).transform.position.y, -7.15f);
		((Component)this).gameObject.layer = 8;
		mDisableGravity = true;
		mRigidBody.gravityScale = 1f;
		mRigidBody.freezeRotation = false;
		if (x)
		{
			mRigidBody.AddTorque(60f);
		}
		else
		{
			mRigidBody.AddTorque(-60f);
		}
		((Collider2D)mCollider).offset = new Vector2(0f, 1.25f);
		mCollider.size = new Vector2(1.3f, 2.5f);
	}

	public void ResetGravity()
	{
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		((Component)this).gameObject.layer = 0;
		mDisableGravity = false;
		mRigidBody.gravityScale = 0f;
		mRigidBody.freezeRotation = true;
		((Component)this).transform.rotation = Quaternion.identity;
		((Collider2D)mCollider).offset = new Vector2(0f, 0.25f);
		mCollider.size = new Vector2(1.2693f, 0.487f);
	}

	public int GetItemCount(Item item)
	{
		int num = 0;
		foreach (Item item2 in mInventory)
		{
			if (item2 == item)
			{
				num++;
			}
		}
		return num;
	}

	public SkeletonAnimation GetSkeleton()
	{
		return mSkeleton;
	}

	public void ActivateHoleInHead()
	{
		ApplyTexture(holeInHeadTexture);
	}

	public void ActivateStabbed()
	{
		ApplyTexture(stabbed);
	}

	public void ActivateBloody()
	{
		ApplyTexture(bloodyTexture);
	}

	public void ActivateBlood()
	{
		((Component)this).GetComponent<Renderer>().material.mainTexture = (Texture)(object)beaten.bodyTexture;
		face = beaten.face;
		faceMO = beaten.faceMO;
	}

	public void ActivatePuking()
	{
		ApplyTexture(pukingTexture);
	}

	public void ApplyTexture(Texture t)
	{
		((Component)this).GetComponent<Renderer>().material.mainTexture = t;
	}

	public void ApplyTextureBlock(TextureBlock t)
	{
		if (t != null)
		{
			mCurrentTextureBlock = t;
			((Component)this).GetComponent<Renderer>().material.mainTexture = (Texture)(object)t.bodyTexture;
			face = t.face;
			faceMO = t.faceMO;
		}
	}

	public void ActivateBloodStream()
	{
		GameObject.Find("PlayerBloodStream").GetComponent<ParticleSystem>().Play();
	}

	public void ActivateBloodStream(Vector3 pos)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		GameObject.Find("PlayerBloodStream").transform.localPosition = pos;
		GameObject.Find("PlayerBloodStream").GetComponent<ParticleSystem>().Play();
	}

	public void ActivateBloodSplat()
	{
		GameObject.Find("PlayerBloodSplat").GetComponent<ParticleSystem>().Play();
	}

	public void ActivateBloodSplat(Vector3 pos)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		GameObject.Find("PlayerBloodSplat").transform.localPosition = pos;
		GameObject.Find("PlayerBloodSplat").GetComponent<ParticleSystem>().Play();
	}

	public void ExplodePlayer(string s, string spa, bool beep)
	{
		((MonoBehaviour)this).StartCoroutine(ExplodeChar(s, spa, beep));
	}

	public void ExplodePlayer(string s, string spa)
	{
		((MonoBehaviour)this).StartCoroutine(ExplodeChar(s, spa, beep: true));
	}

	private IEnumerator ExplodeChar(string s, string spa, bool beep)
	{
		inAnim = true;
		ForceAnim(walk: false);
		mUI.showDeath = true;
		if (beep)
		{
			SFXManager.Instance.PlaySound("Beep");
			yield return (object)new WaitForSeconds(0.5f);
			SFXManager.Instance.PlaySound("Beep");
			yield return (object)new WaitForSeconds(0.5f);
			SFXManager.Instance.PlaySound("Beep");
			yield return (object)new WaitForSeconds(0.5f);
		}
		SFXManager.Instance.PlaySound("Bang");
		if (HasItem(Item.Bug))
		{
			UseItem(Item.Bug);
		}
		Object.FindObjectOfType<CameraFollow>().CameraShake(0.5f);
		Transform transform = Object.Instantiate<GameObject>(GameObject.Find("CharacterExplosion")).transform;
		((Component)transform).transform.parent = GameObject.Find(EnvironmentController.currentRoom.ToString()).transform;
		((Component)transform).transform.position = ((Component)this).transform.position;
		((Component)this).GetComponent<Renderer>().enabled = false;
		((Renderer)GameObject.Find("Player/Shadow").GetComponent<SpriteRenderer>()).enabled = false;
		((Component)transform).GetComponent<ParticleSystem>().Play();
		int num = 0;
		foreach (Transform item in transform)
		{
			Transform val = item;
			Rigidbody2D component = ((Component)val).GetComponent<Rigidbody2D>();
			component.isKinematic = false;
			component.gravityScale = 2f;
			switch (num)
			{
			case 0:
				((Component)val).GetComponent<SpriteRenderer>().flipX = mSkeleton.skeleton.flipX;
				component.AddForceAtPosition(new Vector2((float)Random.Range(-400, 400), 1000f), Vector2.op_Implicit(transform.position + Vector3.up * 1.5f));
				component.AddTorque((float)Random.Range(-100, 100));
				break;
			case 1:
				component.AddForceAtPosition(new Vector2((float)Random.Range(-100, 100), 200f), Vector2.op_Implicit(transform.position + Vector3.up * 1.5f));
				break;
			default:
				component.AddForceAtPosition(new Vector2((float)Random.Range(-100, 100), 400f), Vector2.op_Implicit(transform.position + Vector3.up * 1.5f));
				break;
			}
			num++;
		}
		yield return (object)new WaitForSeconds(3f);
		mUI.ShowDeath(s, spa);
	}

	public void StorePlayerValues()
	{
		mStoreTextureBlock = mCurrentTextureBlock;
		mStoreMoney = money;
		mStoreInventory.Clear();
		foreach (Item item in mInventory)
		{
			mStoreInventory.Add(item);
		}
	}

	public void ResetPlayerValues()
	{
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		money = mStoreMoney;
		mUI.UpdateMoneyText(playSound: false);
		mInventory.Clear();
		foreach (Item item in mStoreInventory)
		{
			mInventory.Add(item);
		}
		((Renderer)((Component)((Component)this).transform.GetChild(3)).GetComponent<SpriteRenderer>()).enabled = false;
		((Component)this).GetComponent<Renderer>().enabled = true;
		((Component)this).GetComponent<Renderer>().material.color = Color.white;
		((Renderer)GameObject.Find("Player/Shadow").GetComponent<SpriteRenderer>()).enabled = true;
		mUI.ShowShowAndTellPanel(x: false);
		((MonoBehaviour)this).StopAllCoroutines();
		mUI.ValidateInventory(mInventory);
		inAnim = false;
		inDialogue = false;
		optionsMode = false;
		mOverrideAnim = false;
		mSkeleton.AnimationName = "idle";
		ResetGravity();
		SetInteractable(null);
		mSkeleton.timeScale = 1.5f;
		ApplyTextureBlock(mStoreTextureBlock);
	}
}
