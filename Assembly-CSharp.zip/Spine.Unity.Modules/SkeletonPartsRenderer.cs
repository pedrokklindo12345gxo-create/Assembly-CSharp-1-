using System;
using Spine.Unity.MeshGeneration;
using UnityEngine;

namespace Spine.Unity.Modules;

[RequireComponent(typeof(MeshRenderer), typeof(MeshFilter))]
public class SkeletonPartsRenderer : MonoBehaviour
{
	private ISubmeshSetMeshGenerator meshGenerator;

	private MeshRenderer meshRenderer;

	private MeshFilter meshFilter;

	public ISubmeshSetMeshGenerator MeshGenerator
	{
		get
		{
			LazyIntialize();
			return meshGenerator;
		}
	}

	public MeshRenderer MeshRenderer
	{
		get
		{
			LazyIntialize();
			return meshRenderer;
		}
	}

	public MeshFilter MeshFilter
	{
		get
		{
			LazyIntialize();
			return meshFilter;
		}
	}

	private void LazyIntialize()
	{
		if (meshGenerator == null)
		{
			meshGenerator = new ArraysSubmeshSetMeshGenerator();
			meshFilter = ((Component)this).GetComponent<MeshFilter>();
			meshRenderer = ((Component)this).GetComponent<MeshRenderer>();
		}
	}

	public void ClearMesh()
	{
		LazyIntialize();
		meshFilter.sharedMesh = null;
	}

	public void RenderParts(ExposedList<SubmeshInstruction> instructions, int startSubmesh, int endSubmesh)
	{
		LazyIntialize();
		MeshAndMaterials meshAndMaterials = meshGenerator.GenerateMesh(instructions, startSubmesh, endSubmesh);
		meshFilter.sharedMesh = meshAndMaterials.mesh;
		((Renderer)meshRenderer).sharedMaterials = meshAndMaterials.materials;
	}

	public void SetPropertyBlock(MaterialPropertyBlock block)
	{
		LazyIntialize();
		((Renderer)meshRenderer).SetPropertyBlock(block);
	}

	public static SkeletonPartsRenderer NewPartsRendererGameObject(Transform parent, string name)
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		GameObject val = new GameObject(name, new Type[2]
		{
			typeof(MeshFilter),
			typeof(MeshRenderer)
		});
		val.transform.SetParent(parent, false);
		return val.AddComponent<SkeletonPartsRenderer>();
	}
}
