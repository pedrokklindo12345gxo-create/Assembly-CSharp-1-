using UnityEngine;

namespace Examples;

public class TwoDCameraFollow : MonoBehaviour
{
	public float xMargin = 1f;

	public float yMargin = 1f;

	public float xSmooth = 8f;

	public float ySmooth = 8f;

	public Vector2 maxXAndY;

	public Vector2 minXAndY;

	private Transform player;

	private void Awake()
	{
		player = GameObject.FindGameObjectWithTag("Player").transform;
	}

	private bool CheckXMargin()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		return Mathf.Abs(((Component)this).transform.position.x - player.position.x) > xMargin;
	}

	private bool CheckYMargin()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		return Mathf.Abs(((Component)this).transform.position.y - player.position.y) > yMargin;
	}

	private void FixedUpdate()
	{
		TrackPlayer();
	}

	private void TrackPlayer()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		float num = ((Component)this).transform.position.x;
		float num2 = ((Component)this).transform.position.y;
		if (CheckXMargin())
		{
			num = Mathf.Lerp(((Component)this).transform.position.x, player.position.x, xSmooth * Time.deltaTime);
		}
		if (CheckYMargin())
		{
			num2 = Mathf.Lerp(((Component)this).transform.position.y, player.position.y, ySmooth * Time.deltaTime);
		}
		num = Mathf.Clamp(num, minXAndY.x, maxXAndY.x);
		num2 = Mathf.Clamp(num2, minXAndY.y, maxXAndY.y);
		((Component)this).transform.position = new Vector3(num, num2, ((Component)this).transform.position.z);
	}
}
