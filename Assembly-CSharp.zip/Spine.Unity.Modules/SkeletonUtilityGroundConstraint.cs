using UnityEngine;

namespace Spine.Unity.Modules;

[RequireComponent(typeof(SkeletonUtilityBone))]
[ExecuteInEditMode]
public class SkeletonUtilityGroundConstraint : SkeletonUtilityConstraint
{
	[Tooltip("LayerMask for what objects to raycast against")]
	public LayerMask groundMask;

	[Tooltip("The 2D")]
	public bool use2D;

	[Tooltip("Uses SphereCast for 3D mode and CircleCast for 2D mode")]
	public bool useRadius;

	[Tooltip("The Radius")]
	public float castRadius = 0.1f;

	[Tooltip("How high above the target bone to begin casting from")]
	public float castDistance = 5f;

	[Tooltip("X-Axis adjustment")]
	public float castOffset;

	[Tooltip("Y-Axis adjustment")]
	public float groundOffset;

	[Tooltip("How fast the target IK position adjusts to the ground.  Use smaller values to prevent snapping")]
	public float adjustSpeed = 5f;

	private Vector3 rayOrigin;

	private Vector3 rayDir = new Vector3(0f, -1f, 0f);

	private float hitY;

	private float lastHitY;

	protected override void OnEnable()
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		base.OnEnable();
		lastHitY = ((Component)this).transform.position.y;
	}

	protected override void OnDisable()
	{
		base.OnDisable();
	}

	public override void DoUpdate()
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		//IL_018b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0191: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_0158: Unknown result type (might be due to invalid IL or missing references)
		//IL_0164: Unknown result type (might be due to invalid IL or missing references)
		//IL_0179: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_005c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_007e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ba: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0236: Unknown result type (might be due to invalid IL or missing references)
		//IL_023b: Unknown result type (might be due to invalid IL or missing references)
		//IL_023e: Unknown result type (might be due to invalid IL or missing references)
		//IL_026a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0281: Unknown result type (might be due to invalid IL or missing references)
		//IL_02a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0210: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		rayOrigin = ((Component)this).transform.position + new Vector3(castOffset, castDistance, 0f);
		hitY = float.MinValue;
		RaycastHit val2 = default(RaycastHit);
		if (use2D)
		{
			RaycastHit2D val = ((!useRadius) ? Physics2D.Raycast(Vector2.op_Implicit(rayOrigin), Vector2.op_Implicit(rayDir), castDistance + groundOffset, LayerMask.op_Implicit(groundMask)) : Physics2D.CircleCast(Vector2.op_Implicit(rayOrigin), castRadius, Vector2.op_Implicit(rayDir), castDistance + groundOffset, LayerMask.op_Implicit(groundMask)));
			if ((Object)(object)((RaycastHit2D)(ref val)).collider != (Object)null)
			{
				hitY = ((RaycastHit2D)(ref val)).point.y + groundOffset;
				if (Application.isPlaying)
				{
					hitY = Mathf.MoveTowards(lastHitY, hitY, adjustSpeed * Time.deltaTime);
				}
			}
			else if (Application.isPlaying)
			{
				hitY = Mathf.MoveTowards(lastHitY, ((Component)this).transform.position.y, adjustSpeed * Time.deltaTime);
			}
		}
		else if ((!useRadius) ? Physics.Raycast(rayOrigin, rayDir, ref val2, castDistance + groundOffset, LayerMask.op_Implicit(groundMask)) : Physics.SphereCast(rayOrigin, castRadius, rayDir, ref val2, castDistance + groundOffset, LayerMask.op_Implicit(groundMask)))
		{
			hitY = ((RaycastHit)(ref val2)).point.y + groundOffset;
			if (Application.isPlaying)
			{
				hitY = Mathf.MoveTowards(lastHitY, hitY, adjustSpeed * Time.deltaTime);
			}
		}
		else if (Application.isPlaying)
		{
			hitY = Mathf.MoveTowards(lastHitY, ((Component)this).transform.position.y, adjustSpeed * Time.deltaTime);
		}
		Vector3 position = ((Component)this).transform.position;
		position.y = Mathf.Clamp(position.y, Mathf.Min(lastHitY, hitY), float.MaxValue);
		((Component)this).transform.position = position;
		utilBone.bone.X = ((Component)this).transform.localPosition.x;
		utilBone.bone.Y = ((Component)this).transform.localPosition.y;
		lastHitY = hitY;
	}

	private void OnDrawGizmos()
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_002e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0033: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		//IL_0103: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0088: Unknown result type (might be due to invalid IL or missing references)
		//IL_008d: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ee: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = rayOrigin + rayDir * Mathf.Min(castDistance, rayOrigin.y - hitY);
		Vector3 val2 = rayOrigin + rayDir * castDistance;
		Gizmos.DrawLine(rayOrigin, val);
		if (useRadius)
		{
			Gizmos.DrawLine(new Vector3(val.x - castRadius, val.y - groundOffset, val.z), new Vector3(val.x + castRadius, val.y - groundOffset, val.z));
			Gizmos.DrawLine(new Vector3(val2.x - castRadius, val2.y, val2.z), new Vector3(val2.x + castRadius, val2.y, val2.z));
		}
		Gizmos.color = Color.red;
		Gizmos.DrawLine(val, val2);
	}
}
