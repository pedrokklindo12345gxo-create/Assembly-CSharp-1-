using TouchControlsKit;
using UnityEngine;

public class CarMove : MonoBehaviour
{
	private CharacterController controller;

	private Transform m_Transform;

	private void Awake()
	{
		controller = ((Component)this).GetComponent<CharacterController>();
		m_Transform = ((Component)this).transform;
	}

	private void Update()
	{
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0058: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0073: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		float num = TCKInput.GetAxis("steeringWheel", AxisType.X) + Input.GetAxis("Horizontal");
		float num2 = TCKInput.GetAxis("moveJoystick", AxisType.Y) + Input.GetAxis("Vertical");
		if (num2 != 0f)
		{
			m_Transform.Rotate(0f, num, 0f);
		}
		Vector3 val = m_Transform.forward * num2 * 5f;
		val *= Time.deltaTime;
		controller.Move(val);
	}
}
