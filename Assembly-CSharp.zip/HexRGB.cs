using System.Globalization;
using UnityEngine;
using UnityEngine.UI;

public class HexRGB : MonoBehaviour
{
	public InputField textColor;

	public HSVPicker hsvpicker;

	public void ManipulateViaRGB2Hex()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		string text = ColorToHex(Color32.op_Implicit(hsvpicker.currentColor));
		textColor.text = text;
	}

	public static string ColorToHex(Color color)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		//IL_0024: Unknown result type (might be due to invalid IL or missing references)
		int num = Mathf.RoundToInt(color.r * 255f);
		int num2 = Mathf.RoundToInt(color.g * 255f);
		int num3 = Mathf.RoundToInt(color.b * 255f);
		return $"#{num:X2}{num2:X2}{num3:X2}";
	}

	public void ManipulateViaHex2RGB()
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		string text = textColor.text;
		Color color = Hex2RGB(text);
		hsvpicker.AssignColor(color);
	}

	private static Color NormalizeVector4(Vector3 v, float r, float a)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		float num = v.x / r;
		float num2 = v.y / r;
		float num3 = v.z / r;
		return new Color(num, num2, num3, a);
	}

	private Color Hex2RGB(string hexColor)
	{
		//IL_010b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0110: Unknown result type (might be due to invalid IL or missing references)
		if (hexColor.IndexOf('#') != -1)
		{
			hexColor = hexColor.Replace("#", string.Empty);
		}
		int num = 0;
		int num2 = 0;
		int num3 = 0;
		if (hexColor.Length == 6)
		{
			num = int.Parse(hexColor.Substring(0, 2), NumberStyles.AllowHexSpecifier);
			num2 = int.Parse(hexColor.Substring(2, 2), NumberStyles.AllowHexSpecifier);
			num3 = int.Parse(hexColor.Substring(4, 2), NumberStyles.AllowHexSpecifier);
		}
		else if (hexColor.Length == 3)
		{
			num = int.Parse(hexColor[0].ToString() + hexColor[0], NumberStyles.AllowHexSpecifier);
			num2 = int.Parse(hexColor[1].ToString() + hexColor[1], NumberStyles.AllowHexSpecifier);
			num3 = int.Parse(hexColor[2].ToString() + hexColor[2], NumberStyles.AllowHexSpecifier);
		}
		return Color32.op_Implicit(new Color32((byte)num, (byte)num2, (byte)num3, byte.MaxValue));
	}
}
