using System.ComponentModel;

public enum MonsterMon
{
	[Description("Blue Eyes Gold Dragon")]
	BlueEyesGoldDragon,
	[Description("Cactus Outlaw")]
	CactusOutlaw,
	[Description("Cyclops Duckling")]
	CyclopsDuckling,
	[Description("Doom Jelly")]
	Doomjelly,
	[Description("Evil Thwarter")]
	EvilThwarter,
	[Description("Eye of the Buttholder")]
	EyeOfTheButtholder,
	[Description("Faptain Calcon")]
	FaptainCalcon,
	[Description("Freezyguy Jim")]
	FreezyguyJim,
	[Description("Giraffe Serpent")]
	GiraffeSerpent,
	[Description("Holy Knight")]
	HolyKnight,
	[Description("King Tower Beetle")]
	KingTowerbeetle,
	[Description("Literally Grass")]
	LiterallyGrass,
	[Description("Magical Airship")]
	MagicalAirship,
	[Description("Man With Long Arm")]
	ManWithLongArm,
	[Description("Martian Orb Man")]
	MartianOrbMan,
	[Description("Oglebop Golem")]
	OglebopGolem,
	[Description("Oh Faka Tornado")]
	OhfakaTornado,
	[Description("Shroom Turtle")]
	ShroomTurtle,
	[Description("Really Bright Star")]
	ReallyBrightStar,
	[Description("Sneaky Snake")]
	SneakySnake,
	[Description("Spikey Flimflam")]
	SpikeyFlimflam,
	[Description("Tornado Fly")]
	TornadoFly,
	[Description("Uneaten Cake")]
	UneatenCake,
	[Description("Wall of Castle")]
	WallOfCastle,
	[Description("Wizard Worm")]
	WizardWorm
}
