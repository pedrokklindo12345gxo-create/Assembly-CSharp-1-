using UnityEngine;

namespace Spine.Unity.MeshGeneration;

public class ArraysMeshGenerator
{
	public class SubmeshTriangleBuffer
	{
		public int[] triangles;

		public int triangleCount;

		public int firstVertex = -1;

		public SubmeshTriangleBuffer()
		{
		}

		public SubmeshTriangleBuffer(int triangleCount)
		{
			triangles = new int[triangleCount];
		}
	}

	protected bool addNormals;

	protected bool addTangents;

	protected float[] attachmentVertexBuffer = new float[8];

	protected Vector3[] meshVertices;

	protected Color32[] meshColors32;

	protected Vector2[] meshUVs;

	protected Vector3[] meshNormals;

	protected Vector4[] meshTangents;

	protected Vector2[] tempTanBuffer;

	public bool PremultiplyVertexColors { get; set; }

	public bool AddNormals
	{
		get
		{
			return addNormals;
		}
		set
		{
			addNormals = value;
		}
	}

	public bool AddTangents
	{
		get
		{
			return addTangents;
		}
		set
		{
			addTangents = value;
		}
	}

	public void TryAddNormalsTo(Mesh mesh, int targetVertexCount)
	{
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		if (!addNormals)
		{
			return;
		}
		if (meshNormals == null || meshNormals.Length < targetVertexCount)
		{
			meshNormals = (Vector3[])(object)new Vector3[targetVertexCount];
			Vector3 val = default(Vector3);
			((Vector3)(ref val))._002Ector(0f, 0f, -1f);
			Vector3[] array = meshNormals;
			for (int i = 0; i < targetVertexCount; i++)
			{
				array[i] = val;
			}
		}
		mesh.normals = meshNormals;
	}

	public static bool EnsureSize(int targetVertexCount, ref Vector3[] vertices, ref Vector2[] uvs, ref Color32[] colors)
	{
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_003e: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		Vector3[] array = vertices;
		bool flag = array == null || targetVertexCount > array.Length;
		if (flag)
		{
			vertices = (Vector3[])(object)new Vector3[targetVertexCount];
			colors = (Color32[])(object)new Color32[targetVertexCount];
			uvs = (Vector2[])(object)new Vector2[targetVertexCount];
		}
		else
		{
			Vector3 zero = Vector3.zero;
			int i = targetVertexCount;
			for (int num = array.Length; i < num; i++)
			{
				array[i] = zero;
			}
		}
		return flag;
	}

	public static bool EnsureTriangleBuffersSize(ExposedList<SubmeshTriangleBuffer> submeshBuffers, int targetSubmeshCount, SubmeshInstruction[] instructionItems)
	{
		bool flag = submeshBuffers.Count < targetSubmeshCount;
		if (flag)
		{
			submeshBuffers.GrowIfNeeded(targetSubmeshCount - submeshBuffers.Count);
			int num = submeshBuffers.Count;
			while (submeshBuffers.Count < targetSubmeshCount)
			{
				submeshBuffers.Add(new SubmeshTriangleBuffer(instructionItems[num].triangleCount));
				num++;
			}
		}
		return flag;
	}

	public static void FillVerts(Skeleton skeleton, int startSlot, int endSlot, float zSpacing, bool pmaColors, Vector3[] verts, Vector2[] uvs, Color32[] colors, ref int vertexIndex, ref float[] tempVertBuffer, ref Vector3 boundsMin, ref Vector3 boundsMax, bool renderMeshes = true)
	{
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0044: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004d: Unknown result type (might be due to invalid IL or missing references)
		//IL_079b: Unknown result type (might be due to invalid IL or missing references)
		//IL_079d: Unknown result type (might be due to invalid IL or missing references)
		//IL_07a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_07a6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c6: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_020b: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_02be: Unknown result type (might be due to invalid IL or missing references)
		//IL_02c0: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_02cd: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_02da: Unknown result type (might be due to invalid IL or missing references)
		//IL_0386: Unknown result type (might be due to invalid IL or missing references)
		//IL_039a: Unknown result type (might be due to invalid IL or missing references)
		//IL_054a: Unknown result type (might be due to invalid IL or missing references)
		//IL_056c: Unknown result type (might be due to invalid IL or missing references)
		//IL_058f: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_03c4: Unknown result type (might be due to invalid IL or missing references)
		//IL_064f: Unknown result type (might be due to invalid IL or missing references)
		//IL_03d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0663: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ee: Unknown result type (might be due to invalid IL or missing references)
		//IL_06e9: Unknown result type (might be due to invalid IL or missing references)
		//IL_06eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_071a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0677: Unknown result type (might be due to invalid IL or missing references)
		//IL_0402: Unknown result type (might be due to invalid IL or missing references)
		//IL_0730: Unknown result type (might be due to invalid IL or missing references)
		//IL_068b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0418: Unknown result type (might be due to invalid IL or missing references)
		//IL_0744: Unknown result type (might be due to invalid IL or missing references)
		//IL_042c: Unknown result type (might be due to invalid IL or missing references)
		//IL_075a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0440: Unknown result type (might be due to invalid IL or missing references)
		//IL_0454: Unknown result type (might be due to invalid IL or missing references)
		//IL_046a: Unknown result type (might be due to invalid IL or missing references)
		//IL_047e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0494: Unknown result type (might be due to invalid IL or missing references)
		//IL_04a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_04be: Unknown result type (might be due to invalid IL or missing references)
		Slot[] items = skeleton.DrawOrder.Items;
		float num = skeleton.a * 255f;
		float r = skeleton.r;
		float g = skeleton.g;
		float b = skeleton.b;
		int num2 = vertexIndex;
		float[] array = tempVertBuffer;
		Vector3 val = boundsMin;
		Vector3 val2 = boundsMax;
		Color32 val3 = default(Color32);
		for (int i = startSlot; i < endSlot; i++)
		{
			Slot slot = items[i];
			Attachment attachment = slot.attachment;
			float z = (float)i * zSpacing;
			if (attachment is RegionAttachment regionAttachment)
			{
				regionAttachment.ComputeWorldVertices(slot.bone, array);
				float num3 = array[0];
				float num4 = array[1];
				float num5 = array[2];
				float num6 = array[3];
				float num7 = array[4];
				float num8 = array[5];
				float num9 = array[6];
				float num10 = array[7];
				verts[num2].x = num3;
				verts[num2].y = num4;
				verts[num2].z = z;
				verts[num2 + 1].x = num9;
				verts[num2 + 1].y = num10;
				verts[num2 + 1].z = z;
				verts[num2 + 2].x = num5;
				verts[num2 + 2].y = num6;
				verts[num2 + 2].z = z;
				verts[num2 + 3].x = num7;
				verts[num2 + 3].y = num8;
				verts[num2 + 3].z = z;
				if (pmaColors)
				{
					val3.a = (byte)(num * slot.a * regionAttachment.a);
					val3.r = (byte)(r * slot.r * regionAttachment.r * (float)(int)val3.a);
					val3.g = (byte)(g * slot.g * regionAttachment.g * (float)(int)val3.a);
					val3.b = (byte)(b * slot.b * regionAttachment.b * (float)(int)val3.a);
					if (slot.data.blendMode == BlendMode.additive)
					{
						val3.a = 0;
					}
				}
				else
				{
					val3.a = (byte)(num * slot.a * regionAttachment.a);
					val3.r = (byte)(r * slot.r * regionAttachment.r * 255f);
					val3.g = (byte)(g * slot.g * regionAttachment.g * 255f);
					val3.b = (byte)(b * slot.b * regionAttachment.b * 255f);
				}
				colors[num2] = val3;
				colors[num2 + 1] = val3;
				colors[num2 + 2] = val3;
				colors[num2 + 3] = val3;
				float[] uvs2 = regionAttachment.uvs;
				uvs[num2].x = uvs2[0];
				uvs[num2].y = uvs2[1];
				uvs[num2 + 1].x = uvs2[6];
				uvs[num2 + 1].y = uvs2[7];
				uvs[num2 + 2].x = uvs2[2];
				uvs[num2 + 2].y = uvs2[3];
				uvs[num2 + 3].x = uvs2[4];
				uvs[num2 + 3].y = uvs2[5];
				if (num3 < val.x)
				{
					val.x = num3;
				}
				if (num3 > val2.x)
				{
					val2.x = num3;
				}
				if (num5 < val.x)
				{
					val.x = num5;
				}
				else if (num5 > val2.x)
				{
					val2.x = num5;
				}
				if (num7 < val.x)
				{
					val.x = num7;
				}
				else if (num7 > val2.x)
				{
					val2.x = num7;
				}
				if (num9 < val.x)
				{
					val.x = num9;
				}
				else if (num9 > val2.x)
				{
					val2.x = num9;
				}
				if (num4 < val.y)
				{
					val.y = num4;
				}
				if (num4 > val2.y)
				{
					val2.y = num4;
				}
				if (num6 < val.y)
				{
					val.y = num6;
				}
				else if (num6 > val2.y)
				{
					val2.y = num6;
				}
				if (num8 < val.y)
				{
					val.y = num8;
				}
				else if (num8 > val2.y)
				{
					val2.y = num8;
				}
				if (num10 < val.y)
				{
					val.y = num10;
				}
				else if (num10 > val2.y)
				{
					val2.y = num10;
				}
				num2 += 4;
			}
			else
			{
				if (!renderMeshes || !(attachment is MeshAttachment { worldVerticesLength: var worldVerticesLength } meshAttachment))
				{
					continue;
				}
				if (array.Length < worldVerticesLength)
				{
					array = new float[worldVerticesLength];
				}
				meshAttachment.ComputeWorldVertices(slot, array);
				if (pmaColors)
				{
					val3.a = (byte)(num * slot.a * meshAttachment.a);
					val3.r = (byte)(r * slot.r * meshAttachment.r * (float)(int)val3.a);
					val3.g = (byte)(g * slot.g * meshAttachment.g * (float)(int)val3.a);
					val3.b = (byte)(b * slot.b * meshAttachment.b * (float)(int)val3.a);
					if (slot.data.blendMode == BlendMode.additive)
					{
						val3.a = 0;
					}
				}
				else
				{
					val3.a = (byte)(num * slot.a * meshAttachment.a);
					val3.r = (byte)(r * slot.r * meshAttachment.r * 255f);
					val3.g = (byte)(g * slot.g * meshAttachment.g * 255f);
					val3.b = (byte)(b * slot.b * meshAttachment.b * 255f);
				}
				float[] uvs3 = meshAttachment.uvs;
				if (num2 == vertexIndex)
				{
					float num11 = array[0];
					float num12 = array[1];
					if (num11 < val.x)
					{
						val.x = num11;
					}
					if (num11 > val2.x)
					{
						val2.x = num11;
					}
					if (num12 < val.y)
					{
						val.y = num12;
					}
					if (num12 > val2.y)
					{
						val2.y = num12;
					}
				}
				for (int j = 0; j < worldVerticesLength; j += 2)
				{
					float num13 = array[j];
					float num14 = array[j + 1];
					verts[num2].x = num13;
					verts[num2].y = num14;
					verts[num2].z = z;
					colors[num2] = val3;
					uvs[num2].x = uvs3[j];
					uvs[num2].y = uvs3[j + 1];
					if (num13 < val.x)
					{
						val.x = num13;
					}
					else if (num13 > val2.x)
					{
						val2.x = num13;
					}
					if (num14 < val.y)
					{
						val.y = num14;
					}
					else if (num14 > val2.y)
					{
						val2.y = num14;
					}
					num2++;
				}
			}
		}
		vertexIndex = num2;
		tempVertBuffer = array;
		boundsMin = val;
		boundsMax = val2;
	}

	public static void FillTriangles(ref int[] triangleBuffer, Skeleton skeleton, int triangleCount, int firstVertex, int startSlot, int endSlot, bool isLastSubmesh)
	{
		int num = triangleBuffer.Length;
		int[] array = triangleBuffer;
		if (isLastSubmesh)
		{
			if (num > triangleCount)
			{
				for (int i = triangleCount; i < num; i++)
				{
					array[i] = 0;
				}
			}
			else if (num < triangleCount)
			{
				array = (triangleBuffer = new int[triangleCount]);
			}
		}
		else if (num != triangleCount)
		{
			array = (triangleBuffer = new int[triangleCount]);
		}
		Slot[] items = skeleton.drawOrder.Items;
		int j = startSlot;
		int num2 = 0;
		int num3 = firstVertex;
		for (; j < endSlot; j++)
		{
			Attachment attachment = items[j].attachment;
			if (attachment is RegionAttachment)
			{
				array[num2] = num3;
				array[num2 + 1] = num3 + 2;
				array[num2 + 2] = num3 + 1;
				array[num2 + 3] = num3 + 2;
				array[num2 + 4] = num3 + 3;
				array[num2 + 5] = num3 + 1;
				num2 += 6;
				num3 += 4;
			}
			else if (attachment is MeshAttachment { triangles: var triangles } meshAttachment)
			{
				int num4 = 0;
				int num5 = triangles.Length;
				while (num4 < num5)
				{
					array[num2] = num3 + triangles[num4];
					num4++;
					num2++;
				}
				num3 += meshAttachment.worldVerticesLength >> 1;
			}
		}
	}

	public static void FillTrianglesQuads(ref int[] triangleBuffer, ref int storedTriangleCount, ref int storedFirstVertex, int instructionsFirstVertex, int instructionTriangleCount, bool isLastSubmesh)
	{
		int num = triangleBuffer.Length;
		if (isLastSubmesh && num > instructionTriangleCount)
		{
			for (int i = instructionTriangleCount; i < num; i++)
			{
				triangleBuffer[i] = 0;
			}
			storedTriangleCount = instructionTriangleCount;
		}
		else if (num != instructionTriangleCount)
		{
			triangleBuffer = new int[instructionTriangleCount];
			storedTriangleCount = 0;
		}
		int[] array = triangleBuffer;
		if (storedFirstVertex != instructionsFirstVertex || storedTriangleCount < instructionTriangleCount)
		{
			storedTriangleCount = instructionTriangleCount;
			storedFirstVertex = instructionsFirstVertex;
			int num2 = instructionsFirstVertex;
			int num3 = 0;
			while (num3 < instructionTriangleCount)
			{
				array[num3] = num2;
				array[num3 + 1] = num2 + 2;
				array[num3 + 2] = num2 + 1;
				array[num3 + 3] = num2 + 2;
				array[num3 + 4] = num2 + 3;
				array[num3 + 5] = num2 + 1;
				num3 += 6;
				num2 += 4;
			}
		}
	}

	public static Bounds ToBounds(Vector3 boundsMin, Vector3 boundsMax)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0014: Unknown result type (might be due to invalid IL or missing references)
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		Vector3 val = boundsMax - boundsMin;
		return new Bounds(boundsMin + val * 0.5f, val);
	}

	public static void SolveTangents2DEnsureSize(ref Vector4[] tangentBuffer, ref Vector2[] tempTanBuffer, int vertexCount)
	{
		if (tangentBuffer == null || tangentBuffer.Length < vertexCount)
		{
			tangentBuffer = (Vector4[])(object)new Vector4[vertexCount];
		}
		if (tempTanBuffer == null || tempTanBuffer.Length < vertexCount * 2)
		{
			tempTanBuffer = (Vector2[])(object)new Vector2[vertexCount * 2];
		}
	}

	public static void SolveTangents2DTriangles(Vector2[] tempTanBuffer, int[] triangles, int triangleCount, Vector3[] vertices, Vector2[] uvs, int vertexCount)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_000a: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_0047: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		//IL_0057: Unknown result type (might be due to invalid IL or missing references)
		//IL_005d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_008a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0094: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00df: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_0146: Unknown result type (might be due to invalid IL or missing references)
		//IL_014b: Unknown result type (might be due to invalid IL or missing references)
		//IL_014d: Unknown result type (might be due to invalid IL or missing references)
		//IL_014e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0150: Unknown result type (might be due to invalid IL or missing references)
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_0197: Unknown result type (might be due to invalid IL or missing references)
		//IL_0198: Unknown result type (might be due to invalid IL or missing references)
		//IL_0199: Unknown result type (might be due to invalid IL or missing references)
		//IL_019b: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a2: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a5: Unknown result type (might be due to invalid IL or missing references)
		//IL_01aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ac: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = default(Vector2);
		Vector2 val2 = default(Vector2);
		for (int i = 0; i < triangleCount; i += 3)
		{
			int num = triangles[i];
			int num2 = triangles[i + 1];
			int num3 = triangles[i + 2];
			Vector3 val3 = vertices[num];
			Vector3 val4 = vertices[num2];
			Vector3 val5 = vertices[num3];
			Vector2 val6 = uvs[num];
			Vector2 val7 = uvs[num2];
			Vector2 val8 = uvs[num3];
			float num4 = val4.x - val3.x;
			float num5 = val5.x - val3.x;
			float num6 = val4.y - val3.y;
			float num7 = val5.y - val3.y;
			float num8 = val7.x - val6.x;
			float num9 = val8.x - val6.x;
			float num10 = val7.y - val6.y;
			float num11 = val8.y - val6.y;
			float num12 = num8 * num11 - num9 * num10;
			float num13 = ((num12 != 0f) ? (1f / num12) : 0f);
			val.x = (num11 * num4 - num10 * num5) * num13;
			val.y = (num11 * num6 - num10 * num7) * num13;
			tempTanBuffer[num] = (tempTanBuffer[num2] = (tempTanBuffer[num3] = val));
			val2.x = (num8 * num5 - num9 * num4) * num13;
			val2.y = (num8 * num7 - num9 * num6) * num13;
			tempTanBuffer[vertexCount + num] = (tempTanBuffer[vertexCount + num2] = (tempTanBuffer[vertexCount + num3] = val2));
		}
	}

	public static void SolveTangents2DBuffer(Vector4[] tangents, Vector2[] tempTanBuffer, int vertexCount)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0078: Unknown result type (might be due to invalid IL or missing references)
		//IL_007d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0081: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00af: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c6: Unknown result type (might be due to invalid IL or missing references)
		Vector4 val = new Vector4
		{
			z = 0f
		};
		for (int i = 0; i < vertexCount; i++)
		{
			Vector2 val2 = tempTanBuffer[i];
			float num = Mathf.Sqrt(val2.x * val2.x + val2.y * val2.y);
			if ((double)num > 1E-05)
			{
				float num2 = 1f / num;
				val2.x *= num2;
				val2.y *= num2;
			}
			Vector2 val3 = tempTanBuffer[vertexCount + i];
			val.x = val2.x;
			val.y = val2.y;
			val.w = ((val2.y * val3.x > val2.x * val3.y) ? 1 : (-1));
			tangents[i] = val;
		}
	}
}
