using DialogueTree;
using UnityEngine;

public class ObjectInteractable : Interactable
{
	public string startFunction;

	public Dialogue dialogue;

	public string NPC;

	public bool activateOnTouch;

	public bool manualSetDepth;

	public override void Start()
	{
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_010d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0112: Unknown result type (might be due to invalid IL or missing references)
		//IL_0115: Unknown result type (might be due to invalid IL or missing references)
		//IL_011f: Unknown result type (might be due to invalid IL or missing references)
		base.Start();
		TextAsset val = (TextAsset)(EnvironmentController.Instance.isSpanish ? /*isinst with value type is only supported in some contexts*/: /*isinst with value type is only supported in some contexts*/);
		if ((Object)(object)val != (Object)null)
		{
			dialogue = Dialogue.LoadDialogue(val);
		}
		else if (startFunction.Length == 0)
		{
			Debug.LogWarning((object)(((Object)((Component)this).transform).name + " does not have any functions or a valid xml file to read from."));
		}
		if (!manualSetDepth)
		{
			Transform transform = ((Component)this).transform;
			float x = ((Component)this).transform.position.x;
			float y = ((Component)this).transform.position.y;
			Bounds bounds = ((Component)this).GetComponent<Collider2D>().bounds;
			transform.position = new Vector3(x, y, ((Bounds)(ref bounds)).min.y);
		}
	}

	public override bool ActivateOnTouch()
	{
		return activateOnTouch;
	}

	public override void Interact()
	{
		if (startFunction.Length > 0)
		{
			((MonoBehaviour)GameObject.Find(NPC).GetComponent<Interactable>()).Invoke(startFunction, 0f);
			player.SetInteractable(null);
		}
		else
		{
			DoNormalInteract();
		}
	}

	public override void DoNormalInteract()
	{
		UI.StartDialogue(dialogue.GetCurrentNode().DialogueText);
		((MonoBehaviour)this).Invoke("UpdateOptions", 0.5f);
		player.inDialogue = true;
	}

	public override void ExecuteBaseEvent(int x)
	{
		lastSelectedOption = GetCurrentOptions()[x];
		if (lastSelectedOption.UsesAction)
		{
			if (EnvironmentController.Instance.ActionsLeft() <= 0)
			{
				UI.ShakeOption();
				return;
			}
			if (player.money >= lastSelectedOption.MoneyLock)
			{
				EnvironmentController.Instance.DecreaseActions();
			}
		}
		if (!string.IsNullOrEmpty(lastSelectedOption.FunctionCall))
		{
			GameObject val = GameObject.Find(NPC);
			if (!Object.op_Implicit((Object)(object)val))
			{
				((MonoBehaviour)this).Invoke(lastSelectedOption.FunctionCall, 0f);
			}
			else
			{
				((MonoBehaviour)val.GetComponent<Interactable>()).Invoke(lastSelectedOption.FunctionCall, 0f);
			}
		}
		((MonoBehaviour)this).Invoke("DoBaseFunction", 0f);
	}

	public virtual void DoBaseFunction()
	{
		if (lastSelectedOption.DestinationID > -1)
		{
			dialogue.currentConversation = lastSelectedOption.DestinationID;
			UI.StartDialogue(dialogue.GetCurrentNode().DialogueText);
		}
		else
		{
			if (lastSelectedOption.DestinationID != -1)
			{
				player.SetInteractable(null);
				((MonoBehaviour)this).StartCoroutine(UI.ShowOptions(show: false));
				return;
			}
			UI.CollapseDialogue();
			player.SetInteractable(null);
			if (lastSelectedOption.ResolutionID > 0)
			{
				dialogue.currentConversation = lastSelectedOption.ResolutionID;
			}
			else if (lastSelectedOption.ResolutionID == -1)
			{
				dialogue.currentConversation = 0;
			}
		}
		((MonoBehaviour)this).StartCoroutine(UI.ShowOptions(show: false));
		((MonoBehaviour)this).Invoke("UpdateOptions", 0.5f);
	}

	public override DialogueOption[] GetCurrentOptions()
	{
		return dialogue.GetCurrentNode().Options.ToArray();
	}

	public override int GetOptionCount()
	{
		try
		{
			return GetCurrentOptions().Length;
		}
		catch
		{
			return 0;
		}
	}

	private void StartGame()
	{
		EnvironmentController.Instance.ChangeEnvironment(Room.SchoolYard);
	}

	public override Dialogue GetDialogue()
	{
		return dialogue;
	}
}
