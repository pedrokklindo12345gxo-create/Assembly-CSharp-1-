using System.Collections;
using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Core.PathCore;
using DG.Tweening.Plugins.Options;
using Spine.Unity;
using UnityEngine;

public class Cindy : NPCBehavior
{
	public TextureBlock crying;

	public TextureBlock bloody;

	public TextureBlock screaming;

	public TextureBlock angry;

	public TextureBlock angryBlood;

	public SpriteRenderer breathalyzer;

	public GameObject janitorHead;

	private bool mShowedFlower;

	public void SetShowFlower(bool x)
	{
		mShowedFlower = x;
	}

	public bool GetShowedFlower()
	{
		return mShowedFlower;
	}

	private void BringFlower()
	{
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		GameObject obj = GameObject.Find("Flower");
		player.GetItem(Item.Flower);
		((Behaviour)obj.GetComponent<Collider2D>()).enabled = false;
		obj.GetComponent<SpriteRenderer>().color = Color.black;
	}

	private void GetGum()
	{
		player.GetItem(Item.Gum);
	}

	private void TakeGum()
	{
		player.UseItem(Item.Gum);
	}

	private void ActivateGumMission()
	{
		ActivateMission(Mission.CindyPutGumInHair, Room.Classroom1);
		ShutDownCindy(breakup: true);
		conversations[Room.Classroom1].currentConversation = 1;
	}

	private void CallRape()
	{
		player.SetInteractable(null);
		Object.FindObjectOfType<CameraFollow>().CameraShake();
		ApplyTextureBlock(screaming);
		((MonoBehaviour)this).StartCoroutine(CallRape2());
	}

	private IEnumerator CallRape2()
	{
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("\\bESTUUUUPRO!!/b", "\\b¡¡VIOLACIÓN!!/b", this));
		while (pEmptyOptions)
		{
			yield return null;
		}
		ApplyTextureBlock(defaultTextureBlock);
		Teacher t = Object.FindObjectOfType<Teacher>();
		t.SetDirection(setFlip: false);
		t.mySkeleton.AnimationName = "walk";
		player.inAnim = true;
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("Ai, meu Deus!~~ O que diabos está acontecendo aqui? Ouvi alguém gritar 'estupro!'", "¡Ay Dios mío!~~ ¿Pero qué está pasando aquí? ¡Escuché a alguien gritar 'violación!'", t));
		t.FacePlayer();
		TweenSettingsExtensions.OnUpdate<TweenerCore<Vector3, Vector3, VectorOptions>>(TweenSettingsExtensions.OnComplete<TweenerCore<Vector3, Vector3, VectorOptions>>(TweenSettingsExtensions.SetEase<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOMove(((Component)t).transform, new Vector3(3.25f, -8.45f, -8.45f), 2f, false), (Ease)1), (TweenCallback)delegate
		{
			t.FacePlayer();
			t.mySkeleton.AnimationName = "idle";
			SetDirection(setFlip: true);
			player.ForceChangeDirection(right: true);
			player.inAnim = false;
		}), (TweenCallback)delegate
		{
			t.SetDepth();
		});
		yield return null;
		while (pEmptyOptions)
		{
			yield return null;
		}
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("Sim, Srta. Applegate. Fui eu. Este garoto tentou me estuprar.", "Sí, Señora Applegate. Fui yo. Este chico intentó violarme.", this));
		while (pEmptyOptions)
		{
			yield return null;
		}
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("*Suspiro*~ Cindy...~nós já conversamos sobre isso. Garotos não quererem ser seu namorado não conta como estupro, mas de acordo com as regras da escola, eu tenho que mandar vocês dois para a diretoria.", "*Suspiro*~ Cindy...~ya hemos hablado de esto. Que los chicos no quieran ser tus novios, no significa que quieran violarte, pero de acuerdo con la política de la escuela, tengo que enviarlos a los dos con el director.", t));
		while (pEmptyOptions)
		{
			yield return null;
		}
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("O quê?! Você tá me punindo por quase ser estuprada?!", "¿Qué? ¡¿Me estás castigando a mi por casi ser violada?", this));
		while (pEmptyOptions)
		{
			yield return null;
		}
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("Agora me escute aqui, seu pequeno parasita.~ Você vai para a sala do diretor. Fim de papo.", "Ahora escúchame pequeño parásito. ~ Ve a la oficina del director. Fin de la historia.", t));
		while (pEmptyOptions)
		{
			yield return null;
		}
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("Isso é muito injusto!", "¡Esto es tan injusto!", this));
		while (pEmptyOptions)
		{
			yield return null;
		}
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("É, ta bom.~ Conta outra pro diretor.", "Sí, sí. ~Cuéntale al director.", t));
		while (pEmptyOptions)
		{
			yield return null;
		}
		UI.CollapseDialogue();
		Object.FindObjectOfType<Principal>().SetCindy();
		EnvironmentController.Instance.ChangeEnvironment(Room.Office);
	}

	private void GoToDollHouse()
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		CompleteMission(Mission.CindyTalkMorningTime);
		ActivateMission(Mission.CindyPlayHouse, Room.Classroom1);
		WalkToPoint(new Vector3(-19.65f, -12.1f, -12.09f), 1.75f);
		SetDirection(setFlip: false);
	}

	private void ActivateWashUp()
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		CompleteMission(Mission.CindyTalkMorningTime);
		ActivateMission(Mission.CindyWashUp, Room.Classroom1);
		WalkToPoint(new Vector3(-19.65f, -12.1f, -12.09f), 1.75f);
		SetDirection(setFlip: false);
	}

	private void TurnOnTears()
	{
		ApplyTextureBlock(crying);
	}

	private void TurnOnBreathalyzer()
	{
		((Renderer)breathalyzer).enabled = true;
	}

	private void HideBreathalyzer()
	{
		((Renderer)breathalyzer).enabled = false;
	}

	private void GetBreathalyzer()
	{
		player.GetItem(Item.Breathalyzer);
		((Renderer)breathalyzer).enabled = false;
	}

	private void GetFlask()
	{
		player.GetItem(Item.Flask);
	}

	private void CantLeave()
	{
		UnlockHint("Cindy", 3);
		UnlockHint("Cindy", 2);
		StabPlayer("Você está bêbado. Não pode sair. Beber e dirigir é perigoso.", "Estás borracho. No puedes salir. Si bebiste, no conduzcas.");
	}

	private void ShowKnife()
	{
		((Renderer)((Component)((Component)this).transform.GetChild(3)).GetComponent<SpriteRenderer>()).enabled = true;
	}

	private void HideKnife()
	{
		((Renderer)((Component)((Component)this).transform.GetChild(3)).GetComponent<SpriteRenderer>()).enabled = false;
	}

	private void StabPlayer(string x, string span)
	{
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		Transform child = ((Component)player).transform.GetChild(3);
		HideKnife();
		((Renderer)((Component)child).GetComponent<SpriteRenderer>()).enabled = true;
		player.ActivateBloodStream(new Vector3(0f, 1.75f, -3.6f));
		if (player.GetSkeleton().skeleton.flipX)
		{
			((Component)child).GetComponent<SpriteRenderer>().flipX = true;
			((Component)child).GetComponent<BoneFollower>().offset = new Vector3(-0.46f, 1.24f, -0.24f);
			child.rotation = Quaternion.Euler(0f, 0f, -267f);
		}
		else
		{
			((Component)child).GetComponent<SpriteRenderer>().flipX = false;
			((Component)child).GetComponent<BoneFollower>().offset = new Vector3(-0.4f, 1.3f, -0.24f);
			child.rotation = Quaternion.Euler(0f, 0f, -109f);
		}
		SFXManager.Instance.PlaySound("GoreSplat2");
		player.inAnim = true;
		player.ActivateStabbed();
		((MonoBehaviour)this).StartCoroutine(StabCoroutine(x, span));
	}

	private void StabPlayerNoMoney()
	{
		UnlockHint("Cindy", 2);
		UnlockHint("Cindy", 3);
		StabPlayer("Você vai precisar de dinheiro se a Cindy começar a ficar hostil.", "Necesitarás dinero si Cindy se vuelve hostil.");
	}

	public void StabPlayerDog()
	{
		StabPlayer("É melhor não mostrar o cachorro quando a Cindy estiver por perto.", "Es mejor cuidar al perro mientras Cindy anda cerca.");
	}

	private IEnumerator StabCoroutine(string x, string span)
	{
		UI.showDeath = true;
		while (player.GetSkeleton().timeScale > 0f)
		{
			player.GetSkeleton().timeScale -= 0.01f;
			yield return null;
		}
		yield return (object)new WaitForSeconds(0.5f);
		if (player.GetSkeleton().skeleton.flipX)
		{
			ShortcutExtensions.DORotate(((Component)player).transform, new Vector3(0f, 0f, 90f), 0.25f, (RotateMode)0);
		}
		else
		{
			ShortcutExtensions.DORotate(((Component)player).transform, new Vector3(0f, 0f, -90f), 0.25f, (RotateMode)0);
		}
		yield return (object)new WaitForSeconds(2f);
		UI.ShowDeath(x, span);
	}

	public void StabNoDeath()
	{
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00dc: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		Transform child = ((Component)player).transform.GetChild(3);
		HideKnife();
		((Renderer)((Component)child).GetComponent<SpriteRenderer>()).enabled = true;
		player.ActivateBloodStream(new Vector3(0f, 1.75f, -3.6f));
		if (player.GetSkeleton().skeleton.flipX)
		{
			((Component)child).GetComponent<SpriteRenderer>().flipX = true;
			((Component)child).GetComponent<BoneFollower>().offset = new Vector3(-0.46f, 1.24f, -0.24f);
			child.rotation = Quaternion.Euler(0f, 0f, -267f);
		}
		else
		{
			((Component)child).GetComponent<SpriteRenderer>().flipX = false;
			((Component)child).GetComponent<BoneFollower>().offset = new Vector3(-0.4f, 1.3f, -0.24f);
			child.rotation = Quaternion.Euler(0f, 0f, -109f);
		}
		SFXManager.Instance.PlaySound("GoreSplat2");
		player.ActivateStabbed();
		((MonoBehaviour)this).StartCoroutine(StabCoroutineNoDeath());
	}

	private IEnumerator StabCoroutineNoDeath()
	{
		while (player.GetSkeleton().timeScale > 0f)
		{
			player.GetSkeleton().timeScale -= 0.005f;
			yield return null;
		}
		yield return (object)new WaitForSeconds(0.5f);
		if (player.GetSkeleton().skeleton.flipX)
		{
			ShortcutExtensions.DORotate(((Component)player).transform, new Vector3(0f, 0f, 90f), 0.25f, (RotateMode)0);
		}
		else
		{
			ShortcutExtensions.DORotate(((Component)player).transform, new Vector3(0f, 0f, -90f), 0.25f, (RotateMode)0);
		}
	}

	private void ResetTexture()
	{
		ApplyTextureBlock(defaultTextureBlock);
	}

	private void EnableLunch()
	{
		conversations[Room.Cafeteria].currentConversation = 4;
		HideBreathalyzer();
		CompleteMission(Mission.CindyPlayHouse);
		ActivateMission(Mission.CindyEatLunch, Room.Cafeteria);
	}

	private void GetCardHouse()
	{
		player.GetItem(Item.GiraffeSerpent);
		UnlockHint("Monstermon", 6);
	}

	private void UsePill()
	{
		player.UseItem(Item.Pill);
	}

	private void UseSlop()
	{
		player.UseItem(Item.Slop);
	}

	private void UseSalad()
	{
		player.UseItem(Item.Salad);
	}

	private void UseDonut()
	{
		player.UseItem(Item.Donut);
	}

	private void UseBiscuitBall()
	{
		player.UseItem(Item.BiscuitBall);
	}

	private void FeedBiscuitBall()
	{
		player.UseItem(Item.BiscuitBall);
		Object.FindObjectOfType<Janitor>().conversations[Room.Cafeteria].Nodes[24].Options[0].IsAvailable = true;
		CompleteMission(Mission.CindyFindVegan);
	}

	private void FeedSalad()
	{
		player.UseItem(Item.Salad);
		CompleteMission(Mission.CindyFindVegan);
	}

	private void UseNugget()
	{
		player.UseItem(Item.Nugget);
	}

	private void GetKey()
	{
		player.GetItem(Item.JanitorKey);
	}

	private void DistractLunchLady()
	{
		((MonoBehaviour)this).StartCoroutine(PayOffLunchLady());
	}

	private void ActivateGumMissionLunch()
	{
		player.GetItem(Item.Gum);
		ActivateMission(Mission.CindyPutGumLunch, Room.Recess);
	}

	private void GetDoomJelly()
	{
		player.GetItem(Item.Doomjelly);
		UnlockHint("Monstermon", 10);
		CompleteMission(Mission.CindyTellPutGumLunch);
		conversations[Room.Recess].currentConversation = 23;
	}

	private IEnumerator PayOffLunchLady()
	{
		LunchLady ll = Object.FindObjectOfType<LunchLady>();
		player.inAnim = true;
		((Behaviour)pCollider).enabled = false;
		ActivateMission(Mission.CindyGoToCloset, Room.Cafeteria);
		SetDirection(setFlip: false);
		SetAnimation("walk");
		ll.SetDistracted(x: true);
		Vector3[] array = (Vector3[])(object)new Vector3[2]
		{
			new Vector3(1.05f, -7.71f, -7.7f),
			new Vector3(-15.85f, -2.58f, -2.57f)
		};
		TweenSettingsExtensions.OnComplete<TweenerCore<Vector3, Path, PathOptions>>(TweenSettingsExtensions.SetEase<TweenerCore<Vector3, Path, PathOptions>>(ShortcutExtensions.DOPath(((Component)this).transform, array, 2f, (PathType)0, (PathMode)1, 10, (Color?)null), (Ease)1), (TweenCallback)delegate
		{
			SetAnimation("idle");
			ll.SetDirection(setFlip: true);
		});
		yield return (object)new WaitForSeconds(3f);
		SetAnimation("walk");
		SetDirection(setFlip: true);
		array = (Vector3[])(object)new Vector3[2]
		{
			new Vector3(1.05f, -7.71f, -7.7f),
			new Vector3(6.34f, -7.71f, -7.703f)
		};
		TweenSettingsExtensions.SetEase<TweenerCore<Vector3, Path, PathOptions>>(ShortcutExtensions.DOPath(((Component)this).transform, array, 2f, (PathType)0, (PathMode)1, 10, (Color?)null), (Ease)1);
		yield return (object)new WaitForSeconds(2f);
		((Behaviour)pCollider).enabled = true;
		FacePlayer();
		player.inAnim = false;
		((Behaviour)pCollider).enabled = true;
		SetAnimation("idle");
		SetCurrentConversation(24);
		Interact();
		conversations[Room.Recess].currentConversation = 1;
	}

	private void StartVegan()
	{
		CompleteMission(Mission.CindyEatLunch);
		ActivateMission(Mission.CindyFindVegan, Room.Cafeteria);
	}

	private void CompleteVegan()
	{
		CompleteMission(Mission.CindyFindVegan);
		if (player.HasItem(Item.BiscuitBall))
		{
			player.UseItem(Item.BiscuitBall);
		}
		else
		{
			player.UseItem(Item.Salad);
		}
	}

	private void WashBlood()
	{
		player.ApplyTextureBlock(player.bruised);
		CompleteMission(Mission.CindyWashUp);
		ActivateMission(Mission.CindyPlayHouse, Room.Classroom1);
		conversations[Room.Classroom1].currentConversation = 4;
	}

	private void CheckActionsLeft()
	{
		if (EnvironmentController.Instance.ActionsLeft() == 0)
		{
			lastSelectedOption.DestinationID = 29;
		}
	}

	private void GetInPosition()
	{
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_011c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0121: Unknown result type (might be due to invalid IL or missing references)
		//IL_0137: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0152: Unknown result type (might be due to invalid IL or missing references)
		//IL_0157: Unknown result type (might be due to invalid IL or missing references)
		//IL_016d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0172: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ad: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a8: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b2: Expected O, but got Unknown
		//IL_01ca: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d4: Expected O, but got Unknown
		CompleteMission(Mission.CindyShowBucket);
		ActivateMission(Mission.CindyDumpBucket);
		if (EnvironmentController.Instance.ActionsLeft() == 0)
		{
			lastSelectedOption.DestinationID = 29;
			return;
		}
		player.inAnim = true;
		player.ForceAnim(walk: true);
		player.inDialogue = true;
		player.lockActions = true;
		bool flag = ((Component)player).transform.position.x > ((Component)this).transform.position.x;
		player.ForceChangeDirection(flag);
		Vector3[] array = (Vector3[])(object)(flag ? new Vector3[4]
		{
			new Vector3(-10.75f, -3.61f, 0f),
			new Vector3(-11.16f, -2.32f, 0f),
			new Vector3(-11.16f, 0.87f, 0f),
			new Vector3(-13.34f, 0.87f, 0f)
		} : new Vector3[4]
		{
			new Vector3(-25.21f, -3.61f, 0f),
			new Vector3(-24.56f, -2.32f, 0f),
			new Vector3(-24.56f, 0.87f, 0f),
			new Vector3(-22.21f, 0.87f, 0f)
		});
		TweenSettingsExtensions.OnUpdate<TweenerCore<Vector3, Path, PathOptions>>(TweenSettingsExtensions.OnWaypointChange<TweenerCore<Vector3, Path, PathOptions>>(TweenSettingsExtensions.OnComplete<TweenerCore<Vector3, Path, PathOptions>>(TweenSettingsExtensions.SetEase<TweenerCore<Vector3, Path, PathOptions>>(ShortcutExtensions.DOPath(((Component)player).transform, array, 3f, (PathType)0, (PathMode)1, 10, (Color?)null), (Ease)1), (TweenCallback)delegate
		{
			player.ForceAnim(walk: false);
			player.inAnim = false;
			player.inDialogue = false;
			SetDirection(setFlip: true);
			((MonoBehaviour)this).StartCoroutine(CallLilyOver());
		}), (TweenCallback<int>)CheckTurnMB), (TweenCallback)delegate
		{
			player.SetDepth();
		});
	}

	private void CheckTurnMB(int x)
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_0025: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		if (x == 1)
		{
			player.ForceChangeDirection(((Component)player).transform.position.x < ((Component)this).transform.position.x);
		}
		if (x == 2)
		{
			if (((Component)player).transform.position.y < 0f)
			{
				GameObject.Find("monkeybars").transform.localPosition = new Vector3(-17.5f, -0.8f, -3f);
			}
			else
			{
				GameObject.Find("monkeybars").transform.localPosition = new Vector3(-17.5f, -0.8f, -7.458f);
			}
		}
	}

	private IEnumerator CallLilyOver()
	{
		Lily i = Object.FindObjectOfType<Lily>();
		SetEmptyOptions();
		yield return null;
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("Ei! Lily!~ Vem aqui! Quero te mostrar uma coisa!", "¡Hey! ¡Lily!~ ¡Ven! ¡Quiero mostrarte algo!", this));
		while (pEmptyOptions)
		{
			yield return null;
		}
		i.SetDirection(setFlip: false);
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("Por que você simplesmente não me deixa em paz, Cindy?~ Tô de saco cheio de você me encher o saco!", "¿Por qué no me dejas en paz, Cindy? ~¡Estoy harto de que me acoses!", i));
		while (pEmptyOptions)
		{
			yield return null;
		}
		((MonoBehaviour)this).StartCoroutine(RunDialogueSection("Eu não vou te encher o saco!~ A gente pode ser amigos! Só vem aqui.", "¡No voy a acosarte! ~ ¡Podemos ser amigos! Sólo ven acá.", this));
		while (pEmptyOptions)
		{
			yield return null;
		}
		player.inAnim = true;
		i.mySkeleton.AnimationName = "walk";
		TweenSettingsExtensions.OnComplete<TweenerCore<Vector3, Vector3, VectorOptions>>(TweenSettingsExtensions.SetEase<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOMove(((Component)i).transform, new Vector3(-16.93f, -3.57f, -3.62f), 2f, false), (Ease)1), (TweenCallback)delegate
		{
			i.mySkeleton.AnimationName = "idle";
			i.SetDirection(setFlip: true);
			((MonoBehaviour)this).StartCoroutine(RunDialogueSection("O que é?", "¿Qué es?", i));
			while (pEmptyOptions)
			{
				// yield return null;
			}
		});
	}
}
