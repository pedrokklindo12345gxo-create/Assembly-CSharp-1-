using UnityEngine;

namespace Spine.Unity.Modules;

public class SkeletonUtilityEyeConstraint : SkeletonUtilityConstraint
{
	public Transform[] eyes;

	public float radius = 0.5f;

	public Transform target;

	public Vector3 targetPosition;

	public float speed = 10f;

	private Vector3[] origins;

	private Vector3 centerPoint;

	protected override void OnEnable()
	{
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0051: Unknown result type (might be due to invalid IL or missing references)
		//IL_005f: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0080: Unknown result type (might be due to invalid IL or missing references)
		if (Application.isPlaying)
		{
			base.OnEnable();
			Bounds val = default(Bounds);
			((Bounds)(ref val))._002Ector(eyes[0].localPosition, Vector3.zero);
			origins = (Vector3[])(object)new Vector3[eyes.Length];
			for (int i = 0; i < eyes.Length; i++)
			{
				origins[i] = eyes[i].localPosition;
				((Bounds)(ref val)).Encapsulate(origins[i]);
			}
			centerPoint = ((Bounds)(ref val)).center;
		}
	}

	protected override void OnDisable()
	{
		if (Application.isPlaying)
		{
			base.OnDisable();
		}
	}

	public override void DoUpdate()
	{
		//IL_0020: Unknown result type (might be due to invalid IL or missing references)
		//IL_002c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_003d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		//IL_001a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0064: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006e: Unknown result type (might be due to invalid IL or missing references)
		//IL_007f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0084: Unknown result type (might be due to invalid IL or missing references)
		//IL_0085: Unknown result type (might be due to invalid IL or missing references)
		//IL_008c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a2: Unknown result type (might be due to invalid IL or missing references)
		if ((Object)(object)target != (Object)null)
		{
			targetPosition = target.position;
		}
		Vector3 val = targetPosition;
		Vector3 val2 = ((Component)this).transform.TransformPoint(centerPoint);
		Vector3 val3 = val - val2;
		if (((Vector3)(ref val3)).magnitude > 1f)
		{
			((Vector3)(ref val3)).Normalize();
		}
		for (int i = 0; i < eyes.Length; i++)
		{
			val2 = ((Component)this).transform.TransformPoint(origins[i]);
			eyes[i].position = Vector3.MoveTowards(eyes[i].position, val2 + val3 * radius, speed * Time.deltaTime);
		}
	}
}
