using System;
using UnityEngine;

namespace Spine.Unity.Modules.AttachmentTools;

public static class AttachmentCloneExtensions
{
	public static Attachment GetClone(this Attachment o, bool cloneMeshesAsLinked)
	{
		if (o is RegionAttachment o2)
		{
			return o2.GetClone();
		}
		if (o is MeshAttachment o3)
		{
			if (cloneMeshesAsLinked)
			{
				return o3.GetLinkedClone();
			}
			return o3.GetClone();
		}
		if (o is BoundingBoxAttachment o4)
		{
			return o4.GetClone();
		}
		if (o is PathAttachment o5)
		{
			return o5.GetClone();
		}
		return null;
	}

	public static RegionAttachment GetClone(this RegionAttachment o)
	{
		return new RegionAttachment(o.Name + "clone")
		{
			x = o.x,
			y = o.y,
			rotation = o.rotation,
			scaleX = o.scaleX,
			scaleY = o.scaleY,
			width = o.width,
			height = o.height,
			r = o.r,
			g = o.g,
			b = o.b,
			a = o.a,
			Path = o.Path,
			RendererObject = o.RendererObject,
			regionOffsetX = o.regionOffsetX,
			regionOffsetY = o.regionOffsetY,
			regionWidth = o.regionWidth,
			regionHeight = o.regionHeight,
			regionOriginalWidth = o.regionOriginalWidth,
			regionOriginalHeight = o.regionOriginalHeight,
			uvs = (o.uvs.Clone() as float[]),
			offset = (o.offset.Clone() as float[])
		};
	}

	public static BoundingBoxAttachment GetClone(this BoundingBoxAttachment o)
	{
		BoundingBoxAttachment boundingBoxAttachment = new BoundingBoxAttachment(o.Name);
		CloneVertexAttachment(o, boundingBoxAttachment);
		return boundingBoxAttachment;
	}

	public static MeshAttachment GetLinkedClone(this MeshAttachment o, bool inheritDeform = true)
	{
		return o.GetLinkedMesh(o.Name, o.RendererObject as AtlasRegion, inheritDeform);
	}

	public static MeshAttachment GetClone(this MeshAttachment o)
	{
		MeshAttachment meshAttachment = new MeshAttachment(o.Name)
		{
			r = o.r,
			g = o.g,
			b = o.b,
			a = o.a,
			inheritDeform = o.inheritDeform,
			Path = o.Path,
			RendererObject = o.RendererObject,
			regionOffsetX = o.regionOffsetX,
			regionOffsetY = o.regionOffsetY,
			regionWidth = o.regionWidth,
			regionHeight = o.regionHeight,
			regionOriginalWidth = o.regionOriginalWidth,
			regionOriginalHeight = o.regionOriginalHeight,
			RegionU = o.RegionU,
			RegionV = o.RegionV,
			RegionU2 = o.RegionU2,
			RegionV2 = o.RegionV2,
			RegionRotate = o.RegionRotate,
			uvs = (o.uvs.Clone() as float[])
		};
		if (o.ParentMesh != null)
		{
			meshAttachment.ParentMesh = o.ParentMesh;
		}
		else
		{
			CloneVertexAttachment(o, meshAttachment);
			meshAttachment.regionUVs = o.regionUVs.Clone() as float[];
			meshAttachment.triangles = o.triangles.Clone() as int[];
			meshAttachment.hulllength = o.hulllength;
			meshAttachment.Edges = ((o.Edges != null) ? (o.Edges.Clone() as int[]) : null);
			meshAttachment.Width = o.Width;
			meshAttachment.Height = o.Height;
		}
		return meshAttachment;
	}

	public static PathAttachment GetClone(this PathAttachment o)
	{
		PathAttachment pathAttachment = new PathAttachment(o.Name)
		{
			lengths = (o.lengths.Clone() as float[]),
			closed = o.closed,
			constantSpeed = o.constantSpeed
		};
		CloneVertexAttachment(o, pathAttachment);
		return pathAttachment;
	}

	private static void CloneVertexAttachment(VertexAttachment src, VertexAttachment dest)
	{
		dest.worldVerticesLength = src.worldVerticesLength;
		if (src.bones != null)
		{
			dest.bones = src.bones.Clone() as int[];
		}
		if (src.vertices != null)
		{
			dest.vertices = src.vertices.Clone() as float[];
		}
	}

	public static MeshAttachment GetLinkedMesh(this MeshAttachment o, string newLinkedMeshName, AtlasRegion region, bool inheritDeform = true)
	{
		if (region == null)
		{
			throw new ArgumentNullException("region");
		}
		if (o.ParentMesh != null)
		{
			o = o.ParentMesh;
		}
		MeshAttachment meshAttachment = new MeshAttachment(newLinkedMeshName);
		meshAttachment.SetRegion(region, updateUVs: false);
		meshAttachment.Path = newLinkedMeshName;
		meshAttachment.r = 1f;
		meshAttachment.g = 1f;
		meshAttachment.b = 1f;
		meshAttachment.a = 1f;
		meshAttachment.inheritDeform = inheritDeform;
		meshAttachment.ParentMesh = o;
		meshAttachment.UpdateUVs();
		return meshAttachment;
	}

	public static MeshAttachment GetLinkedMesh(this MeshAttachment o, Sprite sprite, Shader shader, bool inheritDeform = true, Material materialPropertySource = null)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Expected O, but got Unknown
		Material val = new Material(shader);
		if ((Object)(object)materialPropertySource != (Object)null)
		{
			val.CopyPropertiesFromMaterial(materialPropertySource);
			val.shaderKeywords = materialPropertySource.shaderKeywords;
		}
		return o.GetLinkedMesh(((Object)sprite).name, sprite.ToAtlasRegion(), inheritDeform);
	}

	public static MeshAttachment GetLinkedMesh(this MeshAttachment o, Sprite sprite, Material materialPropertySource, bool inheritDeform = true)
	{
		return o.GetLinkedMesh(sprite, materialPropertySource.shader, inheritDeform, materialPropertySource);
	}
}
