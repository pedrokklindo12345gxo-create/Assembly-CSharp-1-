using System;
using UnityEngine;

namespace Spine.Unity;

[ExecuteInEditMode]
[AddComponentMenu("Spine/SkeletonUtilityBone")]
public class SkeletonUtilityBone : MonoBehaviour
{
	public enum Mode
	{
		Follow,
		Override
	}

	public string boneName;

	public Transform parentReference;

	public Mode mode;

	public bool position;

	public bool rotation;

	public bool scale;

	public bool zPosition = true;

	[Range(0f, 1f)]
	public float overrideAlpha = 1f;

	[NonSerialized]
	public SkeletonUtility skeletonUtility;

	[NonSerialized]
	public Bone bone;

	[NonSerialized]
	public bool transformLerpComplete;

	[NonSerialized]
	public bool valid;

	private Transform cachedTransform;

	private Transform skeletonTransform;

	private bool incompatibleTransformMode;

	public bool IncompatibleTransformMode => incompatibleTransformMode;

	public void Reset()
	{
		bone = null;
		cachedTransform = ((Component)this).transform;
		valid = (Object)(object)skeletonUtility != (Object)null && (Object)(object)skeletonUtility.skeletonRenderer != (Object)null && skeletonUtility.skeletonRenderer.valid;
		if (valid)
		{
			skeletonTransform = ((Component)skeletonUtility).transform;
			skeletonUtility.OnReset -= HandleOnReset;
			skeletonUtility.OnReset += HandleOnReset;
			DoUpdate();
		}
	}

	private void OnEnable()
	{
		skeletonUtility = ((Component)((Component)this).transform).GetComponentInParent<SkeletonUtility>();
		if (!((Object)(object)skeletonUtility == (Object)null))
		{
			skeletonUtility.RegisterBone(this);
			skeletonUtility.OnReset += HandleOnReset;
		}
	}

	private void HandleOnReset()
	{
		Reset();
	}

	private void OnDisable()
	{
		if ((Object)(object)skeletonUtility != (Object)null)
		{
			skeletonUtility.OnReset -= HandleOnReset;
			skeletonUtility.UnregisterBone(this);
		}
	}

	public void DoUpdate()
	{
		//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
		//IL_01df: Unknown result type (might be due to invalid IL or missing references)
		//IL_01e4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f7: Unknown result type (might be due to invalid IL or missing references)
		//IL_021f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0192: Unknown result type (might be due to invalid IL or missing references)
		//IL_0128: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0130: Unknown result type (might be due to invalid IL or missing references)
		//IL_0135: Unknown result type (might be due to invalid IL or missing references)
		//IL_013c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0142: Unknown result type (might be due to invalid IL or missing references)
		//IL_0148: Unknown result type (might be due to invalid IL or missing references)
		//IL_015c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_0312: Unknown result type (might be due to invalid IL or missing references)
		//IL_0317: Unknown result type (might be due to invalid IL or missing references)
		//IL_031c: Unknown result type (might be due to invalid IL or missing references)
		//IL_032f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0357: Unknown result type (might be due to invalid IL or missing references)
		//IL_024f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0254: Unknown result type (might be due to invalid IL or missing references)
		//IL_0257: Unknown result type (might be due to invalid IL or missing references)
		//IL_0381: Unknown result type (might be due to invalid IL or missing references)
		//IL_0392: Unknown result type (might be due to invalid IL or missing references)
		//IL_0397: Unknown result type (might be due to invalid IL or missing references)
		//IL_039c: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_03a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0299: Unknown result type (might be due to invalid IL or missing references)
		//IL_029e: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02d9: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e3: Unknown result type (might be due to invalid IL or missing references)
		//IL_03e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_03fb: Unknown result type (might be due to invalid IL or missing references)
		//IL_0423: Unknown result type (might be due to invalid IL or missing references)
		if (!valid)
		{
			Reset();
			return;
		}
		Skeleton skeleton = skeletonUtility.skeletonRenderer.skeleton;
		if (bone == null)
		{
			if (string.IsNullOrEmpty(boneName))
			{
				return;
			}
			bone = skeleton.FindBone(boneName);
			if (bone == null)
			{
				Debug.LogError((object)("Bone not found: " + boneName), (Object)(object)this);
				return;
			}
		}
		float num = ((!(skeleton.flipX ^ skeleton.flipY)) ? 1f : (-1f));
		Quaternion val;
		if (mode == Mode.Follow)
		{
			if (!bone.appliedValid)
			{
				bone.UpdateAppliedTransform();
			}
			if (position)
			{
				cachedTransform.localPosition = new Vector3(bone.ax, bone.ay, 0f);
			}
			if (rotation)
			{
				if (bone.data.transformMode.InheritsRotation())
				{
					cachedTransform.localRotation = Quaternion.Euler(0f, 0f, bone.AppliedRotation);
				}
				else
				{
					val = skeletonTransform.rotation;
					Vector3 eulerAngles = ((Quaternion)(ref val)).eulerAngles;
					cachedTransform.rotation = Quaternion.Euler(eulerAngles.x, eulerAngles.y, eulerAngles.z + bone.WorldRotationX * num);
				}
			}
			if (scale)
			{
				cachedTransform.localScale = new Vector3(bone.ascaleX, bone.ascaleY, 1f);
				incompatibleTransformMode = BoneTransformModeIncompatible(bone);
			}
		}
		else
		{
			if (mode != Mode.Override || transformLerpComplete)
			{
				return;
			}
			if ((Object)(object)parentReference == (Object)null)
			{
				if (position)
				{
					Vector3 localPosition = cachedTransform.localPosition;
					bone.x = Mathf.Lerp(bone.x, localPosition.x, overrideAlpha);
					bone.y = Mathf.Lerp(bone.y, localPosition.y, overrideAlpha);
				}
				if (rotation)
				{
					float num2 = bone.Rotation;
					val = cachedTransform.localRotation;
					float appliedRotation = Mathf.LerpAngle(num2, ((Quaternion)(ref val)).eulerAngles.z, overrideAlpha);
					bone.Rotation = appliedRotation;
					bone.AppliedRotation = appliedRotation;
				}
				if (scale)
				{
					Vector3 localScale = cachedTransform.localScale;
					bone.scaleX = Mathf.Lerp(bone.scaleX, localScale.x, overrideAlpha);
					bone.scaleY = Mathf.Lerp(bone.scaleY, localScale.y, overrideAlpha);
				}
			}
			else
			{
				if (transformLerpComplete)
				{
					return;
				}
				if (position)
				{
					Vector3 val2 = parentReference.InverseTransformPoint(cachedTransform.position);
					bone.x = Mathf.Lerp(bone.x, val2.x, overrideAlpha);
					bone.y = Mathf.Lerp(bone.y, val2.y, overrideAlpha);
				}
				if (rotation)
				{
					float num3 = bone.Rotation;
					val = Quaternion.LookRotation(Vector3.forward, parentReference.InverseTransformDirection(cachedTransform.up));
					float appliedRotation2 = Mathf.LerpAngle(num3, ((Quaternion)(ref val)).eulerAngles.z, overrideAlpha);
					bone.Rotation = appliedRotation2;
					bone.AppliedRotation = appliedRotation2;
				}
				if (scale)
				{
					Vector3 localScale2 = cachedTransform.localScale;
					bone.scaleX = Mathf.Lerp(bone.scaleX, localScale2.x, overrideAlpha);
					bone.scaleY = Mathf.Lerp(bone.scaleY, localScale2.y, overrideAlpha);
				}
				incompatibleTransformMode = BoneTransformModeIncompatible(bone);
			}
			transformLerpComplete = true;
		}
	}

	public static bool BoneTransformModeIncompatible(Bone bone)
	{
		return !bone.data.transformMode.InheritsScale();
	}

	public void AddBoundingBox(string skinName, string slotName, string attachmentName)
	{
		SkeletonUtility.AddBoundingBoxGameObject(bone.skeleton, skinName, slotName, attachmentName, ((Component)this).transform);
	}
}
