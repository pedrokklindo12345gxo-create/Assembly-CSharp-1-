using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

public class HsvSliderPicker : MonoBehaviour, IDragHandler, IEventSystemHandler, IPointerDownHandler
{
	public HSVPicker picker;

	public Slider slider;

	private void PlacePointer(PointerEventData eventData)
	{
		//IL_0003: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0038: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_008e: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00bd: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c4: Unknown result type (might be due to invalid IL or missing references)
		Vector2 val = default(Vector2);
		((Vector2)(ref val))._002Ector(eventData.position.x - ((Transform)((Graphic)picker.hsvSlider).rectTransform).position.x, ((Transform)((Graphic)picker.hsvSlider).rectTransform).position.y - eventData.position.y);
		ref float y = ref val.y;
		float num = y;
		Rect rect = ((Graphic)picker.hsvSlider).rectTransform.rect;
		y = num / (((Rect)(ref rect)).height * ((Component)((Graphic)picker.hsvSlider).canvas).transform.lossyScale.y);
		val.y = Mathf.Clamp(val.y, 0f, 1f);
		picker.MovePointer(val.y);
	}

	public void OnDrag(PointerEventData eventData)
	{
		PlacePointer(eventData);
	}

	public void OnPointerDown(PointerEventData eventData)
	{
		PlacePointer(eventData);
	}

	public void SliderPositionChanged(float sliderValue)
	{
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		picker.MovePointer(sliderValue);
	}

	internal void SetSliderPosition(float pointerPos)
	{
		slider.normalizedValue = pointerPos;
	}
}
