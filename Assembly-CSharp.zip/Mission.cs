using System.ComponentModel;

public enum Mission
{
	None,
	[Description("Give Jerome the yo-yo during morning time.")]
	JeromeGiveYoyo,
	[Description("Leave the classroom while the teacher is distracted.")]
	JeromeLeaveClassroom,
	[Description("Get into the janitor's closet.")]
	JeromeGoToCloset,
	[Description("Get the laser pointer out of the 'stolen stuff' box.")]
	JeromeGetLaserFromBox,
	[Description("Bring the laser pointer back to Jerome.")]
	JeromeBringLaser,
	[Description("Hide the laser pointer.")]
	JeromeHideLaser,
	[Description("Get the laser pointer from the bathroom before lunch ends.")]
	JeromeGetLaserFromBathroom,
	[Description("Try to bring the laser pointer to Jerome...again.")]
	JeromeBringLaserRecess,
	[Description("Save Jerome from the Janitor before recess ends.")]
	JeromeSaveFromJanitor,
	[Description("Place the device behind the janitor.")]
	JeromePlaceDevice,
	[Description("Tell Monty you placed the device.")]
	JeromeTellMontyDevicePlaced,
	[Description("Solve the duck riddle.")]
	JeromeSolveRiddle,
	[Description("Find out when the teacher is alone.")]
	BuggsFindOutWhenAlone,
	[Description("Tell Buggs when the teacher is alone.")]
	BuggsTellWhenAlone,
	[Description("Talk to Buggs during lunch.")]
	BuggsTalkAtLunch,
	[Description("Talk to the other kids to see if they have any dirt on them.")]
	BuggsFindOutGoldStars,
	[Description("See if Monty has a distraction of some kind.")]
	BuggsCheckForDistraction,
	[Description("Tell Buggs you got a distraction device.")]
	BuggsTellGotDistraction,
	[Description("Place the distraction device under one of the front tables.")]
	BuggsPlaceDevice,
	[Description("Use the lunch pass to have lunch with the teacher.")]
	BuggsGoToLunchWithTeacher,
	[Description("Kill the teacher.")]
	BuggsKillTeacher,
	[Description("Talk to Buggs at recess to find out what to do with the knife.")]
	BuggsDisposeOfKnife,
	[Description("Convince Nugget to let you hide the knife in the Nugget Cave.")]
	BuggsConvinceHide,
	[Description("Put the gum Cindy gave you in Lily's hair during morning time. lol")]
	CindyPutGumInHair,
	[Description("Tell Cindy you put the gum in Lily's hair.")]
	CindyTalkMorningTime,
	[Description("Go to the bathroom to clean yourself up.")]
	CindyWashUp,
	[Description("Play house with Cindy.")]
	CindyPlayHouse,
	[Description("Have lunch with Cindy.")]
	CindyEatLunch,
	[Description("Find something 'vegan' for Cindy to eat.")]
	CindyFindVegan,
	[Description("Go to the janitor's closet.")]
	CindyGoToCloset,
	[Description("Find something gross in the janitor's closet.")]
	CindyFindSomethingGross,
	[Description("Head back to the cafeteria.")]
	CindyGoBackToCafeteria,
	[Description("Show Cindy the bucket of blood.")]
	CindyShowBucket,
	[Description("Dump the bucket on Lily.")]
	CindyDumpBucket,
	[Description("Show Cindy the piece of paper.")]
	CindyShowPaper,
	[Description("Find someone who can read the paper.")]
	CindyReadPaper,
	[Description("Tell Cindy about the recipe.")]
	CindyTellPaper,
	[Description("Tell Cindy about the recipe.")]
	CindyTellAboutDog,
	[Description("Put the gum in Lily's hair during lunch.")]
	CindyPutGumLunch,
	[Description("Tell Cindy you put the gum in Lily's hair.")]
	CindyTellPutGumLunch,
	[Description("Show Lily the note Nugget gave you before morning time.")]
	LilyShowNote,
	[Description("Find someone to read the note.")]
	LilyReadNote,
	[Description("Tell Lily that Monty is deciphering the note before morning time starts.")]
	LilyTellNote,
	[Description("Get the deciphered note from Monty at lunch.")]
	LilyGetNoteFromMonty,
	[Description("Show the deciphered note to Lily during lunch.")]
	LilyShowCode,
	[Description("Get sent to the principal's office alone.")]
	LilyGetSentToOffice,
	[Description("Find the hatch the note mentioned in the principal's office.")]
	LilyLookForSomethingSuspicious,
	[Description("Tell Lily about the hatch during morning time.")]
	LilyTellAboutTheHatch,
	[Description("Figure out how to lure the principal out of his office.")]
	LilyFindWayToLure,
	[Description("Figure out how to get a key to the principal's office.")]
	LilyFindWayToGetKey,
	[Description("Talk to Lily during lunch.")]
	LilyTalkAtLunch,
	[Description("Meet Lily in the bathroom.")]
	LilyMeetInBathroom,
	[Description("Call the principal from the bathroom.")]
	LilyCallInThreat,
	[Description("Use the key to get into the principal's office.")]
	LilyUseKey,
	[Description("Find a way to open the hatch.")]
	LilyOpenHatch,
	[Description("Find evidence of Billy's disappearance in the bathroom.")]
	LilyFindEvidence,
	[Description("Show Lily the evidence of Billy's disapperance.")]
	LilyShowEvidence,
	[Description("Save Billy.")]
	LilySaveBilly,
	[Description("Collect the five nuggets of friendship.")]
	NuggetCollectNuggets,
	[Description("Talk to Nugget during morning time.")]
	NuggetStartCollectNuggets,
	[Description("Get the nugget of friendship from Nugget's cubby.")]
	NuggetGetCubbyNugget,
	[Description("Ask Nugget how to get the next nugget of friendship.")]
	NuggetStartThirdNugget,
	[Description("Give Nugget's love letter to Lily.")]
	NuggetGiveLoveLetter,
	[Description("Tell Nugget you delivered the letter.")]
	NuggetDeliveredLetter,
	[Description("Talk to Nugget about getting the next nugget at lunch.")]
	NuggetTalkAtLunch,
	[Description("Kill Buggs during lunch.")]
	NuggetKillBuggs,
	[Description("Get Buggs to eat the poisoned nugget.")]
	NuggetPoisonBuggs,
	[Description("Get the antidote from Nugget.")]
	NuggetGetAntidote,
	[Description("Tell Nugget you stabbed Buggs.")]
	NuggetTellStabbedBuggs,
	[Description("Tell Nugget you poisoned Buggs.")]
	NuggetTellPoisonedBuggs,
	[Description("Talk to Nugget about the last nugget of friendship at recess.")]
	NuggetTalkAtRecess,
	[Description("Place the device on the statue.")]
	NuggetPlaceDevice,
	[Description("Talk to Lily about Billy's disappearance to trigger the device.")]
	NuggetTalkToLily,
	[Description("Collect the last nugget of friendship to enter the Nugget Cave.")]
	NuggetGetLastNugget,
	[Description("Talk to Nugget during lunch.")]
	NuggetJoinAtLunch,
	[Description("Get Nugget a magnifying glass.")]
	NuggetGetMagnifyingGlass,
	[Description("Ask Monty to make a key out of the mold Jerome gave you.")]
	MontyAskFormold,
	[Description("Collect $20 to buy the key from Monty at the end of the day.")]
	MontyCollectTwenty,
	[Description("Tell the Janitor he mispelt 'biscuit'.")]
	MontyCorrectSpelling,
	[Description("Tell the teacher that Buggs threatened you.")]
	TeacherTellOnBuggs,
	[Description("Start a fight with Buggs.")]
	TeacherStartFightWithBuggs,
	[Description("Talk to the teacher about Jerome during morning time.")]
	TeacherTalkMorningTimeJerome,
	[Description("Try to get the stolen hall pass from Jerome.")]
	TeacherTryToGetPass,
	[Description("Find something to give to Jerome.")]
	TeacherFindJeromeGift,
	[Description("Give the pass to the teacher.")]
	TeacherGivePass,
	[Description("Gain the trust of Nugget before recess starts.")]
	TeacherNuggetGainTrust,
	[Description("Tell the teacher you gained Nugget's trust.")]
	TeacherTellGainedTrust,
	[Description("Enter the Nugget Cave.")]
	TeacherEnterNuggetCave,
	[Description("Collect evidence of Nugget's wrong doing.")]
	TeacherCollectEvidence,
	[Description("Show the teacher the dog remains.")]
	TeacherShowEvidence,
	[Description("Get Lily in trouble.")]
	TeacherGetLilyInTrouble,
	[Description("Tell the teacher what happened to Lily.")]
	TeacherCollectLilyStar,
	[Description("Get Monty in trouble.")]
	TeacherGetMontyInTrouble,
	[Description("Tell the teacher what happened to Monty.")]
	TeacherCollectMontyStar,
	[Description("Get Buggs in trouble again.")]
	TeacherGetBuggsInTrouble,
	[Description("Tell the teacher you stabbed Buggs.")]
	TeacherTellStabbedBuggs,
	[Description("Tell the teacher you poisoned Buggs.")]
	TeacherTellPoisonedBuggs,
	End
}
