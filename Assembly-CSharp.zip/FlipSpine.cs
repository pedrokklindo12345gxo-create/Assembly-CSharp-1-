using Spine.Unity;
using UnityEngine;

public class FlipSpine : MonoBehaviour
{
	private void Start()
	{
		((Component)this).GetComponent<SkeletonAnimation>().skeleton.flipX = true;
	}

	private void Update()
	{
		if (Input.GetKeyDown((KeyCode)112))
		{
			ScreenCapture.CaptureScreenshot("KG.png");
		}
	}
}
