using UnityEngine.EventSystems;
using UnityEngine.UI;

public class ColorScrollRect : ScrollRect
{
	public bool Dragging { get; private set; }

	public override void OnInitializePotentialDrag(PointerEventData eventData)
	{
		Dragging = true;
		((ScrollRect)this).OnInitializePotentialDrag(eventData);
	}

	public override void OnBeginDrag(PointerEventData eventData)
	{
		Dragging = true;
		((ScrollRect)this).OnBeginDrag(eventData);
	}

	public override void OnDrag(PointerEventData eventData)
	{
		Dragging = true;
		((ScrollRect)this).OnDrag(eventData);
	}

	public override void OnEndDrag(PointerEventData eventData)
	{
		Dragging = false;
		((ScrollRect)this).OnEndDrag(eventData);
	}
}
