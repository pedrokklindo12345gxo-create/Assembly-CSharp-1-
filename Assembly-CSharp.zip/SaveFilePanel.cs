using UnityEngine;
using UnityEngine.UI;

public class SaveFilePanel : MonoBehaviour
{
	public Text dayCount;

	public Text moneyCount;

	public Text monstermonCount;

	public Image keyMold;

	public Image flower;

	public Image lunchPass;

	public Image phone;

	public Image principalKey;

	public Image billyNote;

	public Image nuggetFace;

	public bool file1;

	private void Start()
	{
		//IL_01d7: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_0211: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_022e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00cb: Unknown result type (might be due to invalid IL or missing references)
		//IL_024b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_0268: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		PlayerPrefs.Save();
		if (file1)
		{
			int num = PlayerPrefs.GetInt("DaysComplete", 1);
			if (num > 1)
			{
				dayCount.text = "Day #" + num;
				moneyCount.text = PlayerPrefs.GetFloat("PiggyBank").ToString("c2");
				if (PlayerPrefs.GetInt("UnlockKeyMold", 0) != 0)
				{
					((Graphic)keyMold).color = Color.white;
				}
				if (PlayerPrefs.GetInt("UnlockFlower", 0) != 0)
				{
					((Graphic)flower).color = Color.white;
				}
				if (PlayerPrefs.GetInt("UnlockLunchPass", 0) != 0)
				{
					((Graphic)lunchPass).color = Color.white;
				}
				if (PlayerPrefs.GetInt("UnlockPhone", 0) != 0)
				{
					((Graphic)phone).color = Color.white;
				}
				if (PlayerPrefs.GetInt("UnlockPrincipalKey", 0) != 0)
				{
					((Graphic)principalKey).color = Color.white;
				}
				if (PlayerPrefs.GetInt("UnlockBillyNote", 0) != 0)
				{
					((Graphic)billyNote).color = Color.white;
				}
				int num2 = PlayerPrefs.GetInt("UnlockedCards", 0);
				if (num2 > 0)
				{
					monstermonCount.text = num2 + "/25";
				}
				else
				{
					monstermonCount.text = "?/25";
				}
				if (PlayerPrefs.GetInt("WorldEnder", 0) == 1)
				{
					((Behaviour)nuggetFace).enabled = true;
				}
			}
		}
		else if (PlayerPrefs.GetInt("DaysComplete2", 1) > 1)
		{
			dayCount.text = "Day #" + PlayerPrefs.GetInt("DaysComplete2", 1);
			moneyCount.text = PlayerPrefs.GetFloat("PiggyBank2").ToString("c2");
			if (PlayerPrefs.GetInt("UnlockKeyMold2", 0) != 0)
			{
				((Graphic)keyMold).color = Color.white;
			}
			if (PlayerPrefs.GetInt("UnlockFlower2", 0) != 0)
			{
				((Graphic)flower).color = Color.white;
			}
			if (PlayerPrefs.GetInt("UnlockLunchPass2", 0) != 0)
			{
				((Graphic)lunchPass).color = Color.white;
			}
			if (PlayerPrefs.GetInt("UnlockPhone2", 0) != 0)
			{
				((Graphic)phone).color = Color.white;
			}
			if (PlayerPrefs.GetInt("UnlockPrincipalKey2", 0) != 0)
			{
				((Graphic)principalKey).color = Color.white;
			}
			if (PlayerPrefs.GetInt("UnlockBillyNote2", 0) != 0)
			{
				((Graphic)billyNote).color = Color.white;
			}
			int num3 = PlayerPrefs.GetInt("UnlockedCards2", 0);
			if (num3 > 0)
			{
				monstermonCount.text = num3 + "/25";
			}
			else
			{
				monstermonCount.text = "?/25";
			}
			if (PlayerPrefs.GetInt("WorldEnder2", 0) == 1)
			{
				((Behaviour)nuggetFace).enabled = true;
			}
		}
	}
}
