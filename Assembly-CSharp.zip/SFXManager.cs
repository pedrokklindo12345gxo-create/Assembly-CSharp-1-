using UnityEngine;

public class SFXManager : MonoBehaviour
{
	public static SFXManager Instance;

	private AudioSource[] sfx;

	private AudioSource music;

	private float mMusicVolume;

	private float mEffectsVolume;

	private string mCurrentMusic = "none";

	private void Awake()
	{
		Instance = this;
		sfx = ((Component)this).GetComponentsInChildren<AudioSource>();
	}

	private void Start()
	{
		mMusicVolume = PlayerPrefs.GetFloat("MusicVolume", 0.5f);
		mEffectsVolume = PlayerPrefs.GetFloat("EffectsVolume", 1f);
		if (Object.op_Implicit((Object)(object)EnvironmentController.Instance))
		{
			if (EnvironmentController.currentRoom == Room.Bedroom)
			{
				PlayMusic("BedroomTheme");
			}
			else if (EnvironmentController.currentRoom == Room.Lair)
			{
				PlayMusic("LairTheme");
			}
			else
			{
				PlayMusic("ThemeMusic");
			}
		}
		else
		{
			PlayMusic("TitleMusic");
		}
	}

	public void SetVolumes(float m, float e)
	{
		mMusicVolume = m;
		mEffectsVolume = e;
		if (Object.op_Implicit((Object)(object)music))
		{
			music.volume = m;
		}
	}

	public void PlaySound(string s)
	{
		AudioSource[] array = sfx;
		foreach (AudioSource val in array)
		{
			if (((Object)val.clip).name == s)
			{
				val.PlayOneShot(val.clip, mEffectsVolume);
				return;
			}
		}
		Debug.LogError((object)("Could not find sound effect " + s + " in sfx manager."));
	}

	public void StopSound(string s)
	{
		AudioSource[] array = sfx;
		foreach (AudioSource val in array)
		{
			if (((Object)val.clip).name == s)
			{
				val.Stop();
				return;
			}
		}
		Debug.LogError((object)("Could not find sound effect " + s + " in sfx manager."));
	}

	public void RestartMusic()
	{
		if (Object.op_Implicit((Object)(object)music) && !music.isPlaying)
		{
			music.volume = mMusicVolume;
			music.Play();
		}
	}

	public void PlayMusic(string s)
	{
		if (!(mCurrentMusic != s))
		{
			return;
		}
		mCurrentMusic = s;
		if (Object.op_Implicit((Object)(object)music))
		{
			music.Stop();
		}
		AudioSource[] array = sfx;
		foreach (AudioSource val in array)
		{
			if (((Object)val.clip).name == s)
			{
				music = val;
				val.volume = mMusicVolume;
				val.Play();
				return;
			}
		}
		Debug.LogError((object)("Could not find sound effect " + s + " in sfx manager."));
	}

	public void StopMusic()
	{
		if (Object.op_Implicit((Object)(object)music))
		{
			music.Stop();
		}
	}
}
