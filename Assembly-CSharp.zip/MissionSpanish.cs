using System.ComponentModel;

public enum MissionSpanish
{
	[Description("Entregar a Jerome el yo-yo en las clase de la mañana.")]
	JeromeGiveYoyo,
	[Description("Salir del salón cuando la maestra este distraída.")]
	JeromeLeaveClassroom,
	[Description("Meterse en el armario del conserje.")]
	JeromeGoToCloset,
	[Description("Sacar el puntero láser de la caja de objetos robados.")]
	JeromeGetLaserFromBox,
	[Description("Devolver el puntero láser  a Jerome.")]
	JeromeBringLaser,
	[Description("Esconder el puntero láser.")]
	JeromeHideLaser,
	[Description("Sacar el puntero laser del baño, antes de que termine el almuerzo.")]
	JeromeGetLaserFromBathroom,
	[Description("Tratar de entregar el puntero láser a Jerome…de nuevo.")]
	JeromeBringLaserRecess,
	[Description("Salvar a Jerome del conserje antes de que termine el recreo.")]
	JeromeSaveFromJanitor,
	[Description("Colocar el dispositivo detrás del conserje.")]
	JeromePlaceDevice,
	[Description("Decir a Monty que colocaste el dispositivo.")]
	JeromeTellMontyDevicePlaced,
	[Description("Resolver el acertijo del pato.")]
	JeromeSolveRiddle,
	[Description("Averiguar cuando la maestra está sola.")]
	BuggsFindOutWhenAlone,
	[Description("Avisar a Buggs cuando la maestra este sola.")]
	BuggsTellWhenAlone,
	[Description("Hablar con Buggs en el almuerzo.")]
	BuggsTalkAtLunch,
	[Description("Hablar con otros niños para averiguar si están metidos en el chisme.")]
	BuggsFindOutGoldStars,
	[Description("Ver si Monty tiene algún tipo de distracción .")]
	BuggsCheckForDistraction,
	[Description("Decir a Buggs que tienes un dispositivo de distracción.")]
	BuggsTellGotDistraction,
	[Description("Colocar el dispositivo de distracción debajo de una de las mesas delanteras.")]
	BuggsPlaceDevice,
	[Description("Usar el pase de almuerzo para almorzar con la maestra.")]
	BuggsGoToLunchWithTeacher,
	[Description("Matar a la maestra.")]
	BuggsKillTeacher,
	[Description("Hablar con Buggs en el recreo para decidir que hacer con el cuchillo.")]
	BuggsDisposeOfKnife,
	[Description("Convencer a Nugget  que te deje ocultar el cuchillo en la Cueva de Nugget.")]
	BuggsConvinceHide,
	[Description("Pegar el chicle que te dio Cindy en el cabello de Lily en la mañana. ")]
	CindyPutGumInHair,
	[Description("Decir a Cindy que pegaste el chicle en el cabello de Lily.")]
	CindyTalkMorningTime,
	[Description("Ir al baño para limpiarte.")]
	CindyWashUp,
	[Description("Jugar a la casita con Cindy.")]
	CindyPlayHouse,
	[Description("Almorzar con Cindy.")]
	CindyEatLunch,
	[Description("Encontrar comida 'vegetariana' para Cindy.")]
	CindyFindVegan,
	[Description("Ir al armario del conserje.")]
	CindyGoToCloset,
	[Description("Buscar algo asqueroso en el armario del conserje.")]
	CindyFindSomethingGross,
	[Description("Regresar a la cafetería.")]
	CindyGoBackToCafeteria,
	[Description("Mostrar a Cindy el cubo de sangre.")]
	CindyShowBucket,
	[Description("Arrojar el cubo sobre Lily.")]
	CindyDumpBucket,
	[Description("Mostrar a Cindy el pedazo de papel.")]
	CindyShowPaper,
	[Description("Encontrar a alguien quien pueda leer el papelito.")]
	CindyReadPaper,
	[Description("Hablar con Cindy sobre la receta.")]
	CindyTellPaper,
	[Description("Hablar con Cindy sobre el perro.")]
	CindyTellAboutDog,
	[Description("Pegar el chicle en el cabello de Lily durante el almuerzo.")]
	CindyPutGumLunch,
	[Description("Decir a Cindy que pegaste el chicle en el cabello de Lily.")]
	CindyTellPutGumLunch,
	[Description("Mostrar a Lily la nota que Nugget te dio antes de las clases de la mañana.")]
	LilyShowNote,
	[Description("Encontrar a alguien que puede leer la nota.")]
	LilyReadNote,
	[Description("Decir a Lily antes de que empiece la clase de la mañana que Monty está descifrando la nota.")]
	LilyTellNote,
	[Description("Llevar la nota descifrada por Monty al almuerzo.")]
	LilyGetNoteFromMonty,
	[Description("Mostrar la nota descifrada a Lily en el almuerzo.")]
	LilyShowCode,
	[Description("Mandar a Lily sola a la oficina del director.")]
	LilyGetSentToOffice,
	[Description("Encontrar en la oficina del director, la escotilla mencionada en la nota")]
	LilyLookForSomethingSuspicious,
	[Description("Contar a Lily sobre la escotilla en las clases de la mañana.")]
	LilyTellAboutTheHatch,
	[Description("Encontrar la manera de sacar al director de su oficina.")]
	LilyFindWayToLure,
	[Description("Encontrar la manera de obtener la llave de la oficina del director. ")]
	LilyFindWayToGetKey,
	[Description("Hablar con Lily en el almuerzo.")]
	LilyTalkAtLunch,
	[Description("Encontrarse con Lily en el baño.")]
	LilyMeetInBathroom,
	[Description("Llamar desde el baño al director.")]
	LilyCallInThreat,
	[Description("Usar la llave para entrar a la oficina del director.")]
	LilyUseKey,
	[Description("Encontrar el modo de abrir la escotilla.")]
	LilyOpenHatch,
	[Description("Encontrar en el baño evidencia de la desaparición de Billy.")]
	LilyFindEvidence,
	[Description("Mostrar a Lily la evidencia de la desaparición de Billy.")]
	LilyShowEvidence,
	[Description("Salvar a Billy.")]
	LilySaveBilly,
	[Description("Recoger los cinco nuggets de la amistad.")]
	NuggetCollectNuggets,
	[Description("Hablar con Nugget en la clase de la mañana.")]
	NuggetStartCollectNuggets,
	[Description("Coger el nugget de la amistad del casillero de Nugget.")]
	NuggetGetCubbyNugget,
	[Description("Preguntar a Nugget como encontrar el siguiente nugget de la amistad.")]
	NuggetStartThirdNugget,
	[Description("Entregar a Lily la carta de amor de Nugget.")]
	NuggetGiveLoveLetter,
	[Description("Decir a Nugget que entregaste la carta.")]
	NuggetDeliveredLetter,
	[Description("Hablar con Nugget en el almuerzo sobre como obtener el próximo nugget.")]
	NuggetTalkAtLunch,
	[Description("Matar a Buggs en el almuerzo.")]
	NuggetKillBuggs,
	[Description("Hacer que Buggs se coma el nugget envenenado.")]
	NuggetPoisonBuggs,
	[Description("Recibir al antídoto de Nugget.")]
	NuggetGetAntidote,
	[Description("Contar a Nugget que apuñalaste a Buggs.")]
	NuggetTellStabbedBuggs,
	[Description("Contar a Nugget que envenenaste a Buggs.")]
	NuggetTellPoisonedBuggs,
	[Description("Hablar con Nugget en el recreo sobre el último nugget de la amistad.")]
	NuggetTalkAtRecess,
	[Description("Colocar el dispositivo en la estatua.")]
	NuggetPlaceDevice,
	[Description("Hablar con Lily sobre la desaparición de Billy para detonar el dispositivo.")]
	NuggetTalkToLily,
	[Description("Encontrar el último nugget de la amistad para entrar en la Cueva de Nugget.")]
	NuggetGetLastNugget,
	[Description("Hablar con Nugget en el almuerzo.")]
	NuggetJoinAtLunch,
	[Description("Conseguir la lupa de Nugget.")]
	NuggetGetMagnifyingGlass,
	[Description("Pedir a Monty que haga una llave usando el molde que Jerome te dio.")]
	MontyAskFormold,
	[Description("Consigue $20 para comprar la llave a Monty en la tarde.")]
	MontyCollectTwenty,
	[Description("Decirle al conserje que él deletreó mal la palabra 'galleta'.")]
	MontyCorrectSpelling,
	[Description("Decir a la maestra que Buggs te amenazó.")]
	TeacherTellOnBuggs,
	[Description("Pelear con Buggs.")]
	TeacherStartFightWithBuggs,
	[Description("Hablar con la maestra sobre Jerome en las clases de la mañana.")]
	TeacherTalkMorningTimeJerome,
	[Description("Tratar de obtener el permiso robado de Jerome.")]
	TeacherTryToGetPass,
	[Description("Encontrar algo para darle a Jerome.")]
	TeacherFindJeromeGift,
	[Description("Entregar el permiso a la maestra.")]
	TeacherGivePass,
	[Description("Ganar la confianza de Nugget antes del  recreo.")]
	TeacherNuggetGainTrust,
	[Description("Decir a la maestra que te has ganado la confianza de Nugget.")]
	TeacherTellGainedTrust,
	[Description("Entrar a la Cueva de Nugget.")]
	TeacherEnterNuggetCave,
	[Description("Recolectar pruebas de la mala conducta de Nuggets.")]
	TeacherCollectEvidence,
	[Description("Mostrar a la maestra los restos del perro.")]
	TeacherShowEvidence,
	[Description("Meter a Lily en problemas.")]
	TeacherGetLilyInTrouble,
	[Description("Contarle a la maestra lo que pasó a Lily.")]
	TeacherCollectLilyStar,
	[Description("Meter a Monty en problemas.")]
	TeacherGetMontyInTrouble,
	[Description("Contarle a la maestra lo que pasó con Monty.")]
	TeacherCollectMontyStar,
	[Description("Volver a meter en problemas a Buggs.")]
	TeacherGetBuggsInTrouble,
	[Description("Contarle a la maestra  que apuñalaste a Buggs.")]
	TeacherTellStabbedBuggs,
	[Description("Contarle a la maestra que envenenaste a Buggs.")]
	TeacherTellPoisonedBuggs
}
