using Steamworks;
using UnityEngine;

public class SteamScript : MonoBehaviour
{
	public static void UnlockAchievement(string x)
	{
		if (SteamManager.Initialized)
		{
			SteamUserStats.GetAchievement(x, out var pbAchieved);
			if (!pbAchieved)
			{
				SteamUserStats.SetAchievement(x);
				SteamUserStats.StoreStats();
			}
		}
	}

	public static void SetAchievementProgress(string a, int currentAmount, int max)
	{
		if (SteamManager.Initialized && !SteamUserStats.GetAchievement(a, out var _))
		{
			if (SteamUserStats.IndicateAchievementProgress(a, (uint)currentAmount, (uint)max))
			{
				SteamUserStats.StoreStats();
			}
			if (currentAmount == max)
			{
				UnlockAchievement(a);
			}
		}
	}
}
