using System;
using System.Collections.Generic;
using System.IO;
using UnityEngine;

namespace Spine.Unity;

public class AtlasAsset : ScriptableObject
{
	public TextAsset atlasFile;

	public Material[] materials;

	protected Atlas atlas;

	public bool IsLoaded => atlas != null;

	public static AtlasAsset CreateRuntimeInstance(TextAsset atlasText, Material[] materials, bool initialize)
	{
		AtlasAsset atlasAsset = ScriptableObject.CreateInstance<AtlasAsset>();
		atlasAsset.Reset();
		atlasAsset.atlasFile = atlasText;
		atlasAsset.materials = materials;
		if (initialize)
		{
			atlasAsset.GetAtlas();
		}
		return atlasAsset;
	}

	public static AtlasAsset CreateRuntimeInstance(TextAsset atlasText, Texture2D[] textures, Shader shader, bool initialize)
	{
		//IL_00c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Expected O, but got Unknown
		if ((Object)(object)shader == (Object)null)
		{
			shader = Shader.Find("Spine/Skeleton");
		}
		string[] array = atlasText.text.Replace("\r", string.Empty).Split(new char[1] { '\n' });
		List<string> list = new List<string>();
		for (int i = 0; i < array.Length - 1; i++)
		{
			if (array[i].Trim().Length == 0)
			{
				list.Add(array[i + 1].Trim().Replace(".png", string.Empty));
			}
		}
		Material[] array2 = (Material[])(object)new Material[list.Count];
		int j = 0;
		for (int count = list.Count; j < count; j++)
		{
			Material val = null;
			string a = list[j];
			int k = 0;
			for (int num = textures.Length; k < num; k++)
			{
				if (string.Equals(a, ((Object)textures[k]).name, StringComparison.OrdinalIgnoreCase))
				{
					val = new Material(shader);
					val.mainTexture = (Texture)(object)textures[k];
					break;
				}
			}
			if ((Object)(object)val != (Object)null)
			{
				array2[j] = val;
				continue;
			}
			throw new ArgumentException("Could not find matching atlas page in the texture array.");
		}
		return CreateRuntimeInstance(atlasText, array2, initialize);
	}

	private void Reset()
	{
		Clear();
	}

	public virtual void Clear()
	{
		atlas = null;
	}

	public virtual Atlas GetAtlas()
	{
		if ((Object)(object)atlasFile == (Object)null)
		{
			Debug.LogError((object)("Atlas file not set for atlas asset: " + ((Object)this).name), (Object)(object)this);
			Clear();
			return null;
		}
		if (materials == null || materials.Length == 0)
		{
			Debug.LogError((object)("Materials not set for atlas asset: " + ((Object)this).name), (Object)(object)this);
			Clear();
			return null;
		}
		if (atlas != null)
		{
			return atlas;
		}
		try
		{
			atlas = new Atlas(new StringReader(atlasFile.text), string.Empty, new MaterialsTextureLoader(this));
			atlas.FlipV();
			return atlas;
		}
		catch (Exception ex)
		{
			Debug.LogError((object)("Error reading atlas file for atlas asset: " + ((Object)this).name + "\n" + ex.Message + "\n" + ex.StackTrace), (Object)(object)this);
			return null;
		}
	}

	public Mesh GenerateMesh(string name, Mesh mesh, out Material material, float scale = 0.01f)
	{
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_005b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0067: Unknown result type (might be due to invalid IL or missing references)
		//IL_006c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fa: Unknown result type (might be due to invalid IL or missing references)
		//IL_0101: Unknown result type (might be due to invalid IL or missing references)
		//IL_0106: Unknown result type (might be due to invalid IL or missing references)
		//IL_0116: Unknown result type (might be due to invalid IL or missing references)
		//IL_011d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0122: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Expected O, but got Unknown
		//IL_0197: Unknown result type (might be due to invalid IL or missing references)
		//IL_019c: Unknown result type (might be due to invalid IL or missing references)
		//IL_01a7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c7: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0155: Unknown result type (might be due to invalid IL or missing references)
		//IL_015a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0165: Unknown result type (might be due to invalid IL or missing references)
		//IL_016a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0175: Unknown result type (might be due to invalid IL or missing references)
		//IL_017a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0185: Unknown result type (might be due to invalid IL or missing references)
		//IL_018a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0212: Unknown result type (might be due to invalid IL or missing references)
		//IL_0218: Expected O, but got Unknown
		AtlasRegion atlasRegion = atlas.FindRegion(name);
		material = null;
		if (atlasRegion != null)
		{
			if ((Object)(object)mesh == (Object)null)
			{
				mesh = new Mesh();
				((Object)mesh).name = name;
			}
			Vector3[] array = (Vector3[])(object)new Vector3[4];
			Vector2[] array2 = (Vector2[])(object)new Vector2[4];
			Color[] colors = (Color[])(object)new Color[4]
			{
				Color.white,
				Color.white,
				Color.white,
				Color.white
			};
			int[] triangles = new int[6] { 0, 1, 2, 2, 3, 0 };
			float num = (float)atlasRegion.width / -2f;
			float num2 = num * -1f;
			float num3 = (float)atlasRegion.height / 2f;
			float num4 = num3 * -1f;
			array[0] = new Vector3(num, num4, 0f) * scale;
			array[1] = new Vector3(num, num3, 0f) * scale;
			array[2] = new Vector3(num2, num3, 0f) * scale;
			array[3] = new Vector3(num2, num4, 0f) * scale;
			float u = atlasRegion.u;
			float v = atlasRegion.v;
			float u2 = atlasRegion.u2;
			float v2 = atlasRegion.v2;
			if (!atlasRegion.rotate)
			{
				array2[0] = new Vector2(u, v2);
				array2[1] = new Vector2(u, v);
				array2[2] = new Vector2(u2, v);
				array2[3] = new Vector2(u2, v2);
			}
			else
			{
				array2[0] = new Vector2(u2, v2);
				array2[1] = new Vector2(u, v2);
				array2[2] = new Vector2(u, v);
				array2[3] = new Vector2(u2, v);
			}
			mesh.triangles = new int[0];
			mesh.vertices = array;
			mesh.uv = array2;
			mesh.colors = colors;
			mesh.triangles = triangles;
			mesh.RecalculateNormals();
			mesh.RecalculateBounds();
			material = (Material)atlasRegion.page.rendererObject;
		}
		else
		{
			mesh = null;
		}
		return mesh;
	}
}
