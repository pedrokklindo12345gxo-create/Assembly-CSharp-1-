using TouchControlsKit;
using UnityEngine;

namespace Examples;

public class FirstPersonExample : MonoBehaviour
{
	public enum AxesInputType
	{
		GetAxis,
		BindAxes,
		Broadcasting
	}

	public enum GetAxesMethod
	{
		GetByName,
		GetByType
	}

	public AxesInputType axesInputType;

	private bool binded;

	public GetAxesMethod axesGetType;

	private Transform myTransform;

	private Transform cameraTransform;

	private CharacterController controller;

	private float rotation;

	private Vector3 moveDirection = Vector3.zero;

	private bool jump;

	private bool grounded;

	private bool prevGrounded;

	private float weapReadyTime;

	private bool weapReady = true;

	private void Awake()
	{
		myTransform = ((Component)this).transform;
		cameraTransform = ((Component)Camera.main).transform;
		controller = ((Component)this).GetComponent<CharacterController>();
		TCKInput.BindAction("jumpBtn", Jumping, ActionPhase.Down);
	}

	private void Update()
	{
		if (!weapReady)
		{
			weapReadyTime += Time.deltaTime;
			if (weapReadyTime > 0.15f)
			{
				weapReady = true;
				weapReadyTime = 0f;
			}
		}
	}

	private void FixedUpdate()
	{
		if (axesInputType == AxesInputType.BindAxes && !binded)
		{
			TCKInput.BindAxes("Joystick", BindPlayerAxes);
			binded = true;
		}
		else if (axesInputType != AxesInputType.BindAxes && binded)
		{
			TCKInput.UnBindAxes("Joystick", BindPlayerAxes);
			binded = false;
		}
		else if (axesInputType == AxesInputType.GetAxis)
		{
			if (axesGetType == GetAxesMethod.GetByName)
			{
				float axis = TCKInput.GetAxis("Joystick", "Horizontal");
				float axis2 = TCKInput.GetAxis("Joystick", "Vertical");
				PlayerMovement(axis, axis2);
			}
			else
			{
				float axis3 = TCKInput.GetAxis("Joystick", AxisType.X);
				float axis4 = TCKInput.GetAxis("Joystick", AxisType.Y);
				PlayerMovement(axis3, axis4);
			}
		}
	}

	private void Jumping()
	{
		if (grounded)
		{
			jump = true;
		}
	}

	private void BindPlayerAxes(float x, float y, TCKTouchPhase tPhase)
	{
		PlayerMovement(x, y);
	}

	public void GetPlayerAxes(float x, float y, TCKTouchPhase tPhase)
	{
		if (axesInputType == AxesInputType.Broadcasting)
		{
			PlayerMovement(x, y);
		}
	}

	private void PlayerMovement(float horizontal, float vertical)
	{
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0035: Unknown result type (might be due to invalid IL or missing references)
		//IL_003b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a0: Unknown result type (might be due to invalid IL or missing references)
		//IL_00aa: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00be: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0063: Unknown result type (might be due to invalid IL or missing references)
		//IL_00de: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e8: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		grounded = controller.isGrounded;
		moveDirection = myTransform.forward * vertical;
		moveDirection += myTransform.right * horizontal;
		if (grounded)
		{
			moveDirection *= 7f;
			moveDirection.y = -10f;
			if (jump)
			{
				jump = false;
				moveDirection.y = 5f;
			}
		}
		else
		{
			moveDirection += Physics.gravity * 2f * Time.fixedDeltaTime;
		}
		moveDirection.y *= 20f;
		controller.Move(moveDirection * Time.fixedDeltaTime);
		if (!prevGrounded && grounded)
		{
			moveDirection.y = 0f;
		}
		prevGrounded = grounded;
	}

	public void PlayerRotation(float horizontal, float vertical)
	{
		//IL_005e: Unknown result type (might be due to invalid IL or missing references)
		//IL_006d: Unknown result type (might be due to invalid IL or missing references)
		myTransform.Rotate(0f, horizontal * 12f, 0f);
		rotation += vertical * 12f;
		rotation = Mathf.Clamp(rotation, -60f, 60f);
		cameraTransform.localEulerAngles = new Vector3(0f - rotation, cameraTransform.localEulerAngles.y, 0f);
	}

	public void PlayerFiring()
	{
		//IL_0022: Unknown result type (might be due to invalid IL or missing references)
		//IL_002d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		//IL_007c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0082: Unknown result type (might be due to invalid IL or missing references)
		//IL_0096: Unknown result type (might be due to invalid IL or missing references)
		//IL_009b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ba: Unknown result type (might be due to invalid IL or missing references)
		if (weapReady)
		{
			weapReady = false;
			GameObject obj = GameObject.CreatePrimitive((PrimitiveType)0);
			obj.transform.position = myTransform.position + myTransform.right;
			obj.transform.localScale = Vector3.one * 0.15f;
			Rigidbody obj2 = obj.AddComponent<Rigidbody>();
			Transform transform = ((Component)Camera.main).transform;
			obj2.AddForce(transform.forward * Random.Range(25f, 35f) + transform.right * Random.Range(-2f, 2f) + transform.up * Random.Range(-2f, 2f), (ForceMode)1);
			Object.Destroy((Object)(object)obj, 3.5f);
		}
	}

	public void PlayerClicked()
	{
	}
}
