using System;
using System.Collections.Generic;
using UnityEngine;

namespace Spine.Unity.Modules.AttachmentTools;

public static class SpriteAtlasRegionExtensions
{
	internal const TextureFormat SpineTextureFormat = (TextureFormat)4;

	internal const bool UseMipMaps = false;

	internal const float DefaultScale = 0.01f;

	public static AtlasRegion ToAtlasRegion(this Texture2D t, Material materialPropertySource, float scale = 0.01f)
	{
		return t.ToAtlasRegion(materialPropertySource.shader, scale, materialPropertySource);
	}

	public static AtlasRegion ToAtlasRegion(this Texture2D t, Shader shader, float scale = 0.01f, Material materialPropertySource = null)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Expected O, but got Unknown
		//IL_0060: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_0069: Unknown result type (might be due to invalid IL or missing references)
		//IL_006f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0074: Unknown result type (might be due to invalid IL or missing references)
		//IL_009d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ca: Unknown result type (might be due to invalid IL or missing references)
		Material val = new Material(shader);
		if ((Object)(object)materialPropertySource != (Object)null)
		{
			val.CopyPropertiesFromMaterial(materialPropertySource);
			val.shaderKeywords = materialPropertySource.shaderKeywords;
		}
		val.mainTexture = (Texture)(object)t;
		AtlasPage page = val.ToSpineAtlasPage();
		float num = ((Texture)t).width;
		float num2 = ((Texture)t).height;
		AtlasRegion obj = new AtlasRegion
		{
			name = ((Object)t).name,
			index = -1,
			rotate = false
		};
		Vector2 zero = Vector2.zero;
		Vector2 val2 = new Vector2(num, num2) * scale;
		obj.width = (int)num;
		obj.originalWidth = (int)num;
		obj.height = (int)num2;
		obj.originalHeight = (int)num2;
		obj.offsetX = num * (0.5f - InverseLerp(zero.x, val2.x, 0f));
		obj.offsetY = num2 * (0.5f - InverseLerp(zero.y, val2.y, 0f));
		obj.u = 0f;
		obj.v = 1f;
		obj.u2 = 1f;
		obj.v2 = 0f;
		obj.x = 0;
		obj.y = 0;
		obj.page = page;
		return obj;
	}

	public static AtlasRegion ToAtlasRegionPMAClone(this Texture2D t, Material materialPropertySource, TextureFormat textureFormat = (TextureFormat)4, bool mipmaps = false)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		return t.ToAtlasRegionPMAClone(materialPropertySource.shader, textureFormat, mipmaps, materialPropertySource);
	}

	public static AtlasRegion ToAtlasRegionPMAClone(this Texture2D t, Shader shader, TextureFormat textureFormat = (TextureFormat)4, bool mipmaps = false, Material materialPropertySource = null)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Expected O, but got Unknown
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		Material val = new Material(shader);
		if ((Object)(object)materialPropertySource != (Object)null)
		{
			val.CopyPropertiesFromMaterial(materialPropertySource);
			val.shaderKeywords = materialPropertySource.shaderKeywords;
		}
		Texture2D clone = t.GetClone(applyImmediately: false, textureFormat, mipmaps);
		clone.ApplyPMA();
		((Object)clone).name = ((Object)t).name + "-pma-";
		((Object)val).name = ((Object)t).name + ((Object)shader).name;
		val.mainTexture = (Texture)(object)clone;
		AtlasPage page = val.ToSpineAtlasPage();
		AtlasRegion atlasRegion = clone.ToAtlasRegion(shader);
		atlasRegion.page = page;
		return atlasRegion;
	}

	public static AtlasPage ToSpineAtlasPage(this Material m)
	{
		AtlasPage atlasPage = new AtlasPage
		{
			rendererObject = m,
			name = ((Object)m).name
		};
		Texture mainTexture = m.mainTexture;
		if ((Object)(object)mainTexture != (Object)null)
		{
			atlasPage.width = mainTexture.width;
			atlasPage.height = mainTexture.height;
		}
		return atlasPage;
	}

	public static AtlasRegion ToAtlasRegion(this Sprite s, AtlasPage page)
	{
		if (page == null)
		{
			throw new ArgumentNullException("page", "page cannot be null. AtlasPage determines which texture region belongs and how it should be rendered. You can use material.ToSpineAtlasPage() to get a shareable AtlasPage from a Material, or use the sprite.ToAtlasRegion(material) overload.");
		}
		AtlasRegion atlasRegion = s.ToAtlasRegion();
		atlasRegion.page = page;
		return atlasRegion;
	}

	public static AtlasRegion ToAtlasRegion(this Sprite s, Material material)
	{
		AtlasRegion atlasRegion = s.ToAtlasRegion();
		atlasRegion.page = material.ToSpineAtlasPage();
		return atlasRegion;
	}

	public static AtlasRegion ToAtlasRegionPMAClone(this Sprite s, Shader shader, TextureFormat textureFormat = (TextureFormat)4, bool mipmaps = false, Material materialPropertySource = null)
	{
		//IL_0001: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Expected O, but got Unknown
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		Material val = new Material(shader);
		if ((Object)(object)materialPropertySource != (Object)null)
		{
			val.CopyPropertiesFromMaterial(materialPropertySource);
			val.shaderKeywords = materialPropertySource.shaderKeywords;
		}
		Texture2D val2 = s.ToTexture(applyImmediately: false, textureFormat, mipmaps);
		val2.ApplyPMA();
		((Object)val2).name = ((Object)s).name + "-pma-";
		((Object)val).name = ((Object)val2).name + ((Object)shader).name;
		val.mainTexture = (Texture)(object)val2;
		AtlasPage page = val.ToSpineAtlasPage();
		AtlasRegion atlasRegion = s.ToAtlasRegion(isolatedTexture: true);
		atlasRegion.page = page;
		return atlasRegion;
	}

	public static AtlasRegion ToAtlasRegionPMAClone(this Sprite s, Material materialPropertySource, TextureFormat textureFormat = (TextureFormat)4, bool mipmaps = false)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		return s.ToAtlasRegionPMAClone(materialPropertySource.shader, textureFormat, mipmaps, materialPropertySource);
	}

	internal static AtlasRegion ToAtlasRegion(this Sprite s, bool isolatedTexture = false)
	{
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Invalid comparison between Unknown and I4
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0041: Unknown result type (might be due to invalid IL or missing references)
		//IL_0046: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_004e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		//IL_0055: Unknown result type (might be due to invalid IL or missing references)
		//IL_0065: Unknown result type (might be due to invalid IL or missing references)
		//IL_006a: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_00db: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		//IL_0158: Unknown result type (might be due to invalid IL or missing references)
		AtlasRegion atlasRegion = new AtlasRegion();
		atlasRegion.name = ((Object)s).name;
		atlasRegion.index = -1;
		atlasRegion.rotate = s.packed && (int)s.packingRotation > 0;
		Bounds bounds = s.bounds;
		Vector2 val = Vector2.op_Implicit(((Bounds)(ref bounds)).min);
		Vector2 val2 = Vector2.op_Implicit(((Bounds)(ref bounds)).max);
		Rect val3 = s.rect.SpineUnityFlipRect(((Texture)s.texture).height);
		atlasRegion.width = (int)((Rect)(ref val3)).width;
		atlasRegion.originalWidth = (int)((Rect)(ref val3)).width;
		atlasRegion.height = (int)((Rect)(ref val3)).height;
		atlasRegion.originalHeight = (int)((Rect)(ref val3)).height;
		atlasRegion.offsetX = ((Rect)(ref val3)).width * (0.5f - InverseLerp(val.x, val2.x, 0f));
		atlasRegion.offsetY = ((Rect)(ref val3)).height * (0.5f - InverseLerp(val.y, val2.y, 0f));
		if (isolatedTexture)
		{
			atlasRegion.u = 0f;
			atlasRegion.v = 1f;
			atlasRegion.u2 = 1f;
			atlasRegion.v2 = 0f;
			atlasRegion.x = 0;
			atlasRegion.y = 0;
		}
		else
		{
			Texture2D texture = s.texture;
			Rect val4 = TextureRectToUVRect(s.textureRect, ((Texture)texture).width, ((Texture)texture).height);
			atlasRegion.u = ((Rect)(ref val4)).xMin;
			atlasRegion.v = ((Rect)(ref val4)).yMax;
			atlasRegion.u2 = ((Rect)(ref val4)).xMax;
			atlasRegion.v2 = ((Rect)(ref val4)).yMin;
			atlasRegion.x = (int)((Rect)(ref val3)).x;
			atlasRegion.y = (int)((Rect)(ref val3)).y;
		}
		return atlasRegion;
	}

	public static Skin GetRepackedSkin(this Skin o, string newName, Material materialPropertySource, out Material m, out Texture2D t, int maxAtlasSize = 1024, int padding = 2, TextureFormat textureFormat = (TextureFormat)4, bool mipmaps = false)
	{
		//IL_000f: Unknown result type (might be due to invalid IL or missing references)
		return o.GetRepackedSkin(newName, materialPropertySource.shader, out m, out t, maxAtlasSize, padding, textureFormat, mipmaps, materialPropertySource);
	}

	public static Skin GetRepackedSkin(this Skin o, string newName, Shader shader, out Material m, out Texture2D t, int maxAtlasSize = 1024, int padding = 2, TextureFormat textureFormat = (TextureFormat)4, bool mipmaps = false, Material materialPropertySource = null)
	{
		//IL_00f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_0100: Expected O, but got Unknown
		//IL_0131: Unknown result type (might be due to invalid IL or missing references)
		//IL_0138: Expected O, but got Unknown
		//IL_019f: Unknown result type (might be due to invalid IL or missing references)
		Dictionary<Skin.AttachmentKeyTuple, Attachment> attachments = o.Attachments;
		Skin skin = new Skin(newName);
		Dictionary<AtlasRegion, int> dictionary = new Dictionary<AtlasRegion, int>();
		List<int> list = new List<int>();
		List<Attachment> list2 = new List<Attachment>();
		List<Texture2D> list3 = new List<Texture2D>();
		List<AtlasRegion> list4 = new List<AtlasRegion>();
		int num = 0;
		foreach (KeyValuePair<Skin.AttachmentKeyTuple, Attachment> item2 in attachments)
		{
			Attachment clone = item2.Value.GetClone(cloneMeshesAsLinked: true);
			if (IsRenderable(clone))
			{
				AtlasRegion atlasRegion = clone.GetAtlasRegion();
				if (dictionary.TryGetValue(atlasRegion, out var value))
				{
					list.Add(value);
				}
				else
				{
					list4.Add(atlasRegion);
					list3.Add(atlasRegion.ToTexture(applyImmediately: true, (TextureFormat)4));
					dictionary.Add(atlasRegion, num);
					list.Add(num);
					num++;
				}
				list2.Add(clone);
			}
			Skin.AttachmentKeyTuple key = item2.Key;
			skin.AddAttachment(key.slotIndex, key.name, clone);
		}
		Texture2D val = new Texture2D(maxAtlasSize, maxAtlasSize, textureFormat, mipmaps);
		((Texture)val).anisoLevel = ((Texture)list3[0]).anisoLevel;
		((Object)val).name = newName;
		Rect[] array = val.PackTextures(list3.ToArray(), padding, maxAtlasSize);
		Material val2 = new Material(shader);
		if ((Object)(object)materialPropertySource != (Object)null)
		{
			val2.CopyPropertiesFromMaterial(materialPropertySource);
			val2.shaderKeywords = materialPropertySource.shaderKeywords;
		}
		((Object)val2).name = newName;
		val2.mainTexture = (Texture)(object)val;
		AtlasPage atlasPage = val2.ToSpineAtlasPage();
		atlasPage.name = newName;
		List<AtlasRegion> list5 = new List<AtlasRegion>();
		int i = 0;
		for (int count = list4.Count; i < count; i++)
		{
			AtlasRegion atlasRegion2 = list4[i];
			AtlasRegion item = UVRectToAtlasRegion(array[i], atlasRegion2.name, atlasPage, atlasRegion2.offsetX, atlasRegion2.offsetY, atlasRegion2.rotate);
			list5.Add(item);
		}
		int j = 0;
		for (int count2 = list2.Count; j < count2; j++)
		{
			list2[j].SetRegion(list5[list[j]]);
		}
		foreach (Texture2D item3 in list3)
		{
			Object.Destroy((Object)(object)item3);
		}
		t = val;
		m = val2;
		return skin;
	}

	public static Sprite ToSprite(this AtlasRegion ar, float pixelsPerUnit = 100f)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		return Sprite.Create(ar.GetMainTexture(), ar.GetUnityRect(), new Vector2(0.5f, 0.5f), pixelsPerUnit);
	}

	public static Texture2D ToTexture(this AtlasRegion ar, bool applyImmediately = true, TextureFormat textureFormat = (TextureFormat)4, bool mipmaps = false)
	{
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0028: Unknown result type (might be due to invalid IL or missing references)
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Expected O, but got Unknown
		Texture2D mainTexture = ar.GetMainTexture();
		Rect unityRect = ar.GetUnityRect(((Texture)mainTexture).height);
		int num = (int)((Rect)(ref unityRect)).width;
		int num2 = (int)((Rect)(ref unityRect)).height;
		Texture2D val = new Texture2D(num, num2, textureFormat, mipmaps);
		((Object)val).name = ar.name;
		Color[] pixels = mainTexture.GetPixels((int)((Rect)(ref unityRect)).x, (int)((Rect)(ref unityRect)).y, num, num2);
		val.SetPixels(pixels);
		if (applyImmediately)
		{
			val.Apply();
		}
		return val;
	}

	private static Texture2D ToTexture(this Sprite s, bool applyImmediately = true, TextureFormat textureFormat = (TextureFormat)4, bool mipmaps = false)
	{
		//IL_0007: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0043: Unknown result type (might be due to invalid IL or missing references)
		//IL_0045: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Expected O, but got Unknown
		Texture2D texture = s.texture;
		Rect textureRect = s.textureRect;
		Color[] pixels = texture.GetPixels((int)((Rect)(ref textureRect)).x, (int)((Rect)(ref textureRect)).y, (int)((Rect)(ref textureRect)).width, (int)((Rect)(ref textureRect)).height);
		Texture2D val = new Texture2D((int)((Rect)(ref textureRect)).width, (int)((Rect)(ref textureRect)).height, textureFormat, mipmaps);
		val.SetPixels(pixels);
		if (applyImmediately)
		{
			val.Apply();
		}
		return val;
	}

	private static Texture2D GetClone(this Texture2D t, bool applyImmediately = true, TextureFormat textureFormat = (TextureFormat)4, bool mipmaps = false)
	{
		//IL_0021: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0029: Expected O, but got Unknown
		Color[] pixels = t.GetPixels(0, 0, ((Texture)t).width, ((Texture)t).height);
		Texture2D val = new Texture2D(((Texture)t).width, ((Texture)t).height, textureFormat, mipmaps);
		val.SetPixels(pixels);
		if (applyImmediately)
		{
			val.Apply();
		}
		return val;
	}

	private static bool IsRenderable(Attachment a)
	{
		if (!(a is RegionAttachment))
		{
			return a is MeshAttachment;
		}
		return true;
	}

	private static Rect SpineUnityFlipRect(this Rect rect, int textureHeight)
	{
		//IL_0019: Unknown result type (might be due to invalid IL or missing references)
		((Rect)(ref rect)).y = (float)textureHeight - ((Rect)(ref rect)).y - ((Rect)(ref rect)).height;
		return rect;
	}

	private static Rect GetUnityRect(this AtlasRegion region)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0012: Unknown result type (might be due to invalid IL or missing references)
		return region.GetSpineAtlasRect().SpineUnityFlipRect(region.page.height);
	}

	private static Rect GetUnityRect(this AtlasRegion region, int textureHeight)
	{
		//IL_0002: Unknown result type (might be due to invalid IL or missing references)
		//IL_0008: Unknown result type (might be due to invalid IL or missing references)
		return region.GetSpineAtlasRect().SpineUnityFlipRect(textureHeight);
	}

	private static Rect GetSpineAtlasRect(this AtlasRegion region, bool includeRotate = true)
	{
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_0027: Unknown result type (might be due to invalid IL or missing references)
		if (includeRotate && region.rotate)
		{
			return new Rect((float)region.x, (float)region.y, (float)region.height, (float)region.width);
		}
		return new Rect((float)region.x, (float)region.y, (float)region.width, (float)region.height);
	}

	private static Rect UVRectToTextureRect(Rect uvRect, int texWidth, int texHeight)
	{
		//IL_0040: Unknown result type (might be due to invalid IL or missing references)
		((Rect)(ref uvRect)).x = ((Rect)(ref uvRect)).x * (float)texWidth;
		((Rect)(ref uvRect)).width = ((Rect)(ref uvRect)).width * (float)texWidth;
		((Rect)(ref uvRect)).y = ((Rect)(ref uvRect)).y * (float)texHeight;
		((Rect)(ref uvRect)).height = ((Rect)(ref uvRect)).height * (float)texHeight;
		return uvRect;
	}

	private static Rect TextureRectToUVRect(Rect textureRect, int texWidth, int texHeight)
	{
		//IL_0068: Unknown result type (might be due to invalid IL or missing references)
		((Rect)(ref textureRect)).x = Mathf.InverseLerp(0f, (float)texWidth, ((Rect)(ref textureRect)).x);
		((Rect)(ref textureRect)).y = Mathf.InverseLerp(0f, (float)texHeight, ((Rect)(ref textureRect)).y);
		((Rect)(ref textureRect)).width = Mathf.InverseLerp(0f, (float)texWidth, ((Rect)(ref textureRect)).width);
		((Rect)(ref textureRect)).height = Mathf.InverseLerp(0f, (float)texHeight, ((Rect)(ref textureRect)).height);
		return textureRect;
	}

	private static AtlasRegion UVRectToAtlasRegion(Rect uvRect, string name, AtlasPage page, float offsetX, float offsetY, bool rotate)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001d: Unknown result type (might be due to invalid IL or missing references)
		Rect val = UVRectToTextureRect(uvRect, page.width, page.height).SpineUnityFlipRect(page.height);
		int x = (int)((Rect)(ref val)).x;
		int y = (int)((Rect)(ref val)).y;
		int num;
		int num2;
		if (rotate)
		{
			num = (int)((Rect)(ref val)).height;
			num2 = (int)((Rect)(ref val)).width;
		}
		else
		{
			num = (int)((Rect)(ref val)).width;
			num2 = (int)((Rect)(ref val)).height;
		}
		return new AtlasRegion
		{
			page = page,
			name = name,
			u = ((Rect)(ref uvRect)).xMin,
			u2 = ((Rect)(ref uvRect)).xMax,
			v = ((Rect)(ref uvRect)).yMax,
			v2 = ((Rect)(ref uvRect)).yMin,
			index = -1,
			width = num,
			originalWidth = num,
			height = num2,
			originalHeight = num2,
			offsetX = offsetX,
			offsetY = offsetY,
			x = x,
			y = y,
			rotate = rotate
		};
	}

	private static AtlasRegion GetAtlasRegion(this Attachment a)
	{
		if (a is RegionAttachment regionAttachment)
		{
			return regionAttachment.RendererObject as AtlasRegion;
		}
		if (a is MeshAttachment meshAttachment)
		{
			return meshAttachment.RendererObject as AtlasRegion;
		}
		return null;
	}

	private static Texture2D GetMainTexture(this AtlasRegion region)
	{
		object rendererObject = region.page.rendererObject;
		Texture mainTexture = ((Material)((rendererObject is Material) ? rendererObject : null)).mainTexture;
		return (Texture2D)(object)((mainTexture is Texture2D) ? mainTexture : null);
	}

	private static void ApplyPMA(this Texture2D texture, bool applyImmediately = true)
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_0017: Unknown result type (might be due to invalid IL or missing references)
		//IL_0048: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		Color[] pixels = texture.GetPixels();
		int i = 0;
		for (int num = pixels.Length; i < num; i++)
		{
			Color val = pixels[i];
			float a = val.a;
			val.r *= a;
			val.g *= a;
			val.b *= a;
			pixels[i] = val;
		}
		texture.SetPixels(pixels);
		if (applyImmediately)
		{
			texture.Apply();
		}
	}

	private static float InverseLerp(float a, float b, float value)
	{
		return (value - a) / (b - a);
	}
}
