using UnityEngine;
using UnityEngine.Events;
using UnityEngine.UI;

public class HSVPicker : MonoBehaviour
{
	public HexRGB hexrgb;

	public Color32 currentColor;

	private byte r;

	private byte g;

	private byte b;

	public Image colorImage;

	public RawImage hsvSlider;

	public RawImage hsvImage;

	public HsvSliderPicker sliderPicker;

	public BoxSlider boxSlider;

	public Slider sliderR;

	public Slider sliderG;

	public Slider sliderB;

	public Text sliderRText;

	public Text sliderGText;

	public Text sliderBText;

	public float pointerPos;

	public int minHue;

	public int maxHue = 360;

	public float minSat;

	public float maxSat = 1f;

	public float minV;

	public float maxV = 1f;

	public float cursorX;

	public float cursorY;

	public HSVSliderEvent onValueChanged = new HSVSliderEvent();

	private bool isChanging;

	private void Awake()
	{
		//IL_001e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0023: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003c: Unknown result type (might be due to invalid IL or missing references)
		//IL_018e: Unknown result type (might be due to invalid IL or missing references)
		//IL_00e6: Unknown result type (might be due to invalid IL or missing references)
		//IL_00eb: Unknown result type (might be due to invalid IL or missing references)
		//IL_012a: Unknown result type (might be due to invalid IL or missing references)
		//IL_012f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0143: Unknown result type (might be due to invalid IL or missing references)
		//IL_0148: Unknown result type (might be due to invalid IL or missing references)
		//IL_0151: Unknown result type (might be due to invalid IL or missing references)
		//IL_0104: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_0118: Unknown result type (might be due to invalid IL or missing references)
		Rect rect;
		if (Object.op_Implicit((Object)(object)hsvSlider))
		{
			RawImage obj = hsvSlider;
			rect = ((Graphic)hsvSlider).rectTransform.rect;
			int width = (int)((Rect)(ref rect)).width;
			rect = ((Graphic)hsvSlider).rectTransform.rect;
			obj.texture = (Texture)(object)HSVUtil.GenerateHSVTexture(width, (int)((Rect)(ref rect)).height, minHue, maxHue);
		}
		if (Object.op_Implicit((Object)(object)sliderR))
		{
			((UnityEvent<float>)(object)sliderR.onValueChanged).AddListener((UnityAction<float>)delegate(float newValue)
			{
				//IL_002a: Unknown result type (might be due to invalid IL or missing references)
				//IL_002f: Unknown result type (might be due to invalid IL or missing references)
				if (!isChanging)
				{
					isChanging = true;
					r = (byte)newValue;
					currentColor.r = r;
					AssignColor(Color32.op_Implicit(currentColor));
					sliderRText.text = "R:" + r;
					if ((Object)(object)hexrgb != (Object)null)
					{
						hexrgb.ManipulateViaRGB2Hex();
					}
					isChanging = false;
				}
			});
		}
		if (Object.op_Implicit((Object)(object)sliderG))
		{
			((UnityEvent<float>)(object)sliderG.onValueChanged).AddListener((UnityAction<float>)delegate(float newValue)
			{
				//IL_002a: Unknown result type (might be due to invalid IL or missing references)
				//IL_002f: Unknown result type (might be due to invalid IL or missing references)
				if (!isChanging)
				{
					isChanging = true;
					g = (byte)newValue;
					currentColor.g = g;
					AssignColor(Color32.op_Implicit(currentColor));
					sliderGText.text = "G:" + g;
					if ((Object)(object)hexrgb != (Object)null)
					{
						hexrgb.ManipulateViaRGB2Hex();
					}
					isChanging = false;
				}
			});
		}
		if (Object.op_Implicit((Object)(object)sliderB))
		{
			((UnityEvent<float>)(object)sliderB.onValueChanged).AddListener((UnityAction<float>)delegate(float newValue)
			{
				//IL_002a: Unknown result type (might be due to invalid IL or missing references)
				//IL_002f: Unknown result type (might be due to invalid IL or missing references)
				if (!isChanging)
				{
					isChanging = true;
					b = (byte)newValue;
					currentColor.b = b;
					AssignColor(Color32.op_Implicit(currentColor));
					sliderBText.text = "B:" + b;
					if ((Object)(object)hexrgb != (Object)null)
					{
						hexrgb.ManipulateViaRGB2Hex();
					}
					isChanging = false;
				}
			});
		}
		if (Object.op_Implicit((Object)(object)hsvImage))
		{
			Color mainColor = Color.white;
			if (Object.op_Implicit((Object)(object)hsvSlider))
			{
				mainColor = ((Texture2D)hsvSlider.texture).GetPixelBilinear(0f, 0.035f);
			}
			RawImage obj2 = hsvImage;
			rect = ((Graphic)hsvImage).rectTransform.rect;
			int width2 = (int)((Rect)(ref rect)).width;
			rect = ((Graphic)hsvImage).rectTransform.rect;
			obj2.texture = (Texture)(object)HSVUtil.GenerateColorTexture(width2, (int)((Rect)(ref rect)).width, mainColor, minHue, maxHue, minSat, maxSat, minV, maxV);
		}
		MoveCursor(cursorX, cursorY);
		sliderPicker.SetSliderPosition(1f - pointerPos);
	}

	public void AssignColor(Color color)
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0032: Unknown result type (might be due to invalid IL or missing references)
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_004b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0050: Unknown result type (might be due to invalid IL or missing references)
		//IL_0061: Unknown result type (might be due to invalid IL or missing references)
		//IL_0066: Unknown result type (might be due to invalid IL or missing references)
		HsvColor hsvColor = HSVUtil.ConvertRgbToHsv(color);
		float newPos = (float)(hsvColor.H / 360.0);
		MovePointer(newPos, updateInputs: false);
		MoveCursor((float)hsvColor.S, (float)hsvColor.V, updateInputs: false);
		currentColor = Color32.op_Implicit(color);
		((Graphic)colorImage).color = Color32.op_Implicit(currentColor);
		((UnityEvent<Color>)onValueChanged).Invoke(Color32.op_Implicit(currentColor));
	}

	public void PlaceCursor(float posX, float posY)
	{
		//IL_0004: Unknown result type (might be due to invalid IL or missing references)
		MoveCursor(posX, posY);
	}

	public Color MoveCursor(float posX, float posY, bool updateInputs = true)
	{
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ab: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b0: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		//IL_007a: Unknown result type (might be due to invalid IL or missing references)
		//IL_012d: Unknown result type (might be due to invalid IL or missing references)
		//IL_0132: Unknown result type (might be due to invalid IL or missing references)
		//IL_00fd: Unknown result type (might be due to invalid IL or missing references)
		//IL_0102: Unknown result type (might be due to invalid IL or missing references)
		if (posX > 1f)
		{
			posX %= 1f;
		}
		if (posY > 1f)
		{
			posY %= 1f;
		}
		posY = Mathf.Clamp(posY, 0f, 1f);
		posX = Mathf.Clamp(posX, 0f, 1f);
		cursorX = posX;
		cursorY = posY;
		boxSlider.normalizedValue = posX;
		boxSlider.normalizedValueY = posY;
		if (isChanging)
		{
			return Color32.op_Implicit(currentColor);
		}
		isChanging = true;
		currentColor = Color32.op_Implicit(GetColor(cursorX, cursorY));
		((Graphic)colorImage).color = Color32.op_Implicit(currentColor);
		r = currentColor.r;
		g = currentColor.g;
		b = currentColor.b;
		if (updateInputs)
		{
			UpdateInputs();
			((UnityEvent<Color>)onValueChanged).Invoke(Color32.op_Implicit(currentColor));
			if ((Object)(object)hexrgb != (Object)null)
			{
				hexrgb.ManipulateViaRGB2Hex();
			}
		}
		isChanging = false;
		return Color32.op_Implicit(currentColor);
	}

	public Color GetColor(float posX, float posY)
	{
		//IL_0052: Unknown result type (might be due to invalid IL or missing references)
		posY = Mathf.Clamp(posY, minV, maxV);
		posX = Mathf.Clamp(posX, minSat, maxSat);
		return HSVUtil.ConvertHsvToRgb(pointerPos * (float)(-(minHue + maxHue)) + (float)(minHue + maxHue), posX, posY);
	}

	public Color MovePointer(float newPos, bool updateInputs = true)
	{
		//IL_002a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003a: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0195: Unknown result type (might be due to invalid IL or missing references)
		//IL_019a: Unknown result type (might be due to invalid IL or missing references)
		//IL_01ae: Unknown result type (might be due to invalid IL or missing references)
		//IL_01b3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01bc: Unknown result type (might be due to invalid IL or missing references)
		//IL_0071: Unknown result type (might be due to invalid IL or missing references)
		//IL_0076: Unknown result type (might be due to invalid IL or missing references)
		//IL_0214: Unknown result type (might be due to invalid IL or missing references)
		//IL_0219: Unknown result type (might be due to invalid IL or missing references)
		//IL_021e: Unknown result type (might be due to invalid IL or missing references)
		//IL_022a: Unknown result type (might be due to invalid IL or missing references)
		//IL_022f: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f4: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f9: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_00f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0105: Unknown result type (might be due to invalid IL or missing references)
		//IL_010a: Unknown result type (might be due to invalid IL or missing references)
		//IL_0113: Unknown result type (might be due to invalid IL or missing references)
		//IL_009c: Unknown result type (might be due to invalid IL or missing references)
		//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
		//IL_02ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_027c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0281: Unknown result type (might be due to invalid IL or missing references)
		//IL_0147: Unknown result type (might be due to invalid IL or missing references)
		//IL_0153: Unknown result type (might be due to invalid IL or missing references)
		//IL_0181: Expected O, but got Unknown
		newPos = Mathf.Clamp(1f - newPos, 0.05f, 0.99f);
		pointerPos = newPos;
		Color pixelBilinear = ((Texture2D)hsvSlider.texture).GetPixelBilinear(0f, pointerPos);
		Rect rect;
		if (Object.op_Implicit((Object)(object)hsvImage) && (Object)(object)hsvImage.texture != (Object)null)
		{
			rect = ((Graphic)hsvImage).rectTransform.rect;
			if ((int)((Rect)(ref rect)).width == hsvImage.texture.width)
			{
				rect = ((Graphic)hsvImage).rectTransform.rect;
				if ((int)((Rect)(ref rect)).height == hsvImage.texture.height)
				{
					HSVUtil.GenerateColorTexture(pixelBilinear, (Texture2D)hsvImage.texture, minHue, maxHue, minSat, maxSat, minV, maxV);
					goto IL_01eb;
				}
			}
			Object.Destroy((Object)(object)hsvImage.texture);
			hsvImage.texture = null;
			RawImage obj = hsvImage;
			rect = ((Graphic)hsvImage).rectTransform.rect;
			int width = (int)((Rect)(ref rect)).width;
			rect = ((Graphic)hsvImage).rectTransform.rect;
			obj.texture = (Texture)(object)HSVUtil.GenerateColorTexture(width, (int)((Rect)(ref rect)).height, pixelBilinear, minHue, maxHue, minSat, maxSat, minV, maxV);
		}
		else
		{
			RawImage obj2 = hsvImage;
			rect = ((Graphic)hsvImage).rectTransform.rect;
			int width2 = (int)((Rect)(ref rect)).width;
			rect = ((Graphic)hsvImage).rectTransform.rect;
			obj2.texture = (Texture)(object)HSVUtil.GenerateColorTexture(width2, (int)((Rect)(ref rect)).height, pixelBilinear, minHue, maxHue, minSat, maxSat, minV, maxV);
		}
		goto IL_01eb;
		IL_01eb:
		if (isChanging)
		{
			return Color32.op_Implicit(currentColor);
		}
		isChanging = true;
		currentColor = Color32.op_Implicit(GetColor(cursorX, cursorY));
		((Graphic)colorImage).color = Color32.op_Implicit(currentColor);
		r = currentColor.r;
		g = currentColor.g;
		b = currentColor.b;
		if (updateInputs)
		{
			UpdateInputs();
			((UnityEvent<Color>)onValueChanged).Invoke(Color32.op_Implicit(currentColor));
			if ((Object)(object)hexrgb != (Object)null)
			{
				hexrgb.ManipulateViaRGB2Hex();
			}
		}
		isChanging = false;
		return Color32.op_Implicit(currentColor);
	}

	public void UpdateInputs()
	{
		if (Object.op_Implicit((Object)(object)sliderR))
		{
			sliderR.value = (int)r;
		}
		if (Object.op_Implicit((Object)(object)sliderG))
		{
			sliderG.value = (int)g;
		}
		if (Object.op_Implicit((Object)(object)sliderB))
		{
			sliderB.value = (int)b;
		}
		if (Object.op_Implicit((Object)(object)sliderRText))
		{
			sliderRText.text = "R:" + r;
		}
		if (Object.op_Implicit((Object)(object)sliderGText))
		{
			sliderGText.text = "G:" + g;
		}
		if (Object.op_Implicit((Object)(object)sliderBText))
		{
			sliderBText.text = "B:" + b;
		}
	}

	private void OnDestroy()
	{
		if (Object.op_Implicit((Object)(object)hsvSlider) && (Object)(object)hsvSlider.texture != (Object)null)
		{
			Object.Destroy((Object)(object)hsvSlider.texture);
		}
		if (Object.op_Implicit((Object)(object)hsvImage) && (Object)(object)hsvImage.texture != (Object)null)
		{
			Object.Destroy((Object)(object)hsvImage.texture);
		}
	}
}
