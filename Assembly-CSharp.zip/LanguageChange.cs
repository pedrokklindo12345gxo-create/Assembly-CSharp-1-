using UnityEngine;

public class LanguageChange : MonoBehaviour
{
	public GameObject TitleCanvasSpanish;

	public GameObject TitleCanvas;

	private void Awake()
	{
		//IL_0000: Unknown result type (might be due to invalid IL or missing references)
		//IL_0007: Invalid comparison between Unknown and I4
		if ((int)Application.systemLanguage == 34)
		{
			TitleCanvasSpanish.SetActive(true);
			TitleCanvas.SetActive(false);
		}
	}
}
