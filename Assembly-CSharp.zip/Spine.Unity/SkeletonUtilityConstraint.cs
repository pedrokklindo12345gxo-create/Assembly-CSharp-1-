using UnityEngine;

namespace Spine.Unity;

[RequireComponent(typeof(SkeletonUtilityBone))]
[ExecuteInEditMode]
public abstract class SkeletonUtilityConstraint : MonoBehaviour
{
	protected SkeletonUtilityBone utilBone;

	protected SkeletonUtility skeletonUtility;

	protected virtual void OnEnable()
	{
		utilBone = ((Component)this).GetComponent<SkeletonUtilityBone>();
		skeletonUtility = ((Component)((Component)this).transform).GetComponentInParent<SkeletonUtility>();
		skeletonUtility.RegisterConstraint(this);
	}

	protected virtual void OnDisable()
	{
		skeletonUtility.UnregisterConstraint(this);
	}

	public abstract void DoUpdate();
}
