using System;
using System.Collections.Generic;
using UnityEngine;

namespace Spine.Unity;

[RequireComponent(typeof(Animator))]
public class SkeletonAnimator : SkeletonRenderer, ISkeletonAnimation
{
	public enum MixMode
	{
		AlwaysMix,
		MixNext,
		SpineStyle
	}

	public MixMode[] layerMixModes = new MixMode[0];

	public bool autoReset;

	private List<Animation> previousAnimations = new List<Animation>();

	private readonly Dictionary<int, Animation> animationTable = new Dictionary<int, Animation>();

	private readonly Dictionary<AnimationClip, int> clipNameHashCodeTable = new Dictionary<AnimationClip, int>();

	private Animator animator;

	protected event UpdateBonesDelegate _UpdateLocal;

	protected event UpdateBonesDelegate _UpdateWorld;

	protected event UpdateBonesDelegate _UpdateComplete;

	public event UpdateBonesDelegate UpdateLocal
	{
		add
		{
			_UpdateLocal += value;
		}
		remove
		{
			_UpdateLocal -= value;
		}
	}

	public event UpdateBonesDelegate UpdateWorld
	{
		add
		{
			_UpdateWorld += value;
		}
		remove
		{
			_UpdateWorld -= value;
		}
	}

	public event UpdateBonesDelegate UpdateComplete
	{
		add
		{
			_UpdateComplete += value;
		}
		remove
		{
			_UpdateComplete -= value;
		}
	}

	public override void Initialize(bool overwrite)
	{
		if (valid && !overwrite)
		{
			return;
		}
		base.Initialize(overwrite);
		if (!valid)
		{
			return;
		}
		animationTable.Clear();
		clipNameHashCodeTable.Clear();
		animator = ((Component)this).GetComponent<Animator>();
		foreach (Animation animation in skeletonDataAsset.GetSkeletonData(quiet: true).Animations)
		{
			animationTable.Add(animation.Name.GetHashCode(), animation);
		}
	}

	public void Update()
	{
		//IL_01be: Unknown result type (might be due to invalid IL or missing references)
		//IL_01c3: Unknown result type (might be due to invalid IL or missing references)
		//IL_01cc: Unknown result type (might be due to invalid IL or missing references)
		//IL_01d1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0351: Unknown result type (might be due to invalid IL or missing references)
		//IL_0356: Unknown result type (might be due to invalid IL or missing references)
		//IL_0218: Unknown result type (might be due to invalid IL or missing references)
		//IL_021d: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b2: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b7: Unknown result type (might be due to invalid IL or missing references)
		//IL_03ec: Unknown result type (might be due to invalid IL or missing references)
		//IL_03f1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ea: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ef: Unknown result type (might be due to invalid IL or missing references)
		//IL_02b9: Unknown result type (might be due to invalid IL or missing references)
		//IL_02be: Unknown result type (might be due to invalid IL or missing references)
		//IL_0529: Unknown result type (might be due to invalid IL or missing references)
		//IL_052e: Unknown result type (might be due to invalid IL or missing references)
		//IL_013b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0140: Unknown result type (might be due to invalid IL or missing references)
		//IL_0495: Unknown result type (might be due to invalid IL or missing references)
		//IL_049a: Unknown result type (might be due to invalid IL or missing references)
		if (!valid)
		{
			return;
		}
		if (layerMixModes.Length < animator.layerCount)
		{
			Array.Resize(ref layerMixModes, animator.layerCount);
		}
		if (autoReset)
		{
			List<Animation> list = previousAnimations;
			int i = 0;
			for (int count = list.Count; i < count; i++)
			{
				list[i].SetKeyedItemsToSetupPose(skeleton);
			}
			list.Clear();
			int j = 0;
			for (int layerCount = animator.layerCount; j < layerCount; j++)
			{
				float num = ((j != 0) ? animator.GetLayerWeight(j) : 1f);
				if (num <= 0f)
				{
					continue;
				}
				AnimatorStateInfo nextAnimatorStateInfo = animator.GetNextAnimatorStateInfo(j);
				bool flag = ((AnimatorStateInfo)(ref nextAnimatorStateInfo)).fullPathHash != 0;
				AnimatorClipInfo[] currentAnimatorClipInfo = animator.GetCurrentAnimatorClipInfo(j);
				AnimatorClipInfo[] nextAnimatorClipInfo = animator.GetNextAnimatorClipInfo(j);
				for (int k = 0; k < currentAnimatorClipInfo.Length; k++)
				{
					AnimatorClipInfo val = currentAnimatorClipInfo[k];
					if (((AnimatorClipInfo)(ref val)).weight * num != 0f)
					{
						list.Add(animationTable[NameHashCode(((AnimatorClipInfo)(ref val)).clip)]);
					}
				}
				if (!flag)
				{
					continue;
				}
				for (int l = 0; l < nextAnimatorClipInfo.Length; l++)
				{
					AnimatorClipInfo val2 = nextAnimatorClipInfo[l];
					if (((AnimatorClipInfo)(ref val2)).weight * num != 0f)
					{
						list.Add(animationTable[NameHashCode(((AnimatorClipInfo)(ref val2)).clip)]);
					}
				}
			}
		}
		int m = 0;
		for (int layerCount2 = animator.layerCount; m < layerCount2; m++)
		{
			float num2 = ((m != 0) ? animator.GetLayerWeight(m) : 1f);
			AnimatorStateInfo currentAnimatorStateInfo = animator.GetCurrentAnimatorStateInfo(m);
			AnimatorStateInfo nextAnimatorStateInfo2 = animator.GetNextAnimatorStateInfo(m);
			bool flag2 = ((AnimatorStateInfo)(ref nextAnimatorStateInfo2)).fullPathHash != 0;
			AnimatorClipInfo[] currentAnimatorClipInfo2 = animator.GetCurrentAnimatorClipInfo(m);
			AnimatorClipInfo[] nextAnimatorClipInfo2 = animator.GetNextAnimatorClipInfo(m);
			MixMode mixMode = layerMixModes[m];
			if (mixMode == MixMode.AlwaysMix)
			{
				for (int n = 0; n < currentAnimatorClipInfo2.Length; n++)
				{
					AnimatorClipInfo val3 = currentAnimatorClipInfo2[n];
					float num3 = ((AnimatorClipInfo)(ref val3)).weight * num2;
					if (num3 != 0f)
					{
						animationTable[NameHashCode(((AnimatorClipInfo)(ref val3)).clip)].Apply(skeleton, 0f, AnimationTime(((AnimatorStateInfo)(ref currentAnimatorStateInfo)).normalizedTime, ((AnimatorClipInfo)(ref val3)).clip.length, ((AnimatorStateInfo)(ref currentAnimatorStateInfo)).loop, ((AnimatorStateInfo)(ref currentAnimatorStateInfo)).speed < 0f), ((AnimatorStateInfo)(ref currentAnimatorStateInfo)).loop, null, num3, setupPose: false, mixingOut: false);
					}
				}
				if (!flag2)
				{
					continue;
				}
				for (int num4 = 0; num4 < nextAnimatorClipInfo2.Length; num4++)
				{
					AnimatorClipInfo val4 = nextAnimatorClipInfo2[num4];
					float num5 = ((AnimatorClipInfo)(ref val4)).weight * num2;
					if (num5 != 0f)
					{
						animationTable[NameHashCode(((AnimatorClipInfo)(ref val4)).clip)].Apply(skeleton, 0f, AnimationTime(((AnimatorStateInfo)(ref nextAnimatorStateInfo2)).normalizedTime, ((AnimatorClipInfo)(ref val4)).clip.length, ((AnimatorStateInfo)(ref nextAnimatorStateInfo2)).speed < 0f), ((AnimatorStateInfo)(ref nextAnimatorStateInfo2)).loop, null, num5, setupPose: false, mixingOut: false);
					}
				}
				continue;
			}
			int num6;
			for (num6 = 0; num6 < currentAnimatorClipInfo2.Length; num6++)
			{
				AnimatorClipInfo val5 = currentAnimatorClipInfo2[num6];
				if (((AnimatorClipInfo)(ref val5)).weight * num2 != 0f)
				{
					animationTable[NameHashCode(((AnimatorClipInfo)(ref val5)).clip)].Apply(skeleton, 0f, AnimationTime(((AnimatorStateInfo)(ref currentAnimatorStateInfo)).normalizedTime, ((AnimatorClipInfo)(ref val5)).clip.length, ((AnimatorStateInfo)(ref currentAnimatorStateInfo)).loop, ((AnimatorStateInfo)(ref currentAnimatorStateInfo)).speed < 0f), ((AnimatorStateInfo)(ref currentAnimatorStateInfo)).loop, null, 1f, setupPose: false, mixingOut: false);
					break;
				}
			}
			for (; num6 < currentAnimatorClipInfo2.Length; num6++)
			{
				AnimatorClipInfo val6 = currentAnimatorClipInfo2[num6];
				float num7 = ((AnimatorClipInfo)(ref val6)).weight * num2;
				if (num7 != 0f)
				{
					animationTable[NameHashCode(((AnimatorClipInfo)(ref val6)).clip)].Apply(skeleton, 0f, AnimationTime(((AnimatorStateInfo)(ref currentAnimatorStateInfo)).normalizedTime, ((AnimatorClipInfo)(ref val6)).clip.length, ((AnimatorStateInfo)(ref currentAnimatorStateInfo)).loop, ((AnimatorStateInfo)(ref currentAnimatorStateInfo)).speed < 0f), ((AnimatorStateInfo)(ref currentAnimatorStateInfo)).loop, null, num7, setupPose: false, mixingOut: false);
				}
			}
			num6 = 0;
			if (!flag2)
			{
				continue;
			}
			if (mixMode == MixMode.SpineStyle)
			{
				for (; num6 < nextAnimatorClipInfo2.Length; num6++)
				{
					AnimatorClipInfo val7 = nextAnimatorClipInfo2[num6];
					if (((AnimatorClipInfo)(ref val7)).weight * num2 != 0f)
					{
						animationTable[NameHashCode(((AnimatorClipInfo)(ref val7)).clip)].Apply(skeleton, 0f, AnimationTime(((AnimatorStateInfo)(ref nextAnimatorStateInfo2)).normalizedTime, ((AnimatorClipInfo)(ref val7)).clip.length, ((AnimatorStateInfo)(ref nextAnimatorStateInfo2)).speed < 0f), ((AnimatorStateInfo)(ref nextAnimatorStateInfo2)).loop, null, 1f, setupPose: false, mixingOut: false);
						break;
					}
				}
			}
			for (; num6 < nextAnimatorClipInfo2.Length; num6++)
			{
				AnimatorClipInfo val8 = nextAnimatorClipInfo2[num6];
				float num8 = ((AnimatorClipInfo)(ref val8)).weight * num2;
				if (num8 != 0f)
				{
					animationTable[NameHashCode(((AnimatorClipInfo)(ref val8)).clip)].Apply(skeleton, 0f, AnimationTime(((AnimatorStateInfo)(ref nextAnimatorStateInfo2)).normalizedTime, ((AnimatorClipInfo)(ref val8)).clip.length, ((AnimatorStateInfo)(ref nextAnimatorStateInfo2)).speed < 0f), ((AnimatorStateInfo)(ref nextAnimatorStateInfo2)).loop, null, num8, setupPose: false, mixingOut: false);
				}
			}
		}
		if (this._UpdateLocal != null)
		{
			this._UpdateLocal(this);
		}
		skeleton.UpdateWorldTransform();
		if (this._UpdateWorld != null)
		{
			this._UpdateWorld(this);
			skeleton.UpdateWorldTransform();
		}
		if (this._UpdateComplete != null)
		{
			this._UpdateComplete(this);
		}
	}

	private static float AnimationTime(float normalizedTime, float clipLength, bool loop, bool reversed)
	{
		if (reversed)
		{
			normalizedTime = 1f - normalizedTime + (float)(int)normalizedTime + (float)(int)normalizedTime;
		}
		float num = normalizedTime * clipLength;
		if (loop)
		{
			return num;
		}
		if (clipLength - num < 1f / 30f)
		{
			return clipLength;
		}
		return num;
	}

	private static float AnimationTime(float normalizedTime, float clipLength, bool reversed)
	{
		if (reversed)
		{
			normalizedTime = 1f - normalizedTime + (float)(int)normalizedTime + (float)(int)normalizedTime;
		}
		return normalizedTime * clipLength;
	}

	private int NameHashCode(AnimationClip clip)
	{
		if (!clipNameHashCodeTable.TryGetValue(clip, out var value))
		{
			value = ((Object)clip).name.GetHashCode();
			clipNameHashCodeTable.Add(clip, value);
		}
		return value;
	}
}
