using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Xml.Serialization;
using DG.Tweening;
using DG.Tweening.Core;
using DG.Tweening.Plugins.Options;
using TouchControlsKit;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class PauseMenu : MonoBehaviour
{
	public class Hint
	{
		public string NPC;

		public int Number;

		public string Description;

		public bool Unlocked;

		public bool Viewed;

		public bool UnlockedByDefault;
	}

	public class HintList
	{
		public Hint[] Hints;
	}

	private HintList mHints;

	public RectTransform pauseMenu;

	public RectTransform areYouSureMenu;

	public Text areYouSureText;

	public RectTransform areYouSureEraseData;

	public Transform pauseButtons;

	private bool mPauseOpen;

	private bool mAreYouSureOpen;

	public Transform yesButton;

	public Transform noButton;

	public Transform hintsPanel;

	public Transform hintGrid;

	public Text hintDescription;

	public Image hintBackground;

	public Text versionNumber;

	public Transform mainOptionsPanel;

	public Transform mainOptionsButtons;

	public Transform controlOptionsPanel;

	public Transform videoOptionsPanel;

	public Transform audioOptionsPanel;

	public Transform[] controlBoxes;

	private int mCurrentSelection;

	private int mOptionSelection;

	private bool mHintsOpen;

	private bool mMainOptionsOpen;

	private bool mAudioOptionsOpen;

	private bool mControlOptionsOpen;

	private bool mVideoOptionsOpen;

	private bool mAreYouSureData;

	private Event keyEvent;

	private List<Resolution> mAvailableResolutions = new List<Resolution>();

	public Sprite buggsFace;

	public Sprite monstermon;

	private Transform mMusicBox;

	private Transform mEffectsVolumeBox;

	private bool mYes;

	private int mHintSelection;

	private bool mWaitReconfigure;

	private int mControlSelection;

	private int mCurrentRes;

	private int mVideoSelection;

	private bool mIsFullScreen;

	private int mAudioSelection;

	private float mMusicVolume;

	private float mEffectsVolume;

	public bool IsOpen
	{
		get
		{
			if (!mPauseOpen && !mAreYouSureOpen && !mHintsOpen && !mAudioOptionsOpen && !mControlOptionsOpen && !mVideoOptionsOpen && !mMainOptionsOpen)
			{
				return mAreYouSureData;
			}
			return true;
		}
	}

	private void Start()
	{
		GetResolutions();
		((MonoBehaviour)this).StartCoroutine(InitializeHints());
		mMusicBox = GameObject.Find("MusicVolumeBox").transform;
		mEffectsVolumeBox = GameObject.Find("EffectsVolumeBox").transform;
	}

	private void OnGUI()
	{
		keyEvent = Event.current;
	}

	private void GetResolutions()
	{
		//IL_0011: Unknown result type (might be due to invalid IL or missing references)
		//IL_0016: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_009a: Unknown result type (might be due to invalid IL or missing references)
		//IL_009f: Unknown result type (might be due to invalid IL or missing references)
		//IL_00d4: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
		int num = 0;
		Resolution[] resolutions = Screen.resolutions;
		for (int i = 0; i < resolutions.Length; i++)
		{
			Resolution item = resolutions[i];
			bool flag = true;
			foreach (Resolution mAvailableResolution in mAvailableResolutions)
			{
				Resolution current = mAvailableResolution;
				if (((Resolution)(ref item)).width == ((Resolution)(ref current)).width && ((Resolution)(ref item)).height == ((Resolution)(ref current)).height)
				{
					flag = false;
				}
			}
			if (!flag)
			{
				continue;
			}
			if (num == 0)
			{
				mAvailableResolutions.Add(item);
			}
			else
			{
				bool flag2 = false;
				for (int j = 0; j < num; j++)
				{
					int width = ((Resolution)(ref item)).width;
					Resolution val = mAvailableResolutions[j];
					if (width < ((Resolution)(ref val)).width && !flag2)
					{
						mAvailableResolutions.Insert(j, item);
						flag2 = true;
					}
				}
				if (!flag2)
				{
					mAvailableResolutions.Add(item);
				}
			}
			num++;
		}
	}

	private IEnumerator InitializeHints()
	{
		XmlSerializer xmlSerializer = new XmlSerializer(typeof(HintList));
		StringReader stringReader = new StringReader(((TextAsset)(EnvironmentController.Instance.isSpanish ? /*isinst with value type is only supported in some contexts*/: /*isinst with value type is only supported in some contexts*/)).text);
		mHints = (HintList)xmlSerializer.Deserialize(stringReader);
		Hint[] hints = mHints.Hints;
		foreach (Hint hint in hints)
		{
			int num = PlayerPrefs.GetInt(hint.NPC + hint.Number + EnvironmentController.Instance.GetFileModifier(), 0);
			if (num == 0)
			{
				hint.Unlocked = false;
				hint.Viewed = false;
			}
			if (num > 0 || hint.UnlockedByDefault)
			{
				hint.Unlocked = true;
			}
			if (num > 1)
			{
				hint.Unlocked = true;
				hint.Viewed = true;
			}
		}
		stringReader.Close();
		yield return null;
		Dictionary<string, Sprite> dictionary = new Dictionary<string, Sprite>
		{
			{
				"Lily",
				Object.FindObjectOfType<Lily>().defaultTextureBlock.face
			},
			{
				"Jerome",
				Object.FindObjectOfType<Jerome>().defaultTextureBlock.face
			},
			{
				"Cindy",
				Object.FindObjectOfType<Cindy>().defaultTextureBlock.face
			},
			{ "Buggs", buggsFace },
			{
				"Monty",
				Object.FindObjectOfType<Monty>().defaultTextureBlock.face
			},
			{
				"Nugget",
				Object.FindObjectOfType<Nugget>().defaultTextureBlock.face
			},
			{
				"Teacher",
				Object.FindObjectOfType<Teacher>().defaultTextureBlock.face
			},
			{
				"General",
				PlayerController.instance.face
			},
			{ "Monstermon", monstermon }
		};
		Dictionary<string, Color> dictionary2 = new Dictionary<string, Color>
		{
			{
				"Lily",
				Object.FindObjectOfType<Lily>().dialogueColor
			},
			{
				"Jerome",
				Object.FindObjectOfType<Jerome>().dialogueColor
			},
			{
				"Cindy",
				Object.FindObjectOfType<Cindy>().dialogueColor
			},
			{
				"Buggs",
				Object.FindObjectOfType<Buggs>().dialogueColor
			},
			{
				"Monty",
				Object.FindObjectOfType<Monty>().dialogueColor
			},
			{
				"Nugget",
				Object.FindObjectOfType<Nugget>().dialogueColor
			},
			{
				"Teacher",
				Object.FindObjectOfType<Teacher>().dialogueColor
			},
			{
				"General",
				Color.white
			},
			{
				"Monstermon",
				Color.cyan
			}
		};
		for (int j = 0; j < mHints.Hints.Length; j++)
		{
			Transform child = hintGrid.GetChild(j);
			child.GetChild(0).eulerAngles = new Vector3(0f, 0f, (float)(90 * Random.Range(0, 4)));
			if (mHints.Hints[j].Unlocked)
			{
				((Graphic)((Component)child).GetComponent<Image>()).color = dictionary2[mHints.Hints[j].NPC] - new Color(0f, 0f, 0f, 0.5f);
				((Behaviour)((Component)child.GetChild(1)).GetComponent<Image>()).enabled = true;
				((Component)child.GetChild(1)).GetComponent<Image>().sprite = dictionary[mHints.Hints[j].NPC];
				((Component)child.GetChild(2)).GetComponent<Text>().text = mHints.Hints[j].Number.ToString();
				if (!mHints.Hints[j].Viewed)
				{
					((Behaviour)((Component)child.GetChild(3)).GetComponent<Text>()).enabled = true;
				}
				((Behaviour)((Component)child.GetChild(4)).GetComponent<Text>()).enabled = false;
			}
		}
	}

	public void UnlockHint(string npc, int u)
	{
		for (int i = 0; i < mHints.Hints.Length; i++)
		{
			if (mHints.Hints[i].NPC == npc && mHints.Hints[i].Number == u)
			{
				if (!mHints.Hints[i].Unlocked)
				{
					PlayerPrefs.SetInt(npc + u + EnvironmentController.Instance.GetFileModifier(), 1);
					mHints.Hints[i].Unlocked = true;
					((MonoBehaviour)this).StartCoroutine(Object.FindObjectOfType<UIController>().ShowUnlockHint());
					UnlockHint(npc, u, i);
				}
				break;
			}
		}
	}

	public void UnlockAllHints(string npc)
	{
		for (int i = 0; i < mHints.Hints.Length; i++)
		{
			if (mHints.Hints[i].NPC == npc && !mHints.Hints[i].Unlocked)
			{
				PlayerPrefs.SetInt(npc + mHints.Hints[i].Number + EnvironmentController.Instance.GetFileModifier(), 1);
				mHints.Hints[i].Unlocked = true;
				UnlockHint(npc, mHints.Hints[i].Number, i);
			}
		}
	}

	private void UnlockHint(string npc, int number, int index)
	{
		//IL_004f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0031: Unknown result type (might be due to invalid IL or missing references)
		//IL_0036: Unknown result type (might be due to invalid IL or missing references)
		//IL_007b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0090: Unknown result type (might be due to invalid IL or missing references)
		//IL_0095: Unknown result type (might be due to invalid IL or missing references)
		Transform child = hintGrid.GetChild(index);
		Color val;
		Sprite sprite;
		if (npc != "General" && npc != "Monstermon")
		{
			val = GameObject.Find(npc).GetComponent<NPCBehavior>().dialogueColor;
			sprite = GameObject.Find(npc).GetComponent<NPCBehavior>().defaultTextureBlock.face;
		}
		else
		{
			val = Color.white;
			sprite = ((!(npc == "Monstermon")) ? PlayerController.instance.face : monstermon);
		}
		((Graphic)((Component)child).GetComponent<Image>()).color = val - new Color(0f, 0f, 0f, 0.5f);
		((Behaviour)((Component)child.GetChild(1)).GetComponent<Image>()).enabled = true;
		((Component)child.GetChild(1)).GetComponent<Image>().sprite = sprite;
		((Component)child.GetChild(2)).GetComponent<Text>().text = number.ToString();
		((Behaviour)((Component)child.GetChild(3)).GetComponent<Text>()).enabled = true;
		((Behaviour)((Component)child.GetChild(4)).GetComponent<Text>()).enabled = false;
	}

	public void OpenPauseMenu()
	{
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		if (mHintsOpen || mMainOptionsOpen || mVideoOptionsOpen || mAudioOptionsOpen || mControlOptionsOpen)
		{
			return;
		}
		((Behaviour)versionNumber).enabled = true;
		if (!mPauseOpen)
		{
			if (mAreYouSureOpen)
			{
				SFXManager.Instance.PlaySound("Confirm");
				CloseAreYouSure(backToMain: true);
				return;
			}
			mPauseOpen = true;
			DOTweenModuleUI.DOFade(((Component)this).GetComponent<Image>(), 0.6f, 0.25f);
			ShortcutExtensions.DOScale((Transform)(object)pauseMenu, new Vector3(0.2f, 1.3f, 1f), 0.15f);
			TweenSettingsExtensions.SetDelay<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOScale((Transform)(object)pauseMenu, 1f, 0.1f), 0.15f);
			((MonoBehaviour)this).StartCoroutine(RunPauseMenu());
		}
		else
		{
			SFXManager.Instance.PlaySound("Confirm");
			DOTweenModuleUI.DOFade(((Component)this).GetComponent<Image>(), 0f, 0.25f);
			ClosePauseMenu();
		}
	}

	public void SetPauseSelection(int x)
	{
		if (mCurrentSelection != x)
		{
			SFXManager.Instance.PlaySound("DialoguePop");
			UnHighlightButton(mCurrentSelection);
			mCurrentSelection = x;
			HighlightButton(mCurrentSelection);
		}
	}

	private IEnumerator RunPauseMenu()
	{
		HighlightButton(0);
		mCurrentSelection = 0;
		yield return (object)new WaitForSeconds(0.3f);
		for (int i = 0; i < 7; i++)
		{
			UnHighlightButton(i);
		}
		HighlightButton(0);
		((Component)pauseMenu).GetComponent<CanvasGroup>().blocksRaycasts = true;
		((MonoBehaviour)this).StartCoroutine(WaitForConfirm());
		while (mPauseOpen)
		{
			float axis = TCKInput.GetAxis("DPad0", AxisType.Y);
			if (axis > 0f)
			{
				if (mCurrentSelection > 0)
				{
					SFXManager.Instance.PlaySound("DialoguePop");
					UnHighlightButton(mCurrentSelection);
					mCurrentSelection--;
					HighlightButton(mCurrentSelection);
					yield return (object)new WaitForSeconds(0.25f);
				}
			}
			else if (axis < 0f && mCurrentSelection < 6)
			{
				SFXManager.Instance.PlaySound("DialoguePop");
				UnHighlightButton(mCurrentSelection);
				mCurrentSelection++;
				HighlightButton(mCurrentSelection);
				yield return (object)new WaitForSeconds(0.25f);
			}
			yield return null;
		}
		((Component)pauseMenu).GetComponent<CanvasGroup>().blocksRaycasts = false;
		UnHighlightButton(mCurrentSelection);
	}

	private IEnumerator WaitForConfirm()
	{
		while (mPauseOpen)
		{
			if (InputManager.Instance.IsInteractPressed())
			{
				((Component)pauseMenu).GetComponent<CanvasGroup>().blocksRaycasts = false;
				ClosePauseMenu();
				SFXManager.Instance.PlaySound("Confirm");
				if (mCurrentSelection == 1 || mCurrentSelection == 2 || mCurrentSelection == 6)
				{
					yield return (object)new WaitForSeconds(0.2f);
					((MonoBehaviour)this).StartCoroutine(ActivateAreYouSure(mCurrentSelection));
				}
				else if (mCurrentSelection == 3)
				{
					yield return (object)new WaitForSeconds(0.2f);
					((MonoBehaviour)this).StartCoroutine(RunHintsMenu());
				}
				else if (mCurrentSelection == 4)
				{
					yield return (object)new WaitForSeconds(0.2f);
					((MonoBehaviour)this).StartCoroutine(RunOptionsMainMenu());
				}
				else if (mCurrentSelection == 5)
				{
					DOTweenModuleUI.DOFade(((Component)this).GetComponent<Image>(), 0f, 0.25f);
					Object.FindObjectOfType<UIController>().StartTutorial();
				}
				else
				{
					DOTweenModuleUI.DOFade(((Component)this).GetComponent<Image>(), 0f, 0.25f);
				}
			}
			yield return null;
		}
	}

	private void ClosePauseMenu()
	{
		//IL_0039: Unknown result type (might be due to invalid IL or missing references)
		((Component)pauseMenu).GetComponent<CanvasGroup>().blocksRaycasts = false;
		((Behaviour)versionNumber).enabled = false;
		mPauseOpen = false;
		ShortcutExtensions.DOScale((Transform)(object)pauseMenu, new Vector3(0.2f, 1.3f, 1f), 0.15f);
		TweenSettingsExtensions.SetDelay<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOScale((Transform)(object)pauseMenu, 0f, 0.1f), 0.15f);
	}

	public void SetYes(bool x)
	{
		if (x)
		{
			mYes = false;
			SFXManager.Instance.PlaySound("DialoguePop");
			if (!mAreYouSureData)
			{
				ShortcutExtensions.DOScale(noButton, 1.1f, 0.1f);
				ShortcutExtensions.DOScale(yesButton, 1f, 0.1f);
				((Behaviour)((Component)yesButton).GetComponentInChildren<Outline>()).enabled = false;
				((Behaviour)((Component)noButton).GetComponentInChildren<Outline>()).enabled = true;
			}
			else
			{
				UnHighlightWindow(GameObject.Find("YesButtonData").transform);
				HighlightWindow(GameObject.Find("NoButtonData").transform);
			}
		}
		else
		{
			mYes = true;
			SFXManager.Instance.PlaySound("DialoguePop");
			if (!mAreYouSureData)
			{
				ShortcutExtensions.DOScale(noButton, 1f, 0.2f);
				ShortcutExtensions.DOScale(yesButton, 1.1f, 0.2f);
				((Behaviour)((Component)yesButton).GetComponentInChildren<Outline>()).enabled = true;
				((Behaviour)((Component)noButton).GetComponentInChildren<Outline>()).enabled = false;
			}
			else
			{
				HighlightWindow(GameObject.Find("YesButtonData").transform);
				UnHighlightWindow(GameObject.Find("NoButtonData").transform);
			}
		}
	}

	private IEnumerator RunAreYouSureEraseData()
	{
		mAreYouSureData = true;
		ShortcutExtensions.DOScale((Transform)(object)areYouSureEraseData, new Vector3(0.2f, 1.3f, 1f), 0.15f);
		TweenSettingsExtensions.SetDelay<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOScale((Transform)(object)areYouSureEraseData, 1f, 0.1f), 0.15f);
		Text questionText = GameObject.Find("QuestionDataText").GetComponent<Text>();
		if (!EnvironmentController.Instance.isSpanish)
		{
			questionText.text = "Are you sure you want to delete all progress on this file? You will lose all unlocked special items, Monstermon cards, and money in your piggy bank.";
		}
		else
		{
			questionText.text = "¿Seguro que quieres eliminar todo el progreso de este archivo? Perderás todos los artículos especiales desbloqueados, tarjetas Monstermon y  el dinero de tu alcancía.";
		}
		mYes = true;
		yield return (object)new WaitForSeconds(0.5f);
		((Component)areYouSureEraseData).GetComponent<CanvasGroup>().blocksRaycasts = true;
		Transform eYesButton = GameObject.Find("YesButtonData").transform;
		Transform eNoButton = GameObject.Find("NoButtonData").transform;
		bool reallySure = false;
		mYes = false;
		HighlightWindow(eNoButton);
		UnHighlightWindow(eYesButton);
		while (mAreYouSureData)
		{
			if (TCKInput.GetAxis("DPad0", AxisType.X) > 0f)
			{
				if (mYes)
				{
					mYes = false;
					HighlightWindow(eNoButton);
					UnHighlightWindow(eYesButton);
					SFXManager.Instance.PlaySound("DialoguePop");
				}
			}
			else if (TCKInput.GetAxis("DPad0", AxisType.X) < 0f && !mYes)
			{
				mYes = true;
				HighlightWindow(eYesButton);
				UnHighlightWindow(eNoButton);
				SFXManager.Instance.PlaySound("DialoguePop");
			}
			if (InputManager.Instance.IsInteractPressed())
			{
				SFXManager.Instance.PlaySound("Confirm");
				if (mYes)
				{
					if (!reallySure)
					{
						if (!EnvironmentController.Instance.isSpanish)
						{
							questionText.text = "Seriously. If you press 'yes' again your data is gone. It's not coming back.";
						}
						else
						{
							questionText.text = "En serio. Si vuelves a presionar  'sí', tus datos desaparecerán. Por siempre.";
						}
						reallySure = true;
						yield return (object)new WaitForSeconds(0.5f);
					}
					else
					{
						DeleteData(EnvironmentController.Instance.GetFileModifier());
					}
				}
				else
				{
					mAreYouSureData = false;
				}
			}
			yield return null;
		}
		ShortcutExtensions.DOScale((Transform)(object)areYouSureEraseData, new Vector3(0.2f, 1.3f, 1f), 0.15f);
		TweenSettingsExtensions.SetDelay<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOScale((Transform)(object)areYouSureEraseData, 0f, 0.1f), 0.15f);
		((MonoBehaviour)this).StartCoroutine(RunOptionsMainMenu());
		((Component)areYouSureEraseData).GetComponent<CanvasGroup>().blocksRaycasts = false;
	}

	private void DeleteData(string x)
	{
		PlayerPrefs.SetFloat("PiggyBank" + EnvironmentController.Instance.GetFileModifier(), 5f);
		PlayerPrefs.SetInt("PlayerDeaths" + EnvironmentController.Instance.GetFileModifier(), 0);
		PlayerPrefs.SetInt("DaysComplete" + EnvironmentController.Instance.GetFileModifier(), 1);
		PlayerPrefs.SetInt("WorldEnder" + EnvironmentController.Instance.GetFileModifier(), 0);
		PlayerPrefs.SetInt("UnlockKeyMold" + x, 0);
		PlayerPrefs.SetInt("UnlockLunchPass" + x, 0);
		PlayerPrefs.SetInt("UnlockKingTowerbeetle" + x, 0);
		PlayerPrefs.SetInt("UnlockGiraffeSerpent" + x, 0);
		PlayerPrefs.SetInt("UnlockFaptainCalcon" + x, 0);
		PlayerPrefs.SetInt("UnlockMagicalAirship" + x, 0);
		PlayerPrefs.SetInt("UnlockBillyNote" + x, 0);
		PlayerPrefs.SetInt("UnlockReallyBrightStar" + x, 0);
		PlayerPrefs.SetInt("UnlockFlower" + x, 0);
		PlayerPrefs.SetInt("UnlockPrincipalKey" + x, 0);
		PlayerPrefs.SetInt("UnlockEvilThwarter" + x, 0);
		PlayerPrefs.SetInt("UnlockPhone" + x, 0);
		PlayerPrefs.SetInt("UnlockWizardWorm" + x, 0);
		PlayerPrefs.SetInt("UnlockHolyKnight" + x, 0);
		PlayerPrefs.SetInt("UnlockFreezyguyJim" + x, 0);
		PlayerPrefs.SetInt("UnlockTornadoFly" + x, 0);
		PlayerPrefs.SetInt("UnlockManWithLongArm" + x, 0);
		PlayerPrefs.SetInt("UnlockOhfakaTornado" + x, 0);
		PlayerPrefs.SetInt("UnlockEyeOfTheButtholder" + x, 0);
		PlayerPrefs.SetInt("UnlockMartianOrbMan" + x, 0);
		PlayerPrefs.SetInt("UnlockCactusOutlaw" + x, 0);
		PlayerPrefs.SetInt("UnlockUneatenCake" + x, 0);
		PlayerPrefs.SetInt("UnlockCyclopsDuckling" + x, 0);
		PlayerPrefs.SetInt("UnlockSneakySnake" + x, 0);
		PlayerPrefs.SetInt("UnlockOglebopGolem" + x, 0);
		PlayerPrefs.SetInt("UnlockWallOfCastle" + x, 0);
		PlayerPrefs.SetInt("UnlockShroomTurtle" + x, 0);
		PlayerPrefs.SetInt("UnlockLiterallyGrass" + x, 0);
		PlayerPrefs.SetInt("UnlockSpikeyFlimflam" + x, 0);
		PlayerPrefs.SetInt("UnlockDoomjelly" + x, 0);
		PlayerPrefs.SetInt("UnlockBlueEyesGoldDragon" + x, 0);
		PlayerPrefs.SetInt("UnlockKeyMold" + x, 0);
		Hint[] hints = mHints.Hints;
		foreach (Hint hint in hints)
		{
			PlayerPrefs.SetInt(hint.NPC + hint.Number + x, 0);
		}
		SceneManager.LoadScene("Kindergarten");
	}

	private IEnumerator ActivateAreYouSure(int x)
	{
		mAreYouSureOpen = true;
		ShortcutExtensions.DOScale((Transform)(object)areYouSureMenu, new Vector3(0.2f, 1.3f, 1f), 0.15f);
		TweenSettingsExtensions.SetDelay<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOScale((Transform)(object)areYouSureMenu, 1f, 0.1f), 0.15f);
		yield return null;
		switch (x)
		{
		case 1:
		{
			string text = string.Empty;
			if (!EnvironmentController.Instance.isSpanish)
			{
				switch (EnvironmentController.Instance.furthestRoom)
				{
				case Room.SchoolYard:
					text = "the school yard";
					break;
				case Room.Classroom1:
					text = "morning time";
					break;
				case Room.Office:
					text = "the principal's office";
					break;
				case Room.Cafeteria:
					text = "lunch";
					break;
				case Room.ClassroomLunch:
					text = "lunch";
					break;
				case Room.Recess:
					text = "recess";
					break;
				case Room.Lair:
					text = "the principal's lab";
					break;
				}
				areYouSureText.text = "Are you sure you want to reset your day to the start of " + text + "? All progress made since that point will be lost.";
			}
			else
			{
				switch (EnvironmentController.Instance.furthestRoom)
				{
				case Room.SchoolYard:
					text = "el patio de la escuela";
					break;
				case Room.Classroom1:
					text = "clases de la mañana";
					break;
				case Room.Office:
					text = "el oficina del director";
					break;
				case Room.Cafeteria:
					text = "almuerzo";
					break;
				case Room.ClassroomLunch:
					text = "almuerzo";
					break;
				case Room.Recess:
					text = "recreo";
					break;
				case Room.Lair:
					text = "el laboratorio del director";
					break;
				}
				areYouSureText.text = "¿Estás seguro que quieres restablecer el día al principio" + text + "? Todos los progresos realizados en el juego se perderán.";
			}
			break;
		}
		case 2:
			if (!EnvironmentController.Instance.isSpanish)
			{
				areYouSureText.text = "Are you sure you want to restart the day? You will lose all progress from today and start a new day from your bedroom.";
			}
			else
			{
				areYouSureText.text = "¿Estás seguro que quieres reiniciar el día? En este caso perderás todo el progreso del día y comenzarás un nuevo día desde tu dormitorio.";
			}
			break;
		case 6:
			if (EnvironmentController.currentRoom == Room.Bedroom)
			{
				if (!EnvironmentController.Instance.isSpanish)
				{
					areYouSureText.text = "Are you sure you want to return to the main menu?";
				}
				else
				{
					areYouSureText.text = "¿Estás seguro que quieres ir al menú principal?";
				}
			}
			else if (!EnvironmentController.Instance.isSpanish)
			{
				areYouSureText.text = "Are you sure you want to the main menu? All progress made during this day will be lost.";
			}
			else
			{
				areYouSureText.text = "¿Estás seguro que quieres ir al menú principal? Perderás todo el progreso de este día.";
			}
			break;
		}
		mYes = true;
		ShortcutExtensions.DOScale(noButton, 1f, 0.1f);
		ShortcutExtensions.DOScale(yesButton, 1.1f, 0.1f);
		((Behaviour)((Component)yesButton).GetComponentInChildren<Outline>()).enabled = true;
		((Behaviour)((Component)noButton).GetComponentInChildren<Outline>()).enabled = false;
		while (mAreYouSureOpen)
		{
			if (TCKInput.GetAxis("DPad0", AxisType.X) > 0f)
			{
				if (mYes)
				{
					mYes = false;
					ShortcutExtensions.DOScale(noButton, 1.1f, 0.1f);
					ShortcutExtensions.DOScale(yesButton, 1f, 0.1f);
					SFXManager.Instance.PlaySound("DialoguePop");
					((Behaviour)((Component)yesButton).GetComponentInChildren<Outline>()).enabled = false;
					((Behaviour)((Component)noButton).GetComponentInChildren<Outline>()).enabled = true;
					yield return (object)new WaitForSeconds(0.2f);
				}
			}
			else if (TCKInput.GetAxis("DPad0", AxisType.X) < 0f && !mYes)
			{
				mYes = true;
				ShortcutExtensions.DOScale(noButton, 1f, 0.2f);
				ShortcutExtensions.DOScale(yesButton, 1.1f, 0.2f);
				SFXManager.Instance.PlaySound("DialoguePop");
				((Behaviour)((Component)yesButton).GetComponentInChildren<Outline>()).enabled = true;
				((Behaviour)((Component)noButton).GetComponentInChildren<Outline>()).enabled = false;
				yield return (object)new WaitForSeconds(0.2f);
			}
			if (InputManager.Instance.IsInteractPressed())
			{
				SFXManager.Instance.PlaySound("Confirm");
				if (mYes)
				{
					CloseAreYouSure(backToMain: false);
					switch (x)
					{
					case 1:
						if (EnvironmentController.currentRoom != Room.Bedroom)
						{
							EnvironmentController.Instance.RestartRoom();
							DOTweenModuleUI.DOFade(((Component)this).GetComponent<Image>(), 0f, 0.2f);
						}
						else
						{
							DOTweenModuleUI.DOFade(((Component)this).GetComponent<Image>(), 1f, 0.25f);
							yield return (object)new WaitForSeconds(0.25f);
							SceneManager.LoadScene("Kindergarten");
						}
						break;
					case 2:
						DOTweenModuleUI.DOFade(((Component)this).GetComponent<Image>(), 1f, 0.25f);
						yield return (object)new WaitForSeconds(0.25f);
						SceneManager.LoadScene("Kindergarten");
						break;
					case 6:
						DOTweenModuleUI.DOFade(((Component)this).GetComponent<Image>(), 1f, 0.25f);
						yield return (object)new WaitForSeconds(0.25f);
						PlayerPrefs.Save();
						Debug.Log((object)"Progress Saved");
						SceneManager.LoadScene("TitleScreen");
						break;
					}
				}
				else
				{
					CloseAreYouSure(backToMain: true);
				}
			}
			yield return null;
		}
	}

	public void SetHint(int x)
	{
		//IL_0034: Unknown result type (might be due to invalid IL or missing references)
		//IL_0049: Unknown result type (might be due to invalid IL or missing references)
		//IL_0075: Unknown result type (might be due to invalid IL or missing references)
		if (mHintSelection == x)
		{
			return;
		}
		UnHighlightHint(mHintSelection);
		mHintSelection = x;
		HighlightHint(mHintSelection);
		((Component)hintDescription).transform.localScale = Vector3.zero;
		ShortcutExtensions.DOScale(((Component)hintDescription).transform, Vector3.one, 0.2f);
		DOTweenModuleUI.DOColor(hintBackground, ((Graphic)((Component)hintGrid.GetChild(mHintSelection)).GetComponent<Image>()).color, 0.2f);
		SFXManager.Instance.PlaySound("DialoguePop");
		if (mHints.Hints[mHintSelection].Unlocked)
		{
			hintDescription.text = mHints.Hints[mHintSelection].Description;
			if (!mHints.Hints[mHintSelection].Viewed)
			{
				Hint hint = mHints.Hints[mHintSelection];
				hint.Viewed = true;
				((Behaviour)((Component)hintGrid.GetChild(mHintSelection).GetChild(3)).GetComponent<Text>()).enabled = false;
				PlayerPrefs.SetInt(hint.NPC + hint.Number + EnvironmentController.Instance.GetFileModifier(), 2);
			}
		}
		else
		{
			hintDescription.text = "???";
		}
	}

	private IEnumerator RunHintsMenu()
	{
		mHintsOpen = true;
		ShortcutExtensions.DOScale(hintsPanel, new Vector3(0.2f, 1.3f, 1f), 0.15f);
		TweenSettingsExtensions.OnComplete<TweenerCore<Vector3, Vector3, VectorOptions>>(TweenSettingsExtensions.SetDelay<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOScale(hintsPanel, 1f, 0.1f), 0.15f), (TweenCallback)delegate
		{
			((Component)hintsPanel).GetComponent<CanvasGroup>().blocksRaycasts = true;
		});
		mHintSelection = 0;
		HighlightHint(0);
		hintDescription.text = mHints.Hints[mHintSelection].Description;
		while (mHintsOpen)
		{
			float axis = TCKInput.GetAxis("DPad0", AxisType.X);
			float axis2 = TCKInput.GetAxis("DPad0", AxisType.Y);
			if (axis != 0f || axis2 != 0f)
			{
				UnHighlightHint(mHintSelection);
				if (axis > 0f && mHintSelection < mHints.Hints.Length - 1)
				{
					mHintSelection++;
				}
				else if (axis < 0f && mHintSelection > 0)
				{
					mHintSelection--;
				}
				else if (axis2 > 0f && mHintSelection > 14)
				{
					mHintSelection -= 15;
				}
				else if (axis2 < 0f && mHintSelection < mHints.Hints.Length - 15)
				{
					mHintSelection += 15;
				}
				HighlightHint(mHintSelection);
				((Component)hintDescription).transform.localScale = Vector3.zero;
				ShortcutExtensions.DOScale(((Component)hintDescription).transform, Vector3.one, 0.2f);
				DOTweenModuleUI.DOColor(hintBackground, ((Graphic)((Component)hintGrid.GetChild(mHintSelection)).GetComponent<Image>()).color, 0.2f);
				SFXManager.Instance.PlaySound("DialoguePop");
				if (mHints.Hints[mHintSelection].Unlocked)
				{
					hintDescription.text = mHints.Hints[mHintSelection].Description;
					if (!mHints.Hints[mHintSelection].Viewed)
					{
						Hint hint = mHints.Hints[mHintSelection];
						hint.Viewed = true;
						((Behaviour)((Component)hintGrid.GetChild(mHintSelection).GetChild(3)).GetComponent<Text>()).enabled = false;
						PlayerPrefs.SetInt(hint.NPC + hint.Number + EnvironmentController.Instance.GetFileModifier(), 2);
					}
				}
				else
				{
					hintDescription.text = "???";
				}
				yield return (object)new WaitForSeconds(0.2f);
			}
			if (InputManager.Instance.IsInteractPressed() || InputManager.Instance.IsPausePressed())
			{
				((Component)hintsPanel).GetComponent<CanvasGroup>().blocksRaycasts = false;
				UnHighlightHint(mHintSelection);
				SFXManager.Instance.PlaySound("Confirm");
				ShortcutExtensions.DOScale(hintsPanel, new Vector3(0.2f, 1.3f, 1f), 0.15f);
				TweenSettingsExtensions.SetDelay<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOScale(hintsPanel, 0f, 0.1f), 0.15f);
				yield return (object)new WaitForSeconds(0.2f);
				mHintsOpen = false;
				OpenPauseMenu();
			}
			yield return null;
		}
		((Component)hintsPanel).GetComponent<CanvasGroup>().blocksRaycasts = false;
	}

	public void SetMainOption(int x)
	{
		SFXManager.Instance.PlaySound("DialoguePop");
		UnHighlightWindow(mainOptionsButtons.GetChild(mOptionSelection));
		mOptionSelection = x;
		HighlightWindow(mainOptionsButtons.GetChild(mOptionSelection), 1.1f);
	}

	private IEnumerator RunOptionsMainMenu()
	{
		mMainOptionsOpen = true;
		ShortcutExtensions.DOScale(mainOptionsPanel, new Vector3(0.2f, 1.3f, 1f), 0.15f);
		TweenSettingsExtensions.OnComplete<TweenerCore<Vector3, Vector3, VectorOptions>>(TweenSettingsExtensions.SetDelay<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOScale(mainOptionsPanel, 1f, 0.1f), 0.15f), (TweenCallback)delegate
		{
			((Component)mainOptionsPanel).GetComponent<CanvasGroup>().blocksRaycasts = true;
		});
		((MonoBehaviour)this).StartCoroutine(WaitForOptionsConfirm());
		Transform[] oWindows = (Transform[])(object)new Transform[5];
		for (int num = 0; num < 5; num++)
		{
			oWindows[num] = mainOptionsButtons.GetChild(num);
		}
		mOptionSelection = 0;
		HighlightWindow(oWindows[0]);
		while (mMainOptionsOpen)
		{
			float y = TCKInput.GetAxis("DPad0", AxisType.Y);
			if (y > 0f && mOptionSelection > 0)
			{
				SFXManager.Instance.PlaySound("DialoguePop");
				UnHighlightWindow(oWindows[mOptionSelection]);
				mOptionSelection--;
				HighlightWindow(oWindows[mOptionSelection], 1.1f);
				yield return (object)new WaitForSeconds(0.25f);
			}
			if (y < 0f && mOptionSelection < 4)
			{
				SFXManager.Instance.PlaySound("DialoguePop");
				UnHighlightWindow(oWindows[mOptionSelection]);
				mOptionSelection++;
				HighlightWindow(oWindows[mOptionSelection], 1.1f);
				yield return (object)new WaitForSeconds(0.25f);
			}
			yield return null;
		}
		((Component)mainOptionsPanel).GetComponent<CanvasGroup>().blocksRaycasts = false;
		UnHighlightWindow(oWindows[mOptionSelection]);
	}

	private IEnumerator WaitForOptionsConfirm()
	{
		while (mMainOptionsOpen)
		{
			if (InputManager.Instance.IsInteractPressed())
			{
				ShortcutExtensions.DOScale(mainOptionsPanel, new Vector3(0.2f, 1.3f, 1f), 0.15f);
				TweenSettingsExtensions.SetDelay<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOScale(mainOptionsPanel, 0f, 0.1f), 0.15f);
				SFXManager.Instance.PlaySound("Confirm");
				((Component)mainOptionsPanel).GetComponent<CanvasGroup>().blocksRaycasts = false;
				yield return (object)new WaitForSeconds(0.2f);
				mMainOptionsOpen = false;
				if (mOptionSelection == 0)
				{
					((MonoBehaviour)this).StartCoroutine(RunControlOptionsMenu());
				}
				else if (mOptionSelection == 1)
				{
					((MonoBehaviour)this).StartCoroutine(RunVideoOptionsMenu());
				}
				else if (mOptionSelection == 2)
				{
					((MonoBehaviour)this).StartCoroutine(RunAudioOptionsMenu());
				}
				else if (mOptionSelection == 3)
				{
					((MonoBehaviour)this).StartCoroutine(RunAreYouSureEraseData());
				}
				else
				{
					OpenPauseMenu();
				}
			}
			if (InputManager.Instance.IsPausePressed())
			{
				ShortcutExtensions.DOScale(mainOptionsPanel, new Vector3(0.2f, 1.3f, 1f), 0.15f);
				TweenSettingsExtensions.SetDelay<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOScale(mainOptionsPanel, 0f, 0.1f), 0.15f);
				SFXManager.Instance.PlaySound("Confirm");
				((Component)mainOptionsPanel).GetComponent<CanvasGroup>().blocksRaycasts = false;
				yield return (object)new WaitForSeconds(0.2f);
				mMainOptionsOpen = false;
				OpenPauseMenu();
			}
			yield return null;
		}
	}

	public void SetControlBox(int x)
	{
		if (!mWaitReconfigure)
		{
			SFXManager.Instance.PlaySound("DialoguePop");
			UnHighlightWindow(controlBoxes[mControlSelection]);
			mControlSelection = x;
			HighlightWindow(controlBoxes[mControlSelection], 1.1f);
		}
	}

	private IEnumerator RunControlOptionsMenu()
	{
		mControlOptionsOpen = true;
		ShortcutExtensions.DOScale(controlOptionsPanel, new Vector3(0.2f, 1.3f, 1f), 0.15f);
		TweenSettingsExtensions.OnComplete<TweenerCore<Vector3, Vector3, VectorOptions>>(TweenSettingsExtensions.SetDelay<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOScale(controlOptionsPanel, 1f, 0.1f), 0.15f), (TweenCallback)delegate
		{
			((Component)controlOptionsPanel).GetComponent<CanvasGroup>().blocksRaycasts = true;
		});
		mControlSelection = 0;
		HighlightWindow(controlBoxes[0]);
		string[] inputStrings = InputManager.Instance.GetInputStrings();
		for (int num = 0; num < 8; num++)
		{
			if (num % 2 == 0)
			{
				((Component)controlBoxes[num]).GetComponentInChildren<Text>().text = inputStrings[num];
			}
			else
			{
				((Component)controlBoxes[num]).GetComponentInChildren<Text>().text = inputStrings[num];
			}
		}
		while (mControlOptionsOpen)
		{
			float x = TCKInput.GetAxis("DPad0", AxisType.X);
			float y = TCKInput.GetAxis("DPad0", AxisType.Y);
			if (x > 0f && mControlSelection % 2 == 0 && mControlSelection != 8)
			{
				SFXManager.Instance.PlaySound("DialoguePop");
				UnHighlightWindow(controlBoxes[mControlSelection]);
				mControlSelection++;
				HighlightWindow(controlBoxes[mControlSelection], 1.1f);
				yield return (object)new WaitForSeconds(0.2f);
			}
			if (x < 0f && mControlSelection % 2 == 1 && mControlSelection != 8)
			{
				SFXManager.Instance.PlaySound("DialoguePop");
				UnHighlightWindow(controlBoxes[mControlSelection]);
				mControlSelection--;
				HighlightWindow(controlBoxes[mControlSelection], 1.1f);
				yield return (object)new WaitForSeconds(0.2f);
			}
			if (y > 0f && mControlSelection > 1)
			{
				SFXManager.Instance.PlaySound("DialoguePop");
				UnHighlightWindow(controlBoxes[mControlSelection]);
				mControlSelection -= 2;
				HighlightWindow(controlBoxes[mControlSelection], 1.1f);
				yield return (object)new WaitForSeconds(0.2f);
			}
			if (y < 0f)
			{
				if (mControlSelection < 7)
				{
					SFXManager.Instance.PlaySound("DialoguePop");
					UnHighlightWindow(controlBoxes[mControlSelection]);
					mControlSelection += 2;
					HighlightWindow(controlBoxes[mControlSelection], 1.1f);
					yield return (object)new WaitForSeconds(0.2f);
				}
				else if (mControlSelection == 7)
				{
					SFXManager.Instance.PlaySound("DialoguePop");
					UnHighlightWindow(controlBoxes[mControlSelection]);
					mControlSelection++;
					HighlightWindow(controlBoxes[mControlSelection], 1.1f);
					yield return (object)new WaitForSeconds(0.2f);
				}
			}
			if (InputManager.Instance.IsInteractPressed() && !mWaitReconfigure)
			{
				if (mControlSelection % 2 == 0)
				{
					if (mControlSelection < 8)
					{
						mWaitReconfigure = true;
						((MonoBehaviour)this).StartCoroutine(WaitToReconfigureKey(mControlSelection));
						while (mWaitReconfigure)
						{
							yield return null;
						}
						yield return null;
					}
					else
					{
						SFXManager.Instance.PlaySound("Confirm");
						InputManager.Instance.ApplyCustomInputs();
						ShortcutExtensions.DOScale(controlOptionsPanel, new Vector3(0.2f, 1.3f, 1f), 0.15f);
						TweenSettingsExtensions.SetDelay<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOScale(controlOptionsPanel, 0f, 0.1f), 0.15f);
						yield return (object)new WaitForSeconds(0.2f);
						mControlOptionsOpen = false;
						((MonoBehaviour)this).StartCoroutine(RunOptionsMainMenu());
					}
				}
				else
				{
					mWaitReconfigure = true;
					((MonoBehaviour)this).StartCoroutine(WaitToReconfigureButton(mControlSelection));
					while (mWaitReconfigure)
					{
						yield return null;
					}
					yield return null;
				}
			}
			if (InputManager.Instance.IsPausePressed())
			{
				InputManager.Instance.GetCustomInputs();
				SFXManager.Instance.PlaySound("Confirm");
				ShortcutExtensions.DOScale(controlOptionsPanel, new Vector3(0.2f, 1.3f, 1f), 0.15f);
				TweenSettingsExtensions.SetDelay<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOScale(controlOptionsPanel, 0f, 0.1f), 0.15f);
				yield return (object)new WaitForSeconds(0.2f);
				mControlOptionsOpen = false;
				((MonoBehaviour)this).StartCoroutine(RunOptionsMainMenu());
			}
			yield return null;
		}
		((Component)controlOptionsPanel).GetComponent<CanvasGroup>().blocksRaycasts = false;
		UnHighlightWindow(controlBoxes[mControlSelection]);
	}

	private IEnumerator WaitToReconfigureKey(int sel)
	{
		HighlightWindowGreen(controlBoxes[sel], 1.1f);
		yield return null;
		while (InputManager.Instance.IsInteractHeld())
		{
			yield return null;
		}
		yield return null;
		while ((int)keyEvent.keyCode == 0)
		{
			yield return null;
		}
		string text = ((object)keyEvent.keyCode/*cast due to .constrained prefix*/).ToString();
		switch (text)
		{
		default:
			if (!(text.ToUpper() == InputManager.Instance.interactButtonKeyboard.ToUpper()) && !(text.ToUpper() == InputManager.Instance.actionButtonKeyboard.ToUpper()) && !(text.ToUpper() == InputManager.Instance.plannerButtonKeyboard.ToUpper()) && !(text.ToUpper() == InputManager.Instance.pauseButtonKeyboard.ToUpper()))
			{
				switch (sel)
				{
				case 0:
					InputManager.Instance.ReconfigureInteractKeyboard(text);
					break;
				case 2:
					InputManager.Instance.ReconfigurePlannerKeyboard(text);
					break;
				case 4:
					InputManager.Instance.ReconfigureActionKeyboard(text);
					break;
				case 6:
					InputManager.Instance.ReconfigurePauseKeyboard(text);
					break;
				}
				SFXManager.Instance.PlaySound("GetItem");
				((Component)controlBoxes[sel]).GetComponentInChildren<Text>().text = text;
				HighlightWindow(controlBoxes[sel], 1.1f);
				mWaitReconfigure = false;
				yield break;
			}
			break;
		case "W":
		case "S":
		case "A":
		case "D":
			break;
		}
		SFXManager.Instance.PlaySound("Failed");
		HighlightWindow(controlBoxes[sel], 1.1f);
		mWaitReconfigure = false;
		yield return (object)new WaitForSeconds(0.2f);
	}

	private IEnumerator WaitToReconfigureButton(int sel)
	{
		HighlightWindowGreen(controlBoxes[sel], 1.1f);
		while (InputManager.Instance.IsInteractHeld())
		{
			yield return null;
		}
		yield return null;
		int x = -1;
		while (x == -1)
		{
			for (int i = 0; i < 16; i++)
			{
				if (Input.GetButtonDown("Button " + i))
				{
					x = i;
				}
			}
			if ((int)keyEvent.keyCode != 0)
			{
				SFXManager.Instance.PlaySound("Failed");
				HighlightWindow(controlBoxes[sel], 1.1f);
				mWaitReconfigure = false;
				yield break;
			}
			yield return null;
		}
		string text = "Button " + x;
		if (text == InputManager.Instance.interactButtonController.ToUpper() || text == InputManager.Instance.actionButtonController.ToUpper() || text == InputManager.Instance.plannerButtonController.ToUpper() || text == InputManager.Instance.pauseButtonController.ToUpper())
		{
			SFXManager.Instance.PlaySound("Failed");
			HighlightWindow(controlBoxes[sel], 1.1f);
			mWaitReconfigure = false;
			yield break;
		}
		switch (sel)
		{
		case 1:
			InputManager.Instance.ReconfigureInteractController(text);
			break;
		case 3:
			InputManager.Instance.ReconfigurePlannerController(text);
			break;
		case 5:
			InputManager.Instance.ReconfigureActionController(text);
			break;
		case 7:
			InputManager.Instance.ReconfigurePauseController(text);
			break;
		}
		SFXManager.Instance.PlaySound("GetItem");
		((Component)controlBoxes[sel]).GetComponentInChildren<Text>().text = text;
		HighlightWindow(controlBoxes[sel], 1.1f);
		yield return (object)new WaitForSeconds(0.5f);
		mWaitReconfigure = false;
	}

	public void SetVideoOption(bool right)
	{
		//IL_02e2: Unknown result type (might be due to invalid IL or missing references)
		//IL_0341: Unknown result type (might be due to invalid IL or missing references)
		//IL_0086: Unknown result type (might be due to invalid IL or missing references)
		//IL_008b: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ac: Unknown result type (might be due to invalid IL or missing references)
		//IL_00b1: Unknown result type (might be due to invalid IL or missing references)
		//IL_00ed: Unknown result type (might be due to invalid IL or missing references)
		//IL_014c: Unknown result type (might be due to invalid IL or missing references)
		//IL_01f5: Unknown result type (might be due to invalid IL or missing references)
		//IL_0254: Unknown result type (might be due to invalid IL or missing references)
		Text component = GameObject.Find("ScreenSizeText").GetComponent<Text>();
		Text component2 = GameObject.Find("WindowedModeText").GetComponent<Text>();
		if (mVideoSelection == 0)
		{
			if (right)
			{
				if (mCurrentRes < mAvailableResolutions.Count - 1)
				{
					mCurrentRes++;
				}
			}
			else if (mCurrentRes > 0)
			{
				mCurrentRes--;
			}
			SFXManager.Instance.PlaySound("DialoguePop");
			Resolution val = mAvailableResolutions[mCurrentRes];
			string text = ((Resolution)(ref val)).width.ToString();
			val = mAvailableResolutions[mCurrentRes];
			component.text = text + " x " + ((Resolution)(ref val)).height;
			ShortcutExtensions.DOKill((Component)(object)((Component)component).transform, false);
			((Component)component).transform.localPosition = new Vector3(0f, -10f, 0f);
			ShortcutExtensions.DOLocalMoveY(((Component)component).transform, 0f, 0.1f, false);
			TweenSettingsExtensions.SetDelay<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOLocalMoveY(((Component)component).transform, -10f, 0.1f, false), 0.1f);
			ShortcutExtensions.DOKill((Component)(object)((Component)component).transform.parent, false);
			((Component)component).transform.parent.localScale = Vector3.one;
			ShortcutExtensions.DOScale(((Component)component).transform.parent, 1.05f, 0.1f);
			TweenSettingsExtensions.SetDelay<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOScale(((Component)component).transform.parent, 1f, 0.1f), 0.1f);
		}
		else
		{
			if (mVideoSelection != 1)
			{
				return;
			}
			if (right)
			{
				if (mIsFullScreen)
				{
					SFXManager.Instance.PlaySound("DialoguePop");
					mIsFullScreen = false;
					component2.text = "On";
					ShortcutExtensions.DOKill((Component)(object)((Component)component2).transform, false);
					((Component)component2).transform.localPosition = new Vector3(0f, -10f, 0f);
					ShortcutExtensions.DOLocalMoveY(((Component)component2).transform, 0f, 0.1f, false);
					TweenSettingsExtensions.SetDelay<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOLocalMoveY(((Component)component2).transform, -10f, 0.1f, false), 0.1f);
					ShortcutExtensions.DOKill((Component)(object)((Component)component2).transform.parent, false);
					((Component)component2).transform.parent.localScale = Vector3.one;
					ShortcutExtensions.DOScale(((Component)component2).transform.parent, 1.05f, 0.1f);
					TweenSettingsExtensions.SetDelay<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOScale(((Component)component2).transform.parent, 1f, 0.1f), 0.1f);
				}
			}
			else
			{
				SFXManager.Instance.PlaySound("DialoguePop");
				mIsFullScreen = true;
				component2.text = "Off";
				ShortcutExtensions.DOKill((Component)(object)((Component)component2).transform, false);
				((Component)component2).transform.localPosition = new Vector3(0f, -10f, 0f);
				ShortcutExtensions.DOLocalMoveY(((Component)component2).transform, 0f, 0.1f, false);
				TweenSettingsExtensions.SetDelay<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOLocalMoveY(((Component)component2).transform, -10f, 0.1f, false), 0.1f);
				ShortcutExtensions.DOKill((Component)(object)((Component)component2).transform.parent, false);
				((Component)component2).transform.parent.localScale = Vector3.one;
				ShortcutExtensions.DOScale(((Component)component2).transform.parent, 1.05f, 0.1f);
				TweenSettingsExtensions.SetDelay<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOScale(((Component)component2).transform.parent, 1f, 0.1f), 0.1f);
			}
		}
	}

	private IEnumerator RunVideoOptionsMenu()
	{
		mVideoOptionsOpen = true;
		ShortcutExtensions.DOScale(videoOptionsPanel, new Vector3(0.2f, 1.3f, 1f), 0.15f);
		TweenSettingsExtensions.OnComplete<TweenerCore<Vector3, Vector3, VectorOptions>>(TweenSettingsExtensions.SetDelay<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOScale(videoOptionsPanel, 1f, 0.1f), 0.15f), (TweenCallback)delegate
		{
			((Component)videoOptionsPanel).GetComponent<CanvasGroup>().blocksRaycasts = true;
		});
		mVideoSelection = 0;
		int startingRes = mCurrentRes;
		Text resText = GameObject.Find("ScreenSizeText").GetComponent<Text>();
		Text winText = GameObject.Find("WindowedModeText").GetComponent<Text>();
		Resolution val = mAvailableResolutions[mCurrentRes];
		string text = ((Resolution)(ref val)).width.ToString();
		val = mAvailableResolutions[mCurrentRes];
		resText.text = text + " x " + ((Resolution)(ref val)).height;
		mIsFullScreen = Screen.fullScreen;
		if (Screen.fullScreen)
		{
			winText.text = "Off";
		}
		else
		{
			winText.text = "On";
		}
		Transform[] oWindows = (Transform[])(object)new Transform[3];
		Transform transform = GameObject.Find("VideoOptionsHolder").transform;
		for (int num = 0; num < 3; num++)
		{
			oWindows[num] = transform.GetChild(num + 1);
		}
		HighlightWindow(oWindows[mVideoSelection]);
		while (mVideoOptionsOpen)
		{
			yield return null;
			float y = TCKInput.GetAxis("DPad0", AxisType.Y);
			float x = TCKInput.GetAxis("DPad0", AxisType.X);
			if (x > 0f)
			{
				if (mVideoSelection == 0)
				{
					if (mCurrentRes < mAvailableResolutions.Count - 1)
					{
						SFXManager.Instance.PlaySound("DialoguePop");
						mCurrentRes++;
						val = mAvailableResolutions[mCurrentRes];
						string text2 = ((Resolution)(ref val)).width.ToString();
						val = mAvailableResolutions[mCurrentRes];
						resText.text = text2 + " x " + ((Resolution)(ref val)).height;
						ShortcutExtensions.DOKill((Component)(object)((Component)resText).transform, false);
						((Component)resText).transform.localPosition = new Vector3(0f, -10f, 0f);
						ShortcutExtensions.DOLocalMoveY(((Component)resText).transform, 0f, 0.1f, false);
						TweenSettingsExtensions.SetDelay<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOLocalMoveY(((Component)resText).transform, -10f, 0.1f, false), 0.1f);
						ShortcutExtensions.DOKill((Component)(object)((Component)resText).transform.parent, false);
						((Component)resText).transform.parent.localScale = Vector3.one;
						ShortcutExtensions.DOScale(((Component)resText).transform.parent, 1.05f, 0.1f);
						TweenSettingsExtensions.SetDelay<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOScale(((Component)resText).transform.parent, 1f, 0.1f), 0.1f);
						yield return (object)new WaitForSeconds(0.2f);
					}
				}
				else if (mVideoSelection == 1 && mIsFullScreen)
				{
					SFXManager.Instance.PlaySound("DialoguePop");
					mIsFullScreen = false;
					winText.text = "On";
					ShortcutExtensions.DOKill((Component)(object)((Component)winText).transform, false);
					((Component)winText).transform.localPosition = new Vector3(0f, -10f, 0f);
					ShortcutExtensions.DOLocalMoveY(((Component)winText).transform, 0f, 0.1f, false);
					TweenSettingsExtensions.SetDelay<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOLocalMoveY(((Component)winText).transform, -10f, 0.1f, false), 0.1f);
					ShortcutExtensions.DOKill((Component)(object)((Component)winText).transform.parent, false);
					((Component)winText).transform.parent.localScale = Vector3.one;
					ShortcutExtensions.DOScale(((Component)winText).transform.parent, 1.05f, 0.1f);
					TweenSettingsExtensions.SetDelay<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOScale(((Component)winText).transform.parent, 1f, 0.1f), 0.1f);
					yield return (object)new WaitForSeconds(0.2f);
				}
			}
			if (x < 0f)
			{
				if (mVideoSelection == 0)
				{
					if (mCurrentRes > 0)
					{
						SFXManager.Instance.PlaySound("DialoguePop");
						mCurrentRes--;
						val = mAvailableResolutions[mCurrentRes];
						string text3 = ((Resolution)(ref val)).width.ToString();
						val = mAvailableResolutions[mCurrentRes];
						resText.text = text3 + " x " + ((Resolution)(ref val)).height;
						ShortcutExtensions.DOKill((Component)(object)((Component)resText).transform, false);
						((Component)resText).transform.localPosition = new Vector3(0f, -10f, 0f);
						ShortcutExtensions.DOLocalMoveY(((Component)resText).transform, 0f, 0.1f, false);
						TweenSettingsExtensions.SetDelay<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOLocalMoveY(((Component)resText).transform, -10f, 0.1f, false), 0.1f);
						ShortcutExtensions.DOKill((Component)(object)((Component)resText).transform.parent, false);
						((Component)resText).transform.parent.localScale = Vector3.one;
						ShortcutExtensions.DOScale(((Component)resText).transform.parent, 1.05f, 0.1f);
						TweenSettingsExtensions.SetDelay<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOScale(((Component)resText).transform.parent, 1f, 0.1f), 0.1f);
						yield return (object)new WaitForSeconds(0.2f);
					}
				}
				else if (mVideoSelection == 1 && !mIsFullScreen)
				{
					SFXManager.Instance.PlaySound("DialoguePop");
					mIsFullScreen = true;
					winText.text = "Off";
					ShortcutExtensions.DOKill((Component)(object)((Component)winText).transform, false);
					((Component)winText).transform.localPosition = new Vector3(0f, -10f, 0f);
					ShortcutExtensions.DOLocalMoveY(((Component)winText).transform, 0f, 0.1f, false);
					TweenSettingsExtensions.SetDelay<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOLocalMoveY(((Component)winText).transform, -10f, 0.1f, false), 0.1f);
					ShortcutExtensions.DOKill((Component)(object)((Component)winText).transform.parent, false);
					((Component)winText).transform.parent.localScale = Vector3.one;
					ShortcutExtensions.DOScale(((Component)winText).transform.parent, 1.05f, 0.1f);
					TweenSettingsExtensions.SetDelay<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOScale(((Component)winText).transform.parent, 1f, 0.1f), 0.1f);
					yield return (object)new WaitForSeconds(0.2f);
				}
			}
			if (y > 0f)
			{
				if (mVideoSelection > 0)
				{
					SFXManager.Instance.PlaySound("DialoguePop");
					UnHighlightWindow(oWindows[mVideoSelection]);
					mVideoSelection--;
					HighlightWindow(oWindows[mVideoSelection]);
				}
				yield return (object)new WaitForSeconds(0.25f);
			}
			if (y < 0f)
			{
				if (mVideoSelection < oWindows.Length - 1)
				{
					SFXManager.Instance.PlaySound("DialoguePop");
					UnHighlightWindow(oWindows[mVideoSelection]);
					mVideoSelection++;
					HighlightWindow(oWindows[mVideoSelection]);
				}
				yield return (object)new WaitForSeconds(0.25f);
			}
			if (InputManager.Instance.IsInteractPressed() && mVideoSelection == 2)
			{
				SFXManager.Instance.PlaySound("Confirm");
				ShortcutExtensions.DOScale(videoOptionsPanel, new Vector3(0.2f, 1.3f, 1f), 0.15f);
				TweenSettingsExtensions.SetDelay<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOScale(videoOptionsPanel, 0f, 0.1f), 0.15f);
				if (startingRes != mCurrentRes)
				{
					val = mAvailableResolutions[mCurrentRes];
					int width = ((Resolution)(ref val)).width;
					val = mAvailableResolutions[mCurrentRes];
					Screen.SetResolution(width, ((Resolution)(ref val)).height, true);
					CameraFollow cameraFollow = Object.FindObjectOfType<CameraFollow>();
					val = mAvailableResolutions[mCurrentRes];
					float num2 = ((Resolution)(ref val)).width;
					val = mAvailableResolutions[mCurrentRes];
					cameraFollow.RefreshScreen(num2 / (float)((Resolution)(ref val)).height);
				}
				Screen.fullScreen = mIsFullScreen;
				yield return (object)new WaitForSeconds(0.2f);
				((MonoBehaviour)this).StartCoroutine(RunOptionsMainMenu());
				mVideoOptionsOpen = false;
				UnHighlightWindow(oWindows[mVideoSelection]);
			}
			if (InputManager.Instance.IsPausePressed() || InputManager.Instance.IsPlannerPressed())
			{
				SFXManager.Instance.PlaySound("Confirm");
				ShortcutExtensions.DOScale(videoOptionsPanel, new Vector3(0.2f, 1.3f, 1f), 0.15f);
				TweenSettingsExtensions.SetDelay<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOScale(videoOptionsPanel, 0f, 0.1f), 0.15f);
				yield return (object)new WaitForSeconds(0.2f);
				((MonoBehaviour)this).StartCoroutine(RunOptionsMainMenu());
				mVideoOptionsOpen = false;
				UnHighlightWindow(oWindows[mVideoSelection]);
			}
		}
		((Component)videoOptionsPanel).GetComponent<CanvasGroup>().blocksRaycasts = false;
	}

	public void SetVideoSelection(int x)
	{
		if (mVideoSelection != x)
		{
			Transform[] array = (Transform[])(object)new Transform[3];
			Transform transform = GameObject.Find("VideoOptionsHolder").transform;
			for (int i = 0; i < 3; i++)
			{
				array[i] = transform.GetChild(i + 1);
			}
			SFXManager.Instance.PlaySound("DialoguePop");
			UnHighlightWindow(array[mVideoSelection]);
			mVideoSelection = x;
			HighlightWindow(array[mVideoSelection]);
		}
	}

	public void SetAudioSelection(int x)
	{
		if (mAudioSelection != x)
		{
			Transform[] array = (Transform[])(object)new Transform[3];
			Transform transform = GameObject.Find("AudioOptionsHolder").transform;
			for (int i = 0; i < 3; i++)
			{
				array[i] = transform.GetChild(i + 1);
			}
			_ = GameObject.Find("MusicVolumeBox").transform;
			_ = GameObject.Find("EffectsVolumeBox").transform;
			SFXManager.Instance.PlaySound("DialoguePop");
			UnHighlightWindow(array[mAudioSelection]);
			mAudioSelection = x;
			HighlightWindow(array[mAudioSelection]);
		}
	}

	public void SetMusicVolume(bool x)
	{
		//IL_00c1: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Unknown result type (might be due to invalid IL or missing references)
		if (x)
		{
			if (mMusicVolume < 1f)
			{
				mMusicVolume += 0.1f;
				if (mMusicVolume > 1f)
				{
					mMusicVolume = 1f;
				}
				mMusicBox.localScale = new Vector3(mMusicVolume, 1f, 0f);
				SFXManager.Instance.SetVolumes(mMusicVolume, mEffectsVolume);
			}
		}
		else if (mMusicVolume > 0f)
		{
			mMusicVolume -= 0.1f;
			if (mMusicVolume < 0f)
			{
				mMusicVolume = 0f;
			}
			mMusicBox.localScale = new Vector3(mMusicVolume, 1f, 0f);
			SFXManager.Instance.SetVolumes(mMusicVolume, mEffectsVolume);
		}
	}

	public void SetEffectsVolume(bool x)
	{
		//IL_00ce: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		if (x)
		{
			if (mEffectsVolume < 2f)
			{
				mEffectsVolume += 0.1f;
				if (mEffectsVolume > 2f)
				{
					mEffectsVolume = 2f;
				}
				mEffectsVolumeBox.localScale = new Vector3(mEffectsVolume / 2f, 1f, 0f);
				SFXManager.Instance.SetVolumes(mMusicVolume, mEffectsVolume);
			}
		}
		else if (mEffectsVolume > 0f)
		{
			mEffectsVolume -= 0.1f;
			if (mEffectsVolume < 0f)
			{
				mEffectsVolume = 0f;
			}
			mEffectsVolumeBox.localScale = new Vector3(mEffectsVolume / 2f, 1f, 0f);
			SFXManager.Instance.SetVolumes(mMusicVolume, mEffectsVolume);
		}
		SFXManager.Instance.PlaySound("DialoguePop");
	}

	private IEnumerator RunAudioOptionsMenu()
	{
		mAudioOptionsOpen = true;
		ShortcutExtensions.DOScale(audioOptionsPanel, new Vector3(0.2f, 1.3f, 1f), 0.15f);
		TweenSettingsExtensions.OnComplete<TweenerCore<Vector3, Vector3, VectorOptions>>(TweenSettingsExtensions.SetDelay<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOScale(audioOptionsPanel, 1f, 0.1f), 0.15f), (TweenCallback)delegate
		{
			((Component)audioOptionsPanel).GetComponent<CanvasGroup>().blocksRaycasts = true;
		});
		mAudioSelection = 0;
		mMusicVolume = PlayerPrefs.GetFloat("MusicVolume", 0.5f);
		mEffectsVolume = PlayerPrefs.GetFloat("EffectsVolume", 1f);
		float storeMusicVolume = mMusicVolume;
		float storeEffectsVolume = mEffectsVolume;
		Transform[] oWindows = (Transform[])(object)new Transform[3];
		Transform transform = GameObject.Find("AudioOptionsHolder").transform;
		mMusicBox.localScale = new Vector3(mMusicVolume, 1f);
		mEffectsVolumeBox.localScale = new Vector3(mEffectsVolume / 2f, 1f);
		for (int num = 0; num < 3; num++)
		{
			oWindows[num] = transform.GetChild(num + 1);
		}
		HighlightWindow(oWindows[0]);
		while (mAudioOptionsOpen)
		{
			yield return null;
			float y = TCKInput.GetAxis("DPad0", AxisType.Y);
			float axis = TCKInput.GetAxis("DPad0", AxisType.X);
			if (axis > 0f)
			{
				if (mAudioSelection == 0 && mMusicVolume < 1f)
				{
					mMusicVolume += 0.01f;
					mMusicBox.localScale = new Vector3(mMusicVolume, 1f, 0f);
					SFXManager.Instance.SetVolumes(mMusicVolume, mEffectsVolume);
					yield return (object)new WaitForSeconds(0.025f);
				}
				if (mAudioSelection == 1 && mEffectsVolume < 2f)
				{
					SFXManager.Instance.PlaySound("DialoguePop");
					mEffectsVolume += 0.1f;
					mEffectsVolumeBox.localScale = new Vector3(mEffectsVolume / 2f, 1f, 0f);
					SFXManager.Instance.SetVolumes(mMusicVolume, mEffectsVolume);
					yield return (object)new WaitForSeconds(0.1f);
				}
			}
			else if (axis < 0f)
			{
				if (mAudioSelection == 0 && mMusicVolume > 0f)
				{
					mMusicVolume -= 0.01f;
					mMusicBox.localScale = new Vector3(mMusicVolume, 1f, 0f);
					SFXManager.Instance.SetVolumes(mMusicVolume, mEffectsVolume);
					yield return (object)new WaitForSeconds(0.05f);
				}
				if (mAudioSelection == 1 && mEffectsVolume > 0f)
				{
					SFXManager.Instance.PlaySound("DialoguePop");
					mEffectsVolume -= 0.1f;
					mEffectsVolumeBox.localScale = new Vector3(mEffectsVolume / 2f, 1f, 0f);
					SFXManager.Instance.SetVolumes(mMusicVolume, mEffectsVolume);
					yield return (object)new WaitForSeconds(0.15f);
				}
			}
			if (y > 0f)
			{
				if (mAudioSelection > 0)
				{
					SFXManager.Instance.PlaySound("DialoguePop");
					UnHighlightWindow(oWindows[mAudioSelection]);
					mAudioSelection--;
					HighlightWindow(oWindows[mAudioSelection]);
				}
				yield return (object)new WaitForSeconds(0.25f);
			}
			if (y < 0f)
			{
				if (mAudioSelection < oWindows.Length - 1)
				{
					SFXManager.Instance.PlaySound("DialoguePop");
					UnHighlightWindow(oWindows[mAudioSelection]);
					mAudioSelection++;
					HighlightWindow(oWindows[mAudioSelection]);
				}
				yield return (object)new WaitForSeconds(0.25f);
			}
			if (InputManager.Instance.IsInteractPressed() && mAudioSelection == 2)
			{
				SFXManager.Instance.PlaySound("Confirm");
				ShortcutExtensions.DOScale(audioOptionsPanel, new Vector3(0.2f, 1.3f, 1f), 0.15f);
				TweenSettingsExtensions.SetDelay<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOScale(audioOptionsPanel, 0f, 0.1f), 0.15f);
				if (mMusicVolume != storeMusicVolume)
				{
					PlayerPrefs.SetFloat("MusicVolume", mMusicVolume);
				}
				if (mEffectsVolume != storeEffectsVolume)
				{
					PlayerPrefs.SetFloat("EffectsVolume", mEffectsVolume);
				}
				yield return (object)new WaitForSeconds(0.2f);
				((MonoBehaviour)this).StartCoroutine(RunOptionsMainMenu());
				mAudioOptionsOpen = false;
				UnHighlightWindow(oWindows[mAudioSelection]);
			}
			if (InputManager.Instance.IsPausePressed() || InputManager.Instance.IsPlannerPressed())
			{
				SFXManager.Instance.PlaySound("Confirm");
				ShortcutExtensions.DOScale(audioOptionsPanel, new Vector3(0.2f, 1.3f, 1f), 0.15f);
				TweenSettingsExtensions.SetDelay<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOScale(audioOptionsPanel, 0f, 0.1f), 0.15f);
				SFXManager.Instance.SetVolumes(storeMusicVolume, storeEffectsVolume);
				yield return (object)new WaitForSeconds(0.2f);
				((MonoBehaviour)this).StartCoroutine(RunOptionsMainMenu());
				mAudioOptionsOpen = false;
				UnHighlightWindow(oWindows[mAudioSelection]);
			}
		}
		((Component)audioOptionsPanel).GetComponent<CanvasGroup>().blocksRaycasts = false;
	}

	private int GetCurrentResIndex()
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0010: Unknown result type (might be due to invalid IL or missing references)
		//IL_0026: Unknown result type (might be due to invalid IL or missing references)
		//IL_002b: Unknown result type (might be due to invalid IL or missing references)
		for (int i = 0; i < mAvailableResolutions.Count; i++)
		{
			Resolution val = mAvailableResolutions[i];
			if (((Resolution)(ref val)).width == Screen.width)
			{
				val = mAvailableResolutions[i];
				if (((Resolution)(ref val)).height == Screen.height)
				{
					return i;
				}
			}
		}
		return 0;
	}

	private void CloseAreYouSure(bool backToMain)
	{
		//IL_001c: Unknown result type (might be due to invalid IL or missing references)
		mAreYouSureOpen = false;
		ShortcutExtensions.DOScale((Transform)(object)areYouSureMenu, new Vector3(0.2f, 1.3f, 1f), 0.15f);
		TweenSettingsExtensions.SetDelay<TweenerCore<Vector3, Vector3, VectorOptions>>(ShortcutExtensions.DOScale((Transform)(object)areYouSureMenu, 0f, 0.1f), 0.15f);
		if (backToMain)
		{
			((MonoBehaviour)this).Invoke("OpenPauseMenu", 0.2f);
		}
	}

	private void HighlightWindow(Transform t)
	{
		((Behaviour)((Component)t).GetComponentInChildren<Outline>()).enabled = true;
		ShortcutExtensions.DOScale(t, 1.01f, 0.2f);
	}

	private void HighlightWindow(Transform t, float s)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		Outline componentInChildren = ((Component)t).GetComponentInChildren<Outline>();
		((Behaviour)componentInChildren).enabled = true;
		((Shadow)componentInChildren).effectColor = Color.yellow;
		ShortcutExtensions.DOScale(t, s, 0.2f);
	}

	private void HighlightWindowGreen(Transform t, float s)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		Outline componentInChildren = ((Component)t).GetComponentInChildren<Outline>();
		((Behaviour)componentInChildren).enabled = true;
		((Shadow)componentInChildren).effectColor = Color.green;
		ShortcutExtensions.DOScale(t, s, 0.2f);
	}

	private void UnHighlightWindow(Transform t)
	{
		//IL_000d: Unknown result type (might be due to invalid IL or missing references)
		Outline componentInChildren = ((Component)t).GetComponentInChildren<Outline>();
		((Behaviour)componentInChildren).enabled = false;
		((Shadow)componentInChildren).effectColor = Color.yellow;
		ShortcutExtensions.DOScale(t, 1f, 0.2f);
	}

	private void UnHighlightButton(int x)
	{
		Transform child = pauseButtons.GetChild(x);
		((Behaviour)((Component)child).GetComponentInChildren<Outline>()).enabled = false;
		ShortcutExtensions.DOScale(child, 1f, 0.2f);
	}

	private void HighlightButton(int x)
	{
		Transform child = pauseButtons.GetChild(x);
		ShortcutExtensions.DOScale(child, 1.1f, 0.2f);
		((Behaviour)((Component)child).GetComponentInChildren<Outline>()).enabled = true;
	}

	private void UnHighlightHint(int x)
	{
		Transform child = hintGrid.GetChild(x);
		((Behaviour)((Component)child).GetComponentInChildren<Outline>()).enabled = false;
		ShortcutExtensions.DOScale(child, 1f, 0.2f);
	}

	private void HighlightHint(int x)
	{
		Transform child = hintGrid.GetChild(x);
		ShortcutExtensions.DOScale(child, 1.1f, 0.2f);
		((Behaviour)((Component)child).GetComponentInChildren<Outline>()).enabled = true;
	}
}
