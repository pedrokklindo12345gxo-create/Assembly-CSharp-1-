using UnityEngine;

public class Billy : NPCBehavior
{
	public TextureBlock eyesClosed;

	public void ResetLair()
	{
		//IL_0015: Unknown result type (might be due to invalid IL or missing references)
		((Component)this).transform.position = new Vector3(0f, 50f, 0f);
		pRend.enabled = false;
		ApplyTextureBlock(eyesClosed);
		mySkeleton.timeScale = 0f;
	}
}
