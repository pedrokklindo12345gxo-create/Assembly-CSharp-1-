using System;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;

namespace Spine.Unity.Modules;

[RequireComponent(typeof(SkeletonRenderer))]
public class SkeletonGhost : MonoBehaviour
{
	private const HideFlags GhostHideFlags = (HideFlags)1;

	private const string GhostingShaderName = "Spine/Special/SkeletonGhost";

	public bool ghostingEnabled = true;

	public float spawnRate = 0.05f;

	public Color32 color = new Color32(byte.MaxValue, byte.MaxValue, byte.MaxValue, (byte)0);

	[Tooltip("Remember to set color alpha to 0 if Additive is true")]
	public bool additive = true;

	public int maximumGhosts = 10;

	public float fadeSpeed = 10f;

	public Shader ghostShader;

	[Tooltip("0 is Color and Alpha, 1 is Alpha only.")]
	[Range(0f, 1f)]
	public float textureFade = 1f;

	[Header("Sorting")]
	public bool sortWithDistanceOnly;

	public float zOffset;

	private float nextSpawnTime;

	private SkeletonGhostRenderer[] pool;

	private int poolIndex;

	private SkeletonRenderer skeletonRenderer;

	private MeshRenderer meshRenderer;

	private MeshFilter meshFilter;

	private readonly Dictionary<Material, Material> materialTable = new Dictionary<Material, Material>();

	private void Start()
	{
		//IL_0091: Unknown result type (might be due to invalid IL or missing references)
		//IL_0097: Expected O, but got Unknown
		if ((Object)(object)ghostShader == (Object)null)
		{
			ghostShader = Shader.Find("Spine/Special/SkeletonGhost");
		}
		skeletonRenderer = ((Component)this).GetComponent<SkeletonRenderer>();
		meshFilter = ((Component)this).GetComponent<MeshFilter>();
		meshRenderer = ((Component)this).GetComponent<MeshRenderer>();
		nextSpawnTime = Time.time + spawnRate;
		pool = new SkeletonGhostRenderer[maximumGhosts];
		for (int i = 0; i < maximumGhosts; i++)
		{
			GameObject val = new GameObject(((Object)((Component)this).gameObject).name + " Ghost", new Type[1] { typeof(SkeletonGhostRenderer) });
			pool[i] = val.GetComponent<SkeletonGhostRenderer>();
			val.SetActive(false);
			((Object)val).hideFlags = (HideFlags)1;
		}
		if (skeletonRenderer is IAnimationStateComponent animationStateComponent)
		{
			animationStateComponent.AnimationState.Event += OnEvent;
		}
	}

	private void OnEvent(TrackEntry trackEntry, Event e)
	{
		//IL_0054: Unknown result type (might be due to invalid IL or missing references)
		//IL_0059: Unknown result type (might be due to invalid IL or missing references)
		if (e.Data.Name.Equals("Ghosting", StringComparison.Ordinal))
		{
			ghostingEnabled = e.Int > 0;
			if (e.Float > 0f)
			{
				spawnRate = e.Float;
			}
			if (!string.IsNullOrEmpty(e.stringValue))
			{
				color = HexToColor(e.String);
			}
		}
	}

	private void Ghosting(float val)
	{
		ghostingEnabled = val > 0f;
	}

	private void Update()
	{
		//IL_00e5: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Unknown result type (might be due to invalid IL or missing references)
		//IL_0053: Expected O, but got Unknown
		//IL_0062: Unknown result type (might be due to invalid IL or missing references)
		//IL_0139: Unknown result type (might be due to invalid IL or missing references)
		//IL_0144: Unknown result type (might be due to invalid IL or missing references)
		//IL_014f: Unknown result type (might be due to invalid IL or missing references)
		if (!ghostingEnabled || !(Time.time >= nextSpawnTime))
		{
			return;
		}
		GameObject gameObject = ((Component)pool[poolIndex]).gameObject;
		Material[] sharedMaterials = ((Renderer)meshRenderer).sharedMaterials;
		for (int i = 0; i < sharedMaterials.Length; i++)
		{
			Material val = sharedMaterials[i];
			Material val2;
			if (!materialTable.ContainsKey(val))
			{
				val2 = new Material(val);
				val2.shader = ghostShader;
				val2.color = Color.white;
				if (val2.HasProperty("_TextureFade"))
				{
					val2.SetFloat("_TextureFade", textureFade);
				}
				materialTable.Add(val, val2);
			}
			else
			{
				val2 = materialTable[val];
			}
			sharedMaterials[i] = val2;
		}
		Transform transform = gameObject.transform;
		transform.parent = ((Component)this).transform;
		pool[poolIndex].Initialize(meshFilter.sharedMesh, sharedMaterials, color, additive, fadeSpeed, ((Renderer)meshRenderer).sortingLayerID, (!sortWithDistanceOnly) ? (((Renderer)meshRenderer).sortingOrder - 1) : ((Renderer)meshRenderer).sortingOrder);
		transform.localPosition = new Vector3(0f, 0f, zOffset);
		transform.localRotation = Quaternion.identity;
		transform.localScale = Vector3.one;
		transform.parent = null;
		poolIndex++;
		if (poolIndex == pool.Length)
		{
			poolIndex = 0;
		}
		nextSpawnTime = Time.time + spawnRate;
	}

	private void OnDestroy()
	{
		for (int i = 0; i < maximumGhosts; i++)
		{
			if ((Object)(object)pool[i] != (Object)null)
			{
				pool[i].Cleanup();
			}
		}
		foreach (Material value in materialTable.Values)
		{
			Object.Destroy((Object)(object)value);
		}
	}

	private static Color32 HexToColor(string hex)
	{
		//IL_0009: Unknown result type (might be due to invalid IL or missing references)
		//IL_000e: Unknown result type (might be due to invalid IL or missing references)
		//IL_0083: Unknown result type (might be due to invalid IL or missing references)
		if (hex.Length < 6)
		{
			return Color32.op_Implicit(Color.magenta);
		}
		hex = hex.Replace("#", string.Empty);
		byte num = byte.Parse(hex.Substring(0, 2), NumberStyles.HexNumber);
		byte b = byte.Parse(hex.Substring(2, 2), NumberStyles.HexNumber);
		byte b2 = byte.Parse(hex.Substring(4, 2), NumberStyles.HexNumber);
		byte b3 = byte.MaxValue;
		if (hex.Length == 8)
		{
			b3 = byte.Parse(hex.Substring(6, 2), NumberStyles.HexNumber);
		}
		return new Color32(num, b, b2, b3);
	}
}
